# Payload CMS with Supabase Setup

## Quick Start

1. **Install dependencies** (already done)
   ```bash
   npm install
   ```

2. **Set up environment variables**
   - Copy `.env.example` to `.env`
   - Update `DATABASE_URI` with your Supabase PostgreSQL connection string
   - Set a secure `PAYLOAD_SECRET`

3. **Run Payload CMS**
   ```bash
   node scripts/payload.js
   ```

4. **Access Admin Panel**
   - Open http://localhost:3001/admin
   - Create your first admin user

## Environment Variables

```bash
# Required
PAYLOAD_SECRET=your-very-secure-secret-key
DATABASE_URI=postgresql://postgres.ehfsfqmzmrwzlgnbpyzz:your-password@aws-0-us-east-1.pooler.supabase.com:5432/postgres

# Optional
PORT=3001
```

## Supabase Database Setup

### Using Your Existing Supabase Project
Your Payload CMS will use the same Supabase database as your frontend:
- **Project ID**: ehfsfqmzmrwzlgnbpyzz
- **Database URL**: Available in your Supabase dashboard

### Getting Your Database Connection String
1. Go to [Supabase Dashboard](https://supabase.com/dashboard/project/ehfsfqmzmrwzlgnbpyzz/settings/database)
2. Copy the "Connection string" under "Database settings"
3. Replace `[YOUR-PASSWORD]` with your database password
4. Use this as your `DATABASE_URI`

### Benefits of Supabase Integration
- **Unified Database**: CMS and app data in one place
- **Real-time**: Potential for live content updates
- **Scalability**: Supabase handles infrastructure
- **Security**: Built-in RLS policies available
- **Backup**: Automatic database backups

## Database Tables

Payload will automatically create these tables in your Supabase database:
- `payload_users` - CMS admin users
- `payload_categories` - Content categories  
- `payload_posts` - Blog posts
- `payload_resources` - Resource content
- Additional Payload system tables

## Available Collections

- **Users**: Admin and editor accounts
- **Categories**: Content categorization
- **Posts**: Blog posts with SEO
- **Resources**: Downloadable resources and tools

## Next Steps

1. Start the server: `node scripts/payload.js`
2. Create admin user in /admin
3. Add categories
4. Create content
5. Test frontend integration at main site

## Troubleshooting

- Ensure your Supabase project allows connections
- Check that the DATABASE_URI is correct
- Verify PAYLOAD_SECRET is set
- Make sure port 3001 is available