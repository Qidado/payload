#!/usr/bin/env node

const { spawn } = require('child_process')
const path = require('path')

// Build and run the Payload server
const serverPath = path.join(__dirname, '../src/server.ts')

console.log('Starting Payload CMS server...')
console.log('Admin interface will be available at: http://localhost:3001/admin')
console.log('')

// Use tsx to run TypeScript directly
const server = spawn('npx', ['tsx', serverPath], {
  stdio: 'inherit',
  shell: true
})

server.on('close', (code) => {
  console.log(`Payload server exited with code ${code}`)
})

server.on('error', (err) => {
  console.error('Failed to start Payload server:', err)
})