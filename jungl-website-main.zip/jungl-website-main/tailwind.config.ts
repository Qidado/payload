
import type { Config } from "tailwindcss";

export default {
	darkMode: ["class"],
	content: [
		"./pages/**/*.{ts,tsx}",
		"./components/**/*.{ts,tsx}",
		"./app/**/*.{ts,tsx}",
		"./src/**/*.{ts,tsx}",
	],
	prefix: "",
	theme: {
		container: {
			center: true,
			padding: '2rem',
			screens: {
				'2xl': '1536px'
			}
		},
		extend: {
			colors: {
				border: 'hsl(0, 0%, 14.9%)', // zinc-800
				input: 'hsl(0, 0%, 14.9%)',
				ring: 'hsl(0, 0%, 98%)', // white
				background: 'hsl(0, 0%, 0%)', // black
				foreground: 'hsl(0, 0%, 98%)', // white
				primary: {
					DEFAULT: 'hsl(0, 0%, 98%)', // white
					foreground: 'hsl(0, 0%, 0%)' // black
				},
				secondary: {
					DEFAULT: 'hsl(0, 0%, 14.9%)', // zinc-900
					foreground: 'hsl(0, 0%, 98%)' // white
				},
				destructive: {
					DEFAULT: 'hsl(0, 84.2%, 60.2%)',
					foreground: 'hsl(0, 0%, 98%)'
				},
				muted: {
					DEFAULT: 'hsl(0, 0%, 14.9%)', // zinc-900
					foreground: 'hsl(0, 0%, 65.1%)' // zinc-300
				},
				accent: {
					DEFAULT: 'hsl(0, 0%, 3%)', // zinc-950
					foreground: 'hsl(0, 0%, 98%)'
				},
				popover: {
					DEFAULT: 'hsl(0, 0%, 3%)', // zinc-950
					foreground: 'hsl(0, 0%, 98%)'
				},
				card: {
					DEFAULT: 'hsl(0, 0%, 3%)', // zinc-950
					foreground: 'hsl(0, 0%, 98%)'
				},
				sidebar: {
					DEFAULT: 'hsl(0, 0%, 0%)',
					foreground: 'hsl(0, 0%, 98%)',
					primary: 'hsl(0, 0%, 98%)',
					'primary-foreground': 'hsl(0, 0%, 0%)',
					accent: 'hsl(0, 0%, 3%)',
					'accent-foreground': 'hsl(0, 0%, 98%)',
					border: 'hsl(0, 0%, 14.9%)',
					ring: 'hsl(0, 0%, 98%)'
				}
			},
			borderRadius: {
				lg: '0', // Remove rounded corners
				md: '0', // Remove rounded corners
				sm: '0'  // Remove rounded corners
			},
			keyframes: {
				'accordion-down': {
					from: {
						height: '0'
					},
					to: {
						height: 'var(--radix-accordion-content-height)'
					}
				},
				'accordion-up': {
					from: {
						height: 'var(--radix-accordion-content-height)'
					},
					to: {
						height: '0'
					}
				},
				'fade-in': {
					'0%': {
						opacity: '0',
						transform: 'translateY(20px)'
					},
					'100%': {
						opacity: '1',
						transform: 'translateY(0)'
					}
				},
				'slide-up': {
					'0%': {
						opacity: '0',
						transform: 'translateY(40px)'
					},
					'100%': {
						opacity: '1',
						transform: 'translateY(0)'
					}
				},
				'slide-in-bottom': {
					'0%': {
						transform: 'translateY(100%)',
						opacity: '0'
					},
					'100%': {
						transform: 'translateY(0)',
						opacity: '1'
					}
				}
			},
			animation: {
				'accordion-down': 'accordion-down 0.2s ease-out',
				'accordion-up': 'accordion-up 0.2s ease-out',
				'fade-in': 'fade-in 0.8s ease-out',
				'slide-up': 'slide-up 0.6s ease-out',
				'slide-in-bottom': 'slide-in-bottom 0.4s cubic-bezier(0.4, 0, 0.2, 1)'
			},
			fontFamily: {
				'khinterference': ['KHInterferenceTRIAL', 'system-ui', 'sans-serif'],
				'khteka': ['KHTekaTRIAL', 'system-ui', 'sans-serif'],
				'khgiga': ['KHGigaTRIAL', 'system-ui', 'sans-serif']
			},
			maxWidth: {
				'container': '1536px'
			}
		}
	},
	plugins: [require("tailwindcss-animate")],
} satisfies Config;
