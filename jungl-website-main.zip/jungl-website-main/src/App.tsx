
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { HelmetProvider } from 'react-helmet-async';
import { useEffect } from 'react';
import { initializePostHog } from '@/lib/posthog';
import { usePostHogPageTracking } from '@/hooks/usePostHogPageTracking';
import Index from "./pages/Index";
import Brands from "./pages/Brands";
import Resources from "./pages/Resources";
import Blog from "./pages/Blog";
import TestSections from "./pages/TestSections";
import Login from "./pages/Login";
import Privacy from "./pages/Privacy";
import About from "./pages/About";
import Legal from "./pages/Legal";
import Press from "./pages/Press";
import Terms from "./pages/Terms";
import NotFound from "./pages/NotFound";
import BookDemo from "./pages/BookDemo";

const queryClient = new QueryClient();

const PostHogProvider = ({ children }: { children: React.ReactNode }) => {
  useEffect(() => {
    initializePostHog();
  }, []);

  usePostHogPageTracking();
  
  return <>{children}</>;
};

const App = () => (
  <HelmetProvider>
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <PostHogProvider>
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/brands" element={<Brands />} />
              <Route path="/resources" element={<Resources />} />
              <Route path="/blog" element={<Blog />} />
              <Route path="/test-sections" element={<TestSections />} />
              <Route path="/login" element={<Login />} />
              <Route path="/privacy" element={<Privacy />} />
              <Route path="/about" element={<About />} />
              <Route path="/legal" element={<Legal />} />
              <Route path="/press" element={<Press />} />
              <Route path="/terms" element={<Terms />} />
              <Route path="/book-demo" element={<BookDemo />} />
              {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </PostHogProvider>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  </HelmetProvider>
);

export default App;
