// Temporary types until Payload generates them automatically

export interface User {
  id: string
  name: string
  email: string
  role: 'admin' | 'editor'
  createdAt: string
  updatedAt: string
}

export interface Category {
  id: string
  name: string
  slug: string
  description?: string
  color?: string
  createdAt: string
  updatedAt: string
}

export interface Resource {
  id: string
  title: string
  slug: string
  description: string
  content?: any
  type: 'guide' | 'template' | 'tool' | 'course' | 'checklist' | 'calculator'
  category: string | Category
  tags?: { tag: string }[]
  featured: boolean
  image?: string
  downloadUrl?: string
  externalUrl?: string
  difficulty?: 'beginner' | 'intermediate' | 'advanced'
  estimatedTime?: string
  createdAt: string
  updatedAt: string
}

export interface Post {
  id: string
  title: string
  slug: string
  excerpt: string
  content: any
  featuredImage?: string
  category: string | Category
  tags?: { tag: string }[]
  author: string | User
  status: 'draft' | 'published' | 'scheduled'
  publishedAt?: string
  readTime?: number
  createdAt: string
  updatedAt: string
}