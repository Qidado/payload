import { useState, useEffect } from 'react';

export const useScrollPercentage = (threshold: number = 25) => {
  const [isVisible, setIsVisible] = useState(false);
  const [scrollPercentage, setScrollPercentage] = useState(0);

  useEffect(() => {
    let ticking = false;

    const handleScroll = () => {
      if (!ticking) {
        requestAnimationFrame(() => {
          const scrollTop = window.pageYOffset;
          const documentHeight = document.documentElement.scrollHeight - window.innerHeight;
          const percentage = (scrollTop / documentHeight) * 100;
          
          setScrollPercentage(percentage);
          setIsVisible(percentage >= threshold);
          ticking = false;
        });
        ticking = true;
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll(); // Check initial state

    return () => window.removeEventListener('scroll', handleScroll);
  }, [threshold]);

  return { isVisible, scrollPercentage };
};