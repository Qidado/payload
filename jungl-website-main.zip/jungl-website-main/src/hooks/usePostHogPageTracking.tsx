import { useLocation } from 'react-router-dom';

export const usePostHogPageTracking = () => {
  const location = useLocation();
  // PostHog now automatically captures page views when capture_pageview: true
  // This hook remains for potential future custom page tracking logic
};