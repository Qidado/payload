import { useEffect, useRef } from 'react';
import { trackScrollDepth } from '@/lib/posthog';

export const useScrollTracking = () => {
  const scrollThresholds = useRef(new Set<number>());

  useEffect(() => {
    let ticking = false;

    const handleScroll = () => {
      if (!ticking) {
        requestAnimationFrame(() => {
          const scrollTop = window.pageYOffset;
          const documentHeight = document.documentElement.scrollHeight - window.innerHeight;
          const percentage = Math.round((scrollTop / documentHeight) * 100);
          
          // Track at 25%, 50%, 75%, and 100% milestones
          const thresholds = [25, 50, 75, 100];
          
          thresholds.forEach(threshold => {
            if (percentage >= threshold && !scrollThresholds.current.has(threshold)) {
              scrollThresholds.current.add(threshold);
              trackScrollDepth(threshold);
            }
          });
          
          ticking = false;
        });
        ticking = true;
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
};