import express from 'express'
import payload from 'payload'
import { config } from 'dotenv'
import payloadConfig from '../payload.config'

// Load environment variables
config()

const app = express()
const PORT = process.env.PORT || 3001

// Redirect root to admin
app.get('/', (req, res) => {
  res.redirect('/admin')
})

// Initialize Payload
const start = async (): Promise<void> => {
  await payload.init({
    config: payloadConfig,
    onInit: async () => {
      payload.logger.info(`Payload Admin URL: ${payload.getAdminURL()}`)
    },
  })

  // Payload handles its own routing

  app.listen(PORT, async () => {
    payload.logger.info(`Server listening on port ${PORT}`)
    payload.logger.info(`Admin panel: http://localhost:${PORT}/admin`)
  })
}

start()