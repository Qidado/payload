
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import { H2, BodyLarge } from "./Typography";

const BrandEnergy = () => {
  return (
    <section className="py-16 sm:py-20 lg:py-24 px-4 sm:px-6 lg:px-8 bg-black">
      <div className="max-w-container mx-auto text-center">
        <div className="scroll-fade">
          <H2 className="text-white mb-4 sm:mb-6">
            Ready to energize your brand?
          </H2>
          <BodyLarge className="text-zinc-300 mb-6 sm:mb-8 max-w-2xl mx-auto">
            Join thousands of creators who are already building and scaling their businesses with Jungl. 
            Your success story starts here.
          </BodyLarge>
          
          <Button 
            size="lg" 
            className="bg-white text-black hover:opacity-90 hover:scale-105 px-6 py-3 text-base sm:px-8 sm:py-4 sm:text-lg font-khteka font-medium transition-all duration-300 w-full max-w-sm sm:w-auto"
          >
            Get Started Today
            <ArrowRight className="ml-2 h-4 w-4 sm:h-5 sm:w-5" />
          </Button>
        </div>
      </div>
    </section>
  );
};

export default BrandEnergy;
