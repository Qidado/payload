import { Helmet } from 'react-helmet-async';

interface BrandsSEOProps {
  title?: string;
  description?: string;
  image?: string;
  url?: string;
}

const BrandsSEO = ({ 
  title = "Jungl for Brands – Activate Top Creators in 24 H",
  description = "Brief, book and pay creators in one dashboard. Guaranteed brand safety & real‑time ROI. Book a demo today.",
  image = "/jungl-opengraph.jpg",
  url = "https://jungl.co/brands"
}: BrandsSEOProps) => {
  const structuredData = {
    "@context": "https://schema.org",
    "@type": "Service",
    "name": "Jungl for Brands",
    "description": description,
    "provider": {
      "@type": "Organization",
      "name": "Jungl",
      "url": "https://jungl.co"
    },
    "serviceType": "Creator Marketing Platform",
    "audience": {
      "@type": "BusinessAudience",
      "audienceType": "Brands and Businesses"
    }
  };

  return (
    <Helmet>
      {/* Primary Meta Tags */}
      <title>{title}</title>
      <meta name="title" content={title} />
      <meta name="description" content={description} />
      <meta name="keywords" content="creator marketing, influencer marketing, brand partnerships, content creators, ROI tracking, brand campaigns" />
      <link rel="canonical" href={url} />

      {/* Open Graph / Facebook */}
      <meta property="og:type" content="website" />
      <meta property="og:url" content={url} />
      <meta property="og:title" content={title} />
      <meta property="og:description" content={description} />
      <meta property="og:image" content={image} />
      <meta property="og:site_name" content="Jungl" />

      {/* Twitter */}
      <meta property="twitter:card" content="summary_large_image" />
      <meta property="twitter:url" content={url} />
      <meta property="twitter:title" content={title} />
      <meta property="twitter:description" content={description} />
      <meta property="twitter:image" content={image} />

      {/* Structured Data */}
      <script type="application/ld+json">
        {JSON.stringify(structuredData)}
      </script>
    </Helmet>
  );
};

export default BrandsSEO;