import { Button } from "@/components/ui/button";
import { ArrowRight, ArrowDown } from "lucide-react";
import { HeroMegaDisplay, BodyLarge, Caption } from "./Typography";
const Hero = () => {
  const handleEarlyAccessClick = () => {
    window.open("https://apps.apple.com/dk/app/jungl-creator-business-hub/id6741893457", "_blank");
  };
  return <section className="relative h-screen w-full overflow-hidden dark" role="banner" aria-label="Hero section">
      {/* Background Video with fallback */}
      <video autoPlay muted loop playsInline preload="auto" poster="https://ehfsfqmzmrwzlgnbpyzz.supabase.co/storage/v1/object/public/assets/hero-fallback.jpg" className="video-crop z-0" width="1920" height="1080" aria-hidden="true" onLoadedMetadata={e => {
      const video = e.target as HTMLVideoElement;
      console.log('Video dimensions:', {
        videoWidth: video.videoWidth,
        videoHeight: video.videoHeight,
        aspectRatio: video.videoWidth / video.videoHeight,
        containerWidth: video.offsetWidth,
        containerHeight: video.offsetHeight
      });
      video.play().catch(err => {
        console.log('Video autoplay prevented:', err);
      });
    }} onCanPlay={e => {
      const video = e.target as HTMLVideoElement;
      video.play().catch(err => {
        console.log('Video play failed:', err);
      });
    }} onError={() => {
      console.log('Video failed to load, showing fallback');
    }}>
        <source src="https://ehfsfqmzmrwzlgnbpyzz.supabase.co/storage/v1/object/public/assets/Headervideo.mp4" type="video/mp4" />
        Your browser does not support the video tag.
      </video>

      {/* Fallback background image for non-JS/SEO crawlers */}
      <noscript>
        <div className="absolute inset-0 z-0 bg-cover bg-center bg-no-repeat" style={{
        backgroundImage: "url('https://ehfsfqmzmrwzlgnbpyzz.supabase.co/storage/v1/object/public/assets/hero-fallback.jpg')"
      }} aria-hidden="true" />
      </noscript>

      {/* Dim overlay covering entire hero including nav area */}
      <div className="absolute inset-0 bg-black/60 z-10" />

      {/* Grain texture covering entire hero including nav area */}
      <div className="absolute inset-0 opacity-5 bg-[url('/grain.svg')] z-20" />

      {/* Hero Content */}
      <div className="relative z-30 flex flex-col items-center justify-center text-center h-full px-4 sm:px-6">
        <div className="animate-fade-in">
          {/* Early Access Badge */}
          <div className="inline-flex items-center gap-2 bg-white/10 border border-white/20 rounded-full px-4 py-2 mb-6 backdrop-blur-sm">
            <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
            <span className="text-white text-sm font-medium">Early Access • Limited Spots</span>
          </div>

          {/* Headline - Responsive sizing */}
          <HeroMegaDisplay className="text-white mb-6">
            <span className="block">Run Your Creator Business</span>
            <span className="block">Without the Hassle</span>
          </HeroMegaDisplay>
          
          {/* Subheadline - Mobile optimized */}
          <BodyLarge className="text-zinc-300 mb-6 max-w-4xl mx-auto">
            <span className="block">Invoice brands instantly, track every cent, land your next collab.</span>
            <span className="block">Jungl does the boring stuff, so you can stay creative.</span>
          </BodyLarge>
          
          {/* Call-to-Action Section */}
          <div className="flex flex-col gap-4 justify-center items-center w-full max-w-sm mx-auto sm:max-w-none sm:flex-row sm:gap-6">
            {/* Primary CTA */}
            <Button size="lg" className="bg-white text-black hover:bg-zinc-50 hover:shadow-lg hover:scale-[1.02] focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-black px-6 py-3 text-base sm:px-8 sm:py-4 sm:text-lg font-khteka font-medium transition-all duration-200 w-full sm:w-auto" onClick={handleEarlyAccessClick} aria-label="Request early access to Jungl" title="Skip the queue – I'm in.">
              Get Early Access
              <ArrowRight className="ml-2 h-4 w-4 sm:h-5 sm:w-5" />
            </Button>
            
            {/* Secondary Demo Link */}
            <a href="#demo" className="text-white/80 hover:text-white text-sm sm:text-base font-khteka underline underline-offset-4 hover:underline-offset-2 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-white/50 rounded px-2 py-1" aria-label="Watch 40-second product demo">
              Watch 40-second demo ↓
            </a>
          </div>

          {/* Social Proof */}
          
        </div>
      </div>

      {/* Scroll Indicator - Hidden on small mobile */}
      <button 
        className="absolute bottom-8 sm:bottom-16 left-1/2 transform -translate-x-1/2 z-30 flex flex-col items-center animate-fade-in hover:scale-105 transition-transform duration-200 cursor-pointer group"
        onClick={() => {
          const nextSection = document.querySelector('#problem');
          nextSection?.scrollIntoView({ behavior: 'smooth' });
        }}
        aria-label="Scroll to next section"
      >
        <Caption className="text-white mb-2 tracking-wider group-hover:text-white/80 transition-colors">ENTER THE JUNGLE</Caption>
        <ArrowDown className="w-5 h-5 sm:w-6 sm:h-6 text-white animate-bounce group-hover:text-white/80 transition-colors" />
      </button>
    </section>;
};
export default Hero;