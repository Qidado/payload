import { H2, H3, Body } from "@/components/Typography";
import { Play, Pause, CreditCard, Briefcase, Users, RotateCcw, Zap, TrendingUp, CheckCircle } from "lucide-react";
import { useState, useRef } from "react";

const CardFlipReveal = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [flippedCards, setFlippedCards] = useState<number[]>([]);
  const [currentStep, setCurrentStep] = useState(0);
  const videoRef = useRef<HTMLVideoElement>(null);

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const flipCard = (index: number) => {
    if (!flippedCards.includes(index)) {
      setFlippedCards([...flippedCards, index]);
    }
  };

  const problems = [
    {
      title: "Invoice Hell",
      problem: "Spending 8+ hours per week creating, sending, and tracking invoices manually.",
      solution: "Auto-generated invoices with smart payment tracking and reminder sequences.",
      impact: "Save 95% of your admin time",
      icon: CreditCard
    },
    {
      title: "Opportunity Chaos", 
      problem: "Drowning in irrelevant brand emails while missing perfect partnerships.",
      solution: "AI-powered matching that delivers only brands that fit your audience perfectly.",
      impact: "3x higher deal values",
      icon: Briefcase
    },
    {
      title: "Team Scattered",
      problem: "Files everywhere, missed deadlines, and constant confusion about who's doing what.",
      solution: "Centralized hub with role-based access, automatic syncing, and deadline tracking.",
      impact: "Zero missed deadlines",
      icon: Users
    }
  ];

  const workflowSteps = [
    {
      title: "Connect Once",
      description: "Link your accounts in under 2 minutes",
      icon: Zap,
      detail: "One-time setup that saves 20+ hours per week forever"
    },
    {
      title: "Create Freely", 
      description: "Focus on content while Jungl handles business",
      icon: RotateCcw,
      detail: "Automatic tracking, invoicing, and payment processing"
    },
    {
      title: "Scale Endlessly",
      description: "Grow without the growing pains",
      icon: TrendingUp,
      detail: "Perfect opportunities and seamless team collaboration"
    }
  ];

  return (
    <div className="bg-black">
      {/* Clean Hero */}
      <div className="py-20 px-4 sm:px-6 lg:px-8 text-center">
        <div className="max-w-3xl mx-auto scroll-fade">
          <H2 className="text-white mb-6 text-4xl leading-tight">
            Click to Transform
          </H2>
          <Body className="text-zinc-300 text-lg max-w-xl mx-auto mb-12">
            Three problems. Three solutions. Click each card to reveal how Jungl fixes everything.
          </Body>
        </div>
      </div>

      {/* Problem → Solution Cards */}
      <div className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16 scroll-fade">
            <H2 className="text-white mb-6">Your Problems Have Solutions</H2>
            <Body className="text-zinc-300 text-lg">Click any card to see the transformation</Body>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-16">
            {problems.map((problem, index) => (
              <div key={index} className="scroll-fade">
                <div 
                  className={`relative h-72 cursor-pointer transition-transform duration-700 preserve-3d ${
                    flippedCards.includes(index) ? 'rotate-y-180' : ''
                  }`}
                  style={{ transformStyle: 'preserve-3d' }}
                  onClick={() => flipCard(index)}
                >
                  {/* Front - Problem */}
                  <div className="absolute inset-0 w-full h-full bg-red-950/20 border border-red-500/20 rounded-xl p-6 backface-hidden">
                    <div className="flex flex-col h-full">
                      <div className="mb-6">
                        <div className="w-16 h-16 bg-red-500/10 rounded-xl flex items-center justify-center mb-4">
                          <problem.icon className="h-8 w-8 text-red-400" />
                        </div>
                        <H3 className="text-red-400 mb-4">{problem.title}</H3>
                      </div>
                      <Body className="text-zinc-300 flex-1">{problem.problem}</Body>
                      <div className="mt-6 text-center">
                        <div className="inline-flex items-center gap-2 text-zinc-400 text-sm">
                          <RotateCcw className="w-4 h-4" />
                          Click to flip
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Back - Solution */}
                  <div className="absolute inset-0 w-full h-full bg-green-950/20 border border-green-500/20 rounded-xl p-6 backface-hidden rotate-y-180">
                    <div className="flex flex-col h-full">
                      <div className="mb-6">
                        <div className="w-16 h-16 bg-green-500/10 rounded-xl flex items-center justify-center mb-4">
                          <CheckCircle className="h-8 w-8 text-green-400" />
                        </div>
                        <H3 className="text-green-400 mb-4">Solved!</H3>
                      </div>
                      <Body className="text-zinc-300 mb-4">{problem.solution}</Body>
                      <div className="mt-auto">
                        <div className="bg-gradient-to-r from-green-500/10 to-blue-500/10 border border-green-500/20 rounded-lg p-3">
                          <div className="text-white font-bold text-center">{problem.impact}</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Workflow Section - Only show after cards are flipped */}
      {flippedCards.length >= 2 && (
        <div className="py-16 px-4 sm:px-6 lg:px-8 bg-zinc-950">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16 scroll-fade">
              <H2 className="text-white mb-6">How It Actually Works</H2>
              <Body className="text-zinc-300 text-lg">Three steps to transform your business</Body>
            </div>

            <div className="grid md:grid-cols-3 gap-8 mb-16">
              {workflowSteps.map((step, index) => (
                <div
                  key={index}
                  className={`scroll-fade text-center cursor-pointer transition-all duration-300 ${
                    currentStep === index ? 'scale-105' : 'hover:scale-102'
                  }`}
                  style={{ animationDelay: `${index * 300}ms` }}
                  onClick={() => setCurrentStep(index)}
                >
                  <div className={`p-8 rounded-xl border transition-all duration-300 ${
                    currentStep === index 
                      ? 'bg-white/5 border-white/20' 
                      : 'bg-zinc-900 border-zinc-800 hover:border-zinc-700'
                  }`}>
                    <div className="relative mb-6">
                      <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto transition-all duration-300 ${
                        currentStep === index ? 'bg-white text-black scale-110' : 'bg-white/10 text-white'
                      }`}>
                        <step.icon className="h-8 w-8" />
                      </div>
                      <div className="absolute -top-2 -right-2 w-8 h-8 bg-white text-black rounded-full flex items-center justify-center text-sm font-bold">
                        {index + 1}
                      </div>
                    </div>
                    <H3 className="text-white mb-4">{step.title}</H3>
                    <Body className="text-zinc-300 mb-4">{step.description}</Body>
                    <Body className="text-zinc-500 text-sm italic">{step.detail}</Body>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Demo Section - Only show after workflow is revealed */}
      {flippedCards.length === 3 && (
        <div className="py-16 px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <div className="scroll-fade space-y-8">
              <H2 className="text-white mb-6">
                See The Transformation
              </H2>
              
              <Body className="text-zinc-300 text-lg max-w-2xl mx-auto mb-12">
                This is what your new reality looks like
              </Body>
              
              {/* Video */}
              <div className="relative max-w-sm mx-auto mb-12">
                <div className="absolute -inset-4 bg-gradient-to-r from-green-500/20 via-blue-500/20 to-purple-500/20 rounded-3xl blur-xl"></div>
                <div className="relative bg-zinc-900 rounded-3xl overflow-hidden shadow-2xl border border-zinc-800 aspect-[9/19]">
                  <video
                    ref={videoRef}
                    className="w-full h-full object-cover rounded-3xl"
                    loop
                    muted
                    playsInline
                    onPlay={() => setIsPlaying(true)}
                    onPause={() => setIsPlaying(false)}
                    poster="/video-placeholder.jpg"
                  >
                    <source src="/video-placeholder.jpg" type="video/mp4" />
                  </video>
                  
                  <button
                    onClick={togglePlay}
                    className="absolute inset-0 flex items-center justify-center bg-black/20 hover:bg-black/30 transition-all duration-200 group rounded-3xl"
                  >
                    <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-full p-4 group-hover:bg-white/20 transition-all duration-200">
                      {isPlaying ? (
                        <Pause className="w-8 h-8 text-white" />
                      ) : (
                        <Play className="w-8 h-8 text-white ml-1" />
                      )}
                    </div>
                  </button>
                </div>
              </div>

              {/* Final Impact */}
              <div className="bg-gradient-to-r from-zinc-900 via-zinc-800 to-zinc-900 border border-zinc-700 rounded-2xl p-8 max-w-2xl mx-auto mb-12">
                <H3 className="text-white mb-6">The Result</H3>
                <div className="grid grid-cols-3 gap-6 mb-6">
                  {[
                    { metric: "90%", label: "Less Admin Work" },
                    { metric: "3x", label: "Higher Revenue" },
                    { metric: "100%", label: "Peace of Mind" }
                  ].map((item, index) => (
                    <div key={index} className="text-center">
                      <div className="text-3xl font-bold bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent mb-2">
                        {item.metric}
                      </div>
                      <div className="text-zinc-400 text-sm">{item.label}</div>
                    </div>
                  ))}
                </div>
              </div>
              
              {/* App Store Buttons */}
              <div className="flex flex-row gap-4 justify-center items-center">
                <a 
                  href="https://apps.apple.com/dk/app/jungl-creator-business-hub/id6741893457" 
                  className="block transition-transform hover:scale-105" 
                  target="_blank" 
                  rel="noopener noreferrer"
                >
                  <img 
                    src="https://ehfsfqmzmrwzlgnbpyzz.supabase.co/storage/v1/object/public/assets//2.svg" 
                    alt="Download Jungl on the App Store" 
                    className="h-14 w-auto"
                  />
                </a>
                <a 
                  href="#" 
                  className="block transition-transform hover:scale-105" 
                  target="_blank" 
                  rel="noopener noreferrer"
                >
                  <img 
                    src="https://ehfsfqmzmrwzlgnbpyzz.supabase.co/storage/v1/object/public/assets//1.svg" 
                    alt="Get Jungl on Google Play" 
                    className="h-14 w-auto"
                  />
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CardFlipReveal;