import { H2, H3, Body } from "@/components/Typography";
import { Play, Pause, CreditCard, Briefcase, Users, Link, Zap, TrendingUp, ChevronDown, Star, Clock, DollarSign } from "lucide-react";
import { useState, useRef, useEffect } from "react";

const ProgressiveStoryFlow52 = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  return (
    <div className="bg-black min-h-screen">
      {/* Clean Hero */}
      <div className="py-20 px-4 sm:px-6 lg:px-8 text-center">
        <div className="max-w-3xl mx-auto scroll-fade">
          <H2 className="text-white mb-6 text-4xl leading-tight">
            Before & After
          </H2>
          <Body className="text-zinc-300 text-lg max-w-xl mx-auto">
            See how Jungl transforms your creator business
          </Body>
        </div>
      </div>

      {/* Section 1: The Current Reality */}
      <div className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-black to-red-950/20">
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="scroll-fade">
              <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-2 w-fit mb-6">
                <span className="text-red-400 text-sm font-medium">Chapter 1: Reality Check</span>
              </div>
              <H2 className="text-white mb-6">
                The Success Trap
              </H2>
              <Body className="text-zinc-300 text-lg mb-8">
                You started creating because you loved it. But somewhere along the way, 
                success became your biggest enemy.
              </Body>
              
              {/* Statistics */}
              <div className="grid grid-cols-2 gap-6 mb-8">
                {[
                  { number: "73%", label: "of your time on admin", icon: Clock },
                  { number: "40%", label: "revenue lost to chaos", icon: DollarSign },
                  { number: "89%", label: "creators feel burned out", icon: Star },
                  { number: "0", label: "time for actual creating", icon: Zap }
                ].map((stat, index) => (
                  <div key={index} className="text-center">
                    <div className="w-12 h-12 bg-red-500/10 rounded-lg flex items-center justify-center mx-auto mb-3">
                      <stat.icon className="w-6 h-6 text-red-400" />
                    </div>
                    <div className="text-2xl font-bold text-red-400 mb-1">{stat.number}</div>
                    <div className="text-zinc-400 text-sm">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>

            <div className="scroll-fade">
              {/* Problem Visualization */}
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-br from-red-500/20 to-orange-500/20 blur-3xl rounded-full"></div>
                <div className="relative bg-zinc-900 border border-zinc-800 rounded-2xl p-8">
                  <H3 className="text-white mb-6 text-center">Your Typical Day</H3>
                  <div className="space-y-4">
                    {[
                      { time: "8 AM", task: "Check emails (47 unread)", mood: "😐" },
                      { time: "10 AM", task: "Create invoice #847", mood: "😑" },
                      { time: "12 PM", task: "Follow up on payments", mood: "😤" },
                      { time: "2 PM", task: "Organize files (again)", mood: "😫" },
                      { time: "4 PM", task: "Actually create content", mood: "😮‍💨" },
                      { time: "6 PM", task: "More admin work", mood: "😵" }
                    ].map((item, index) => (
                      <div key={index} className="flex items-center gap-4 p-3 bg-zinc-800/50 rounded-lg">
                        <span className="text-zinc-400 text-sm w-16">{item.time}</span>
                        <span className="text-zinc-300 flex-1">{item.task}</span>
                        <span className="text-2xl">{item.mood}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Section 2: The Solution Reveal */}
      <div className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-red-950/20 to-green-950/20">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16 scroll-fade">
              <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-2 w-fit mx-auto mb-6">
                <span className="text-green-400 text-sm font-medium">Chapter 2: The Plot Twist</span>
              </div>
              <H2 className="text-white mb-6">
                What If There Was Another Way?
              </H2>
              <Body className="text-zinc-300 text-lg max-w-2xl mx-auto">
                Imagine if all that admin work just... disappeared. Here's your new reality.
              </Body>
            </div>

            {/* Before vs After Split */}
            <div className="grid lg:grid-cols-2 gap-12">
              {/* Before */}
              <div className="scroll-fade">
                <div className="bg-red-500/5 border border-red-500/20 rounded-xl p-8">
                  <H3 className="text-red-400 mb-6 text-center">Before Jungl</H3>
                  <div className="space-y-4">
                    {[
                      "Spending hours on invoices and tracking",
                      "Missing payment deadlines and follow-ups", 
                      "Juggling spreadsheets and scattered files",
                      "Saying no to opportunities due to admin overload",
                      "Burning out from business tasks instead of creating"
                    ].map((item, index) => (
                      <div key={index} className="flex items-start gap-3">
                        <div className="w-2 h-2 bg-red-400 rounded-full mt-2 shrink-0"></div>
                        <span className="text-zinc-300">{item}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* After */}
              <div className="scroll-fade" style={{ animationDelay: '300ms' }}>
                <div className="bg-green-500/5 border border-green-500/20 rounded-xl p-8">
                  <H3 className="text-green-400 mb-6 text-center">With Jungl</H3>
                  <div className="space-y-4">
                    {[
                      "Automatic invoicing and payment tracking",
                      "Perfect brand opportunities delivered daily",
                      "Seamless team collaboration and file sharing", 
                      "90% more time for actual content creation",
                      "Scaling your business while staying sane"
                    ].map((item, index) => (
                      <div key={index} className="flex items-start gap-3">
                        <div className="w-2 h-2 bg-green-400 rounded-full mt-2 shrink-0"></div>
                        <span className="text-zinc-300">{item}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Tools Preview */}
            <div className="grid md:grid-cols-3 gap-8 mt-16">
              {[
                {
                  icon: CreditCard,
                  title: "Finance Autopilot",
                  description: "Never touch a spreadsheet again",
                  gradient: "from-blue-500/20 to-cyan-500/20"
                },
                {
                  icon: Briefcase,
                  title: "Smart Matching",
                  description: "Perfect brands find you automatically",
                  gradient: "from-purple-500/20 to-pink-500/20"
                },
                {
                  icon: Users,
                  title: "Team Harmony",
                  description: "Collaboration without the chaos",
                  gradient: "from-green-500/20 to-emerald-500/20"
                }
              ].map((tool, index) => (
                <div 
                  key={index} 
                  className="scroll-fade group cursor-pointer"
                  style={{ animationDelay: `${index * 200}ms` }}
                >
                  <div className={`bg-gradient-to-br ${tool.gradient} border border-white/10 rounded-xl p-6 hover:scale-105 transition-all duration-300`}>
                    <tool.icon className="w-12 h-12 text-white mb-4 group-hover:scale-110 transition-transform" />
                    <H3 className="text-white mb-3">{tool.title}</H3>
                    <Body className="text-zinc-300">{tool.description}</Body>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      
      {/* Section 3: How It Works */}
      <div className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-green-950/20 to-blue-950/20">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-16 scroll-fade">
              <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-2 w-fit mx-auto mb-6">
                <span className="text-blue-400 text-sm font-medium">Chapter 3: The How</span>
              </div>
              <H2 className="text-white mb-6">
                Your Transformation
              </H2>
              <Body className="text-zinc-300 text-lg max-w-2xl mx-auto">
                Three steps. Two minutes. One life-changing decision.
              </Body>
            </div>

            {/* Vertical Timeline */}
            <div className="relative">
              {[
                {
                  step: "01",
                  title: "Connect & Forget",
                  description: "Link your accounts once. Jungl handles everything forever.",
                  icon: Link,
                  detail: "2-minute setup that saves 20+ hours per week",
                  circleClass: "bg-blue-500/20 border-blue-500/40",
                  iconClass: "text-blue-400"
                },
                {
                  step: "02", 
                  title: "Create Without Limits",
                  description: "Focus on content. Jungl tracks mentions, creates invoices, chases payments.",
                  icon: Zap,
                  detail: "Your creativity unleashed, admin work eliminated",
                  circleClass: "bg-purple-500/20 border-purple-500/40",
                  iconClass: "text-purple-400"
                },
                {
                  step: "03",
                  title: "Scale & Succeed",
                  description: "Watch your income grow while your stress disappears.",
                  icon: TrendingUp,
                  detail: "Sustainable growth without the burnout",
                  circleClass: "bg-green-500/20 border-green-500/40",
                  iconClass: "text-green-400"
                }
              ].map((step, index) => (
                <div key={index} className="relative flex items-center mb-16 last:mb-0">
                  {/* Timeline Line */}
                  {index < 2 && (
                    <div className="absolute left-8 top-16 w-0.5 h-16 bg-gradient-to-b from-white/40 to-transparent"></div>
                  )}
                  
                  <div className="scroll-fade flex items-start gap-8 w-full" style={{ animationDelay: `${index * 400}ms` }}>
                    {/* Step Circle */}
                    <div className={`w-16 h-16 ${step.circleClass} border-2 rounded-full flex items-center justify-center shrink-0`}>
                      <step.icon className={`w-8 h-8 ${step.iconClass}`} />
                    </div>
                    
                    {/* Content */}
                    <div className="flex-1">
                      <div className="flex items-center gap-4 mb-3">
                        <span className="text-3xl font-bold text-white font-khinterference">{step.step}</span>
                        <H3 className="text-white">{step.title}</H3>
                      </div>
                      <Body className="text-zinc-300 mb-3">{step.description}</Body>
                      <Body className="text-zinc-500 italic">{step.detail}</Body>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      
      {/* Section 4: The Proof */}
      <div className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-blue-950/20 to-black">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-16 scroll-fade">
              <div className="bg-purple-500/10 border border-purple-500/20 rounded-lg p-2 w-fit mx-auto mb-6">
                <span className="text-purple-400 text-sm font-medium">Chapter 4: The Proof</span>
              </div>
              <H2 className="text-white mb-6">
                See Your Future
              </H2>
              <Body className="text-zinc-300 text-lg max-w-2xl mx-auto mb-12">
                This 15-second glimpse shows what your new reality looks like
              </Body>
            </div>

            {/* Video with Enhanced Presentation */}
            <div className="relative mb-16 scroll-fade">
              <div className="absolute -inset-8 bg-gradient-to-r from-purple-500/20 via-blue-500/20 to-green-500/20 blur-2xl rounded-full"></div>
              <div className="relative">
                <div className="max-w-sm mx-auto">
                  <div className="relative bg-zinc-900 rounded-3xl overflow-hidden shadow-2xl border-2 border-white/10 aspect-[9/19]">
                    <video
                      ref={videoRef}
                      className="w-full h-full object-cover rounded-3xl"
                      loop
                      muted
                      playsInline
                      onPlay={() => setIsPlaying(true)}
                      onPause={() => setIsPlaying(false)}
                      poster="/video-placeholder.jpg"
                    >
                      <source src="/video-placeholder.jpg" type="video/mp4" />
                    </video>
                    
                    <button
                      onClick={togglePlay}
                      className="absolute inset-0 flex items-center justify-center bg-black/30 hover:bg-black/40 transition-all duration-200 group rounded-3xl"
                    >
                      <div className="bg-white/15 backdrop-blur-md border border-white/30 rounded-full p-6 group-hover:bg-white/25 transition-all duration-200 group-hover:scale-110">
                        {isPlaying ? (
                          <Pause className="w-8 h-8 text-white" />
                        ) : (
                          <Play className="w-8 h-8 text-white ml-1" />
                        )}
                      </div>
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Final Impact Statement */}
            <div className="text-center space-y-8 scroll-fade">
              <div className="bg-gradient-to-r from-zinc-900 via-zinc-800 to-zinc-900 border border-zinc-700 rounded-2xl p-8 max-w-2xl mx-auto">
                <H3 className="text-white mb-6">The Happy Ending</H3>
                <Body className="text-zinc-300 text-lg leading-relaxed mb-6">
                  You wake up excited to create. Your income is predictable. Your team runs smoothly. 
                  Your biggest problem is deciding which amazing opportunity to accept.
                </Body>
                
                {/* Success Metrics */}
                <div className="grid grid-cols-3 gap-6 mb-6">
                  {[
                    { metric: "90%", label: "Less Admin" },
                    { metric: "3x", label: "Better Deals" },
                    { metric: "∞", label: "More Joy" }
                  ].map((item, index) => (
                    <div key={index} className="text-center">
                      <div className="text-3xl font-bold bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent mb-2">
                        {item.metric}
                      </div>
                      <div className="text-zinc-400 text-sm">{item.label}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Call to Action */}
              <div>
                <Body className="text-zinc-300 mb-8 text-lg">
                  Ready to rewrite your story?
                </Body>
                <div className="flex flex-row gap-4 justify-center items-center">
                  <a 
                    href="https://apps.apple.com/dk/app/jungl-creator-business-hub/id6741893457" 
                    className="block transition-transform hover:scale-105" 
                    target="_blank" 
                    rel="noopener noreferrer"
                  >
                    <img 
                      src="https://ehfsfqmzmrwzlgnbpyzz.supabase.co/storage/v1/object/public/assets//2.svg" 
                      alt="Download Jungl on the App Store" 
                      className="h-14 w-auto"
                    />
                  </a>
                  <a 
                    href="#" 
                    className="block transition-transform hover:scale-105" 
                    target="_blank" 
                    rel="noopener noreferrer"
                  >
                    <img 
                      src="https://ehfsfqmzmrwzlgnbpyzz.supabase.co/storage/v1/object/public/assets//1.svg" 
                      alt="Get Jungl on Google Play" 
                      className="h-14 w-auto"
                    />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
    </div>
  );
};

export default ProgressiveStoryFlow52;