import { H2, H3, Body } from "@/components/Typography";
import { Play, Pause, CreditCard, Briefcase, Users, Link, Zap, TrendingUp, ArrowRight, MousePointer, Eye } from "lucide-react";
import { useState, useRef, useEffect } from "react";
import React from "react";

const ScrollDrivenExperience = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);
  const [activeFeature, setActiveFeature] = useState(0);
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  // Track scroll progress and change active feature
  useEffect(() => {
    const handleScroll = () => {
      if (containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect();
        const progress = Math.max(0, Math.min(1, -rect.top / (rect.height - window.innerHeight)));
        setScrollProgress(progress);
        
        // Change active feature based on scroll
        if (progress < 0.33) setActiveFeature(0);
        else if (progress < 0.66) setActiveFeature(1);
        else setActiveFeature(2);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const features = [
    {
      icon: CreditCard,
      title: "Finance Revolution",
      subtitle: "From chaos to control",
      description: "Watch invoices create themselves. See payments flow automatically. Experience the joy of never touching a spreadsheet again.",
      stats: { before: "40hrs/week", after: "2hrs/week", improvement: "95% reduction" },
      gradient: "from-blue-600 to-cyan-400"
    },
    {
      icon: Briefcase,
      title: "Opportunity Engine",
      subtitle: "Perfect matches, delivered",
      description: "Stop hunting for brands. Let AI find the perfect partnerships that align with your audience and values.",
      stats: { before: "$2k avg deal", after: "$8k avg deal", improvement: "4x value increase" },
      gradient: "from-purple-600 to-pink-400"
    },
    {
      icon: Users,
      title: "Team Synchrony",
      subtitle: "Collaboration reimagined",
      description: "Your team moves as one. Files sync seamlessly. Deadlines become suggestions because everything happens ahead of schedule.",
      stats: { before: "3 days turnaround", after: "Same day delivery", improvement: "10x faster" },
      gradient: "from-green-600 to-emerald-400"
    }
  ];

  return (
    <div ref={containerRef} className="bg-black">
      {/* Simple Hero */}
      <div className="min-h-screen flex items-center justify-center px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <div className="scroll-fade">
            <H2 className="text-white mb-6 text-4xl leading-tight">
              Scroll to Explore
            </H2>
            <Body className="text-zinc-300 text-lg max-w-2xl mx-auto mb-12">
              Three powerful tools that transform your creator business
            </Body>
          </div>
        </div>
      </div>

      {/* Scroll-Driven Features */}
      <div className="min-h-[300vh] relative">
        {/* Sticky Video Container */}
        <div className="sticky top-0 h-screen flex items-center">
          <div className="w-full grid lg:grid-cols-2 gap-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
            
            {/* Left: Content */}
            <div className="flex flex-col justify-center">
              <div className="transition-all duration-700 ease-out">
                <div className="mb-8">
                  <div className={`inline-flex items-center gap-3 p-4 rounded-2xl bg-gradient-to-r ${features[activeFeature].gradient} mb-6`}>
                    {React.createElement(features[activeFeature].icon, { className: "w-8 h-8 text-white" })}
                    <div>
                      <H3 className="text-white">{features[activeFeature].title}</H3>
                      <Body className="text-white/80 text-sm">{features[activeFeature].subtitle}</Body>
                    </div>
                  </div>
                </div>

                <Body className="text-zinc-300 text-lg mb-8 leading-relaxed">
                  {features[activeFeature].description}
                </Body>

                {/* Before/After Stats */}
                <div className="grid grid-cols-3 gap-4 mb-8">
                  <div className="text-center p-4 bg-red-500/10 border border-red-500/20 rounded-lg">
                    <div className="text-red-400 font-bold text-lg">{features[activeFeature].stats.before}</div>
                    <div className="text-red-300 text-sm">Before</div>
                  </div>
                  <div className="flex items-center justify-center">
                    <ArrowRight className="w-6 h-6 text-zinc-400" />
                  </div>
                  <div className="text-center p-4 bg-green-500/10 border border-green-500/20 rounded-lg">
                    <div className="text-green-400 font-bold text-lg">{features[activeFeature].stats.after}</div>
                    <div className="text-green-300 text-sm">With Jungl</div>
                  </div>
                </div>

                <div className="text-center p-4 bg-gradient-to-r from-zinc-900 to-zinc-800 rounded-lg border border-zinc-700">
                  <div className="text-white font-bold text-xl">{features[activeFeature].stats.improvement}</div>
                  <div className="text-zinc-400 text-sm">Impact on your business</div>
                </div>
              </div>
            </div>

            {/* Right: Video */}
            <div className="flex flex-col justify-center">
              <div className="relative max-w-sm mx-auto w-full">
                <div className={`absolute -inset-6 bg-gradient-to-r ${features[activeFeature].gradient} opacity-20 blur-2xl rounded-full transition-all duration-700`}></div>
                <div className="relative bg-zinc-900 rounded-3xl overflow-hidden shadow-2xl border-2 border-white/10 aspect-[9/19]">
                  <video
                    ref={videoRef}
                    className="w-full h-full object-cover rounded-3xl"
                    loop
                    muted
                    playsInline
                    onPlay={() => setIsPlaying(true)}
                    onPause={() => setIsPlaying(false)}
                    poster="/video-placeholder.jpg"
                  >
                    <source src="/video-placeholder.jpg" type="video/mp4" />
                  </video>
                  
                  <button
                    onClick={togglePlay}
                    className="absolute inset-0 flex items-center justify-center bg-black/20 hover:bg-black/30 transition-all duration-200 group rounded-3xl"
                  >
                    <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-full p-4 group-hover:bg-white/20 transition-all duration-200 group-hover:scale-110">
                      {isPlaying ? (
                        <Pause className="w-6 h-6 text-white" />
                      ) : (
                        <Play className="w-6 h-6 text-white ml-0.5" />
                      )}
                    </div>
                  </button>
                </div>
              </div>

              {/* Feature Progress Dots */}
              <div className="flex justify-center gap-2 mt-8">
                {features.map((_, index) => (
                  <div
                    key={index}
                    className={`w-3 h-3 rounded-full transition-all duration-300 ${
                      index === activeFeature ? 'bg-white' : 'bg-zinc-700'
                    }`}
                  ></div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Final CTA */}
      <div className="py-20 px-4 sm:px-6 lg:px-8 text-center bg-gradient-to-t from-zinc-950 to-black">
        <div className="max-w-4xl mx-auto scroll-fade">
          <div className="mb-12">
            <Eye className="w-12 h-12 text-white mx-auto mb-6" />
            <H2 className="text-white mb-6">
              Now You've Seen It
            </H2>
            <Body className="text-zinc-300 text-lg max-w-2xl mx-auto mb-8">
              The question isn't whether Jungl works. You just watched it transform everything. 
              The question is: are you ready for your transformation?
            </Body>
          </div>

          {/* App Store Buttons */}
          <div className="flex flex-row gap-4 justify-center items-center">
            <a 
              href="https://apps.apple.com/dk/app/jungl-creator-business-hub/id6741893457" 
              className="block transition-transform hover:scale-105" 
              target="_blank" 
              rel="noopener noreferrer"
            >
              <img 
                src="https://ehfsfqmzmrwzlgnbpyzz.supabase.co/storage/v1/object/public/assets//2.svg" 
                alt="Download Jungl on the App Store" 
                className="h-14 w-auto"
              />
            </a>
            <a 
              href="#" 
              className="block transition-transform hover:scale-105" 
              target="_blank" 
              rel="noopener noreferrer"
            >
              <img 
                src="https://ehfsfqmzmrwzlgnbpyzz.supabase.co/storage/v1/object/public/assets//1.svg" 
                alt="Get Jungl on Google Play" 
                className="h-14 w-auto"
              />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ScrollDrivenExperience;