import { H2, H3, Body } from "@/components/Typography";
import { Play, Pause, CreditCard, Briefcase, Users, Link, Zap, TrendingUp } from "lucide-react";
import { useState, useRef } from "react";

const TabbedDemoCenter = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [activeTab, setActiveTab] = useState(0);
  const videoRef = useRef<HTMLVideoElement>(null);

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const tabs = [
    {
      id: "demo",
      label: "See It in Action",
      icon: Play,
      content: {
        title: "How Jungl Works",
        subtitle: "AI-powered workflows made for creators",
        description: "Watch a 15-second demo of Jungl streamlining your creator workflow from setup to cash-out."
      }
    },
    {
      id: "process",
      label: "How It Works", 
      icon: Zap,
      content: {
        title: "Simple 3-Step Process",
        subtitle: "From setup to scale in minutes",
        steps: [
          {
            number: "01",
            title: "Connect",
            description: "Link your socials & payment method in < 2 min.",
            icon: Link
          },
          {
            number: "02", 
            title: "Create",
            description: "Keep posting; Jungl tracks your brand mentions & converts them to invoices.",
            icon: Zap
          },
          {
            number: "03",
            title: "Cash-out",
            description: "Get paid, export tax-ready reports, and climb the leaderboard for bigger deals.",
            icon: TrendingUp
          }
        ]
      }
    },
    {
      id: "features",
      label: "What You Get",
      icon: CreditCard,
      content: {
        title: "Your Command Center",
        subtitle: "Everything you need in one place",
        features: [
          {
            icon: CreditCard,
            title: "Finance Hub",
            description: "One-click invoices, automated reminders, multi-currency payouts, and real-time earnings dashboard."
          },
          {
            icon: Briefcase,
            title: "Smart Jobs",
            description: "Curated brand briefs that actually match your audience. Accept offers or counter in a tap."
          },
          {
            icon: Users,
            title: "Team Collaboration",
            description: "Secure file-sharing, shared calendars, and role-based access for agents & editors."
          }
        ]
      }
    }
  ];

  return (
    <div className="py-16 sm:py-20 lg:py-24 px-4 sm:px-6 lg:px-8 bg-black">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16 scroll-fade">
          <H2 className="text-white mb-6">
            Everything You Need to Know
          </H2>
          <Body className="text-zinc-300 text-lg max-w-2xl mx-auto">
            Discover how Jungl transforms your creator business
          </Body>
        </div>

        {/* Tab Navigation */}
        <div className="flex flex-wrap gap-2 justify-center mb-12 scroll-fade">
          {tabs.map((tab, index) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(index)}
              className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-all duration-300 ${
                activeTab === index
                  ? 'bg-white text-black'
                  : 'bg-zinc-800 text-zinc-300 hover:bg-zinc-700'
              }`}
            >
              <tab.icon className="h-4 w-4" />
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Video - Always Visible */}
          <div className="scroll-fade order-2 lg:order-1">
            <div className="text-center">
              <div className="relative max-w-sm mx-auto mb-8">
                <div className="relative bg-zinc-900 rounded-3xl overflow-hidden shadow-2xl border border-zinc-800 aspect-[9/19]">
                  <video
                    ref={videoRef}
                    className="w-full h-full object-cover rounded-3xl"
                    loop
                    muted
                    playsInline
                    onPlay={() => setIsPlaying(true)}
                    onPause={() => setIsPlaying(false)}
                    poster="/lovable-uploads/56495540-5978-42a9-b48e-d0df60b46803.png"
                  >
                    <source src="#" type="video/mp4" />
                  </video>
                  
                  <button
                    onClick={togglePlay}
                    className="absolute inset-0 flex items-center justify-center bg-black/20 hover:bg-black/30 transition-all duration-200 group rounded-3xl"
                  >
                    <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-full p-3 group-hover:bg-white/20 transition-all duration-200">
                      {isPlaying ? (
                        <Pause className="w-6 h-6 text-white" />
                      ) : (
                        <Play className="w-6 h-6 text-white ml-0.5" />
                      )}
                    </div>
                  </button>
                </div>
              </div>

              {/* App Store Buttons */}
              <div className="flex flex-row gap-4 justify-center items-center">
                <a 
                  href="https://apps.apple.com/dk/app/jungl-creator-business-hub/id6741893457" 
                  className="block transition-opacity hover:opacity-80" 
                  target="_blank" 
                  rel="noopener noreferrer"
                >
                  <img 
                    src="https://ehfsfqmzmrwzlgnbpyzz.supabase.co/storage/v1/object/public/assets//2.svg" 
                    alt="Download Jungl on the App Store" 
                    className="h-12 w-auto"
                  />
                </a>
                <a 
                  href="#" 
                  className="block transition-opacity hover:opacity-80" 
                  target="_blank" 
                  rel="noopener noreferrer"
                >
                  <img 
                    src="https://ehfsfqmzmrwzlgnbpyzz.supabase.co/storage/v1/object/public/assets//1.svg" 
                    alt="Get Jungl on Google Play" 
                    className="h-12 w-auto"
                  />
                </a>
              </div>
            </div>
          </div>

          {/* Dynamic Content */}
          <div className="scroll-fade order-1 lg:order-2">
            <div className="animate-fade-in" key={activeTab}>
              <H2 className="text-white mb-4">
                {tabs[activeTab].content.title}
              </H2>
              <Body className="text-zinc-300 text-lg mb-8">
                {tabs[activeTab].content.subtitle}
              </Body>

              {/* Demo Tab Content */}
              {activeTab === 0 && (
                <div className="space-y-6">
                  <Body className="text-zinc-300">
                    {tabs[activeTab].content.description}
                  </Body>
                  <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-lg">
                    <Body className="text-zinc-400 text-sm">
                      <strong className="text-white">Try it now:</strong> Download the app and see how Jungl can transform your creator business in just 2 minutes.
                    </Body>
                  </div>
                </div>
              )}

              {/* Process Tab Content */}
              {activeTab === 1 && (
                <div className="space-y-6">
                  {tabs[activeTab].content.steps.map((step, index) => (
                    <div key={index} className="flex items-start gap-4">
                      <div className="relative shrink-0">
                        <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center">
                          <step.icon className="h-6 w-6 text-black" />
                        </div>
                        <div className="absolute -top-2 -right-2 w-6 h-6 bg-white text-black rounded-full flex items-center justify-center text-xs font-bold font-khinterference">
                          {index + 1}
                        </div>
                      </div>
                      <div>
                        <H3 className="text-white mb-2">{step.title}</H3>
                        <Body className="text-zinc-300">{step.description}</Body>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Features Tab Content */}
              {activeTab === 2 && (
                <div className="space-y-6">
                  {tabs[activeTab].content.features.map((feature, index) => (
                    <div key={index} className="bg-zinc-900 border border-zinc-800 p-6 rounded-lg">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 bg-white/10 rounded-lg flex items-center justify-center shrink-0">
                          <feature.icon className="h-6 w-6 text-white" />
                        </div>
                        <div>
                          <H3 className="text-white mb-3">{feature.title}</H3>
                          <Body className="text-zinc-300">{feature.description}</Body>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TabbedDemoCenter;