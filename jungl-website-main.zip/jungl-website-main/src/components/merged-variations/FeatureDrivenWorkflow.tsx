import { H2, H3, Body } from "@/components/Typography";
import { Play, Pause, CreditCard, Briefcase, Users, Link, Zap, TrendingUp, ChevronRight } from "lucide-react";
import { useState, useRef } from "react";

const FeatureDrivenWorkflow = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [activeFeature, setActiveFeature] = useState(0);
  const videoRef = useRef<HTMLVideoElement>(null);

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const features = [
    {
      icon: CreditCard,
      title: "Finance Hub",
      description: "One-click invoices, automated reminders, multi-currency payouts, and real-time earnings dashboard.",
      workflow: [
        { step: "Connect", detail: "Link your payment method in < 2 min", icon: Link },
        { step: "Auto-Track", detail: "Jungl converts brand mentions to invoices", icon: Zap },
        { step: "Get Paid", detail: "Export tax-ready reports & cash out", icon: TrendingUp }
      ]
    },
    {
      icon: Briefcase,
      title: "Smart Jobs",
      description: "Curated brand briefs that actually match your audience. Accept offers or counter in a tap.",
      workflow: [
        { step: "Get Matched", detail: "AI finds relevant brand opportunities", icon: Link },
        { step: "Quick Decision", detail: "Accept offers or counter with one tap", icon: Zap },
        { step: "Track Success", detail: "Monitor performance & climb leaderboards", icon: TrendingUp }
      ]
    },
    {
      icon: Users,
      title: "Team Collaboration",
      description: "Secure file-sharing, shared calendars, and role-based access for agents & editors.",
      workflow: [
        { step: "Invite Team", detail: "Add agents, editors with role-based access", icon: Link },
        { step: "Collaborate", detail: "Share files, sync calendars seamlessly", icon: Zap },
        { step: "Scale Together", detail: "Grow your creator business as a team", icon: TrendingUp }
      ]
    }
  ];

  return (
    <div className="py-16 sm:py-20 lg:py-24 px-4 sm:px-6 lg:px-8 bg-black">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16 scroll-fade">
          <H2 className="text-white mb-6">
            Powerful Features, Simple Workflow
          </H2>
          <Body className="text-zinc-300 text-lg max-w-2xl mx-auto">
            Click any feature to see how it works in your creator journey
          </Body>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Features Grid */}
          <div className="space-y-6">
            {features.map((feature, index) => (
              <div
                key={index}
                className={`scroll-fade bg-zinc-900 border rounded-lg p-6 cursor-pointer transition-all duration-300 ${
                  activeFeature === index 
                    ? 'border-white bg-zinc-800 scale-[1.02]' 
                    : 'border-zinc-800 hover:bg-zinc-800'
                }`}
                style={{ animationDelay: `${index * 100}ms` }}
                onClick={() => setActiveFeature(index)}
              >
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-white/10 rounded-lg flex items-center justify-center shrink-0">
                    <feature.icon className="h-6 w-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <H3 className="text-white">{feature.title}</H3>
                      <ChevronRight className={`w-5 h-5 text-zinc-400 transition-transform ${
                        activeFeature === index ? 'rotate-90' : ''
                      }`} />
                    </div>
                    <Body className="text-zinc-300 text-sm">{feature.description}</Body>
                    
                    {/* Workflow Steps (expanded when active) */}
                    {activeFeature === index && (
                      <div className="mt-6 space-y-3 animate-fade-in">
                        {feature.workflow.map((step, stepIndex) => (
                          <div key={stepIndex} className="flex items-center gap-3 bg-zinc-800 p-3 rounded-lg">
                            <div className="w-8 h-8 bg-white/5 rounded-full flex items-center justify-center">
                              <step.icon className="h-4 w-4 text-white" />
                            </div>
                            <div>
                              <div className="text-white font-medium text-sm">{step.step}</div>
                              <div className="text-zinc-400 text-xs">{step.detail}</div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Demo Video */}
          <div className="scroll-fade lg:sticky lg:top-8" style={{ animationDelay: '300ms' }}>
            <div className="text-center">
              <H3 className="text-white mb-4">See It In Action</H3>
              <Body className="text-zinc-300 mb-8">
                Watch how {features[activeFeature].title.toLowerCase()} streamlines your workflow
              </Body>
              
              <div className="relative max-w-sm mx-auto mb-8">
                <div className="relative bg-zinc-900 rounded-3xl overflow-hidden shadow-2xl border border-zinc-800 aspect-[9/19]">
                  <video
                    ref={videoRef}
                    className="w-full h-full object-cover rounded-3xl"
                    loop
                    muted
                    playsInline
                    onPlay={() => setIsPlaying(true)}
                    onPause={() => setIsPlaying(false)}
                    poster="/lovable-uploads/56495540-5978-42a9-b48e-d0df60b46803.png"
                  >
                    <source src="#" type="video/mp4" />
                  </video>
                  
                  <button
                    onClick={togglePlay}
                    className="absolute inset-0 flex items-center justify-center bg-black/20 hover:bg-black/30 transition-all duration-200 group rounded-3xl"
                  >
                    <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-full p-3 group-hover:bg-white/20 transition-all duration-200">
                      {isPlaying ? (
                        <Pause className="w-6 h-6 text-white" />
                      ) : (
                        <Play className="w-6 h-6 text-white ml-0.5" />
                      )}
                    </div>
                  </button>
                </div>
              </div>

              {/* App Store Buttons */}
              <div className="flex flex-row gap-4 justify-center items-center">
                <a 
                  href="https://apps.apple.com/dk/app/jungl-creator-business-hub/id6741893457" 
                  className="block transition-opacity hover:opacity-80" 
                  target="_blank" 
                  rel="noopener noreferrer"
                >
                  <img 
                    src="https://ehfsfqmzmrwzlgnbpyzz.supabase.co/storage/v1/object/public/assets//2.svg" 
                    alt="Download Jungl on the App Store" 
                    className="h-12 w-auto"
                  />
                </a>
                <a 
                  href="#" 
                  className="block transition-opacity hover:opacity-80" 
                  target="_blank" 
                  rel="noopener noreferrer"
                >
                  <img 
                    src="https://ehfsfqmzmrwzlgnbpyzz.supabase.co/storage/v1/object/public/assets//1.svg" 
                    alt="Get Jungl on Google Play" 
                    className="h-12 w-auto"
                  />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FeatureDrivenWorkflow;