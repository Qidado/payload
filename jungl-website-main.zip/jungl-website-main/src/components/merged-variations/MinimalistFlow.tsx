import { H2, H3, Body } from "@/components/Typography";
import { Play, Pause, ArrowDown, Sparkles } from "lucide-react";
import { useState, useRef } from "react";

const MinimalistFlow = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentView, setCurrentView] = useState(0);
  const videoRef = useRef<HTMLVideoElement>(null);

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const views = [
    {
      title: "Today",
      subtitle: "Your current reality",
      content: {
        time: "Monday Morning",
        tasks: [
          { task: "Check 47 unread emails", time: "30 min", stress: "high" },
          { task: "Create invoice #847", time: "25 min", stress: "high" },
          { task: "Follow up on payments", time: "45 min", stress: "high" },
          { task: "Organize scattered files", time: "35 min", stress: "high" },
          { task: "Actually create content", time: "45 min", stress: "medium" },
          { task: "More admin work", time: "60+ min", stress: "high" }
        ],
        total: "4+ hours of admin hell"
      }
    },
    {
      title: "Tomorrow",
      subtitle: "With Jungl",
      content: {
        time: "Monday Morning",
        tasks: [
          { task: "Check Jungl dashboard", time: "2 min", stress: "none" },
          { task: "Review auto-generated reports", time: "3 min", stress: "none" },
          { task: "Approve perfect brand match", time: "1 min", stress: "none" },
          { task: "Create amazing content", time: "4+ hours", stress: "joy" },
          { task: "Everything else handled automatically", time: "0 min", stress: "none" }
        ],
        total: "6 minutes of admin, 4+ hours of creativity"
      }
    }
  ];

  const stressColors = {
    high: "text-red-400 bg-red-500/10",
    medium: "text-yellow-400 bg-yellow-500/10", 
    none: "text-green-400 bg-green-500/10",
    joy: "text-blue-400 bg-blue-500/10"
  };

  return (
    <div className="bg-black min-h-screen">
      {/* Hero */}
      <div className="min-h-screen flex items-center justify-center px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mx-auto text-center">
          <div className="scroll-fade">
            <div className="w-1 h-20 bg-gradient-to-b from-transparent via-white to-transparent mx-auto mb-8"></div>
            <H2 className="text-white mb-8 leading-tight text-4xl lg:text-6xl font-light">
              Before<br />
              <span className="text-zinc-500">&</span><br />
              After
            </H2>
            <Body className="text-zinc-400 text-lg mb-12 max-w-md mx-auto">
              A simple comparison that changes everything
            </Body>
            <ArrowDown className="w-6 h-6 text-zinc-500 mx-auto animate-bounce" />
          </div>
        </div>
      </div>

      {/* Comparison Views */}
      <div className="min-h-screen flex items-center justify-center px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto w-full">
          
          {/* View Toggle */}
          <div className="flex justify-center mb-16 scroll-fade">
            <div className="bg-zinc-900 p-1 rounded-full border border-zinc-800">
              {views.map((view, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentView(index)}
                  className={`px-8 py-3 rounded-full text-sm font-medium transition-all duration-300 ${
                    currentView === index
                      ? 'bg-white text-black'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  {view.title}
                </button>
              ))}
            </div>
          </div>

          {/* Content */}
          <div className="relative">
            {views.map((view, index) => (
              <div
                key={index}
                className={`transition-all duration-700 ${
                  currentView === index
                    ? 'opacity-100 translate-y-0'
                    : 'opacity-0 translate-y-8 absolute inset-0 pointer-events-none'
                }`}
              >
                <div className="text-center mb-12">
                  <H2 className="text-white mb-4 text-3xl">{view.title}</H2>
                  <Body className="text-zinc-400 text-lg">{view.subtitle}</Body>
                </div>

                {/* Daily Schedule */}
                <div className="max-w-2xl mx-auto">
                  <div className="bg-zinc-950 border border-zinc-800 rounded-2xl p-8">
                    <div className="text-center mb-8">
                      <div className="text-white font-medium text-lg">{view.content.time}</div>
                    </div>

                    <div className="space-y-4 mb-8">
                      {view.content.tasks.map((item, taskIndex) => (
                        <div key={taskIndex} className="flex items-center justify-between p-4 bg-zinc-900/50 rounded-lg">
                          <div className="flex-1">
                            <div className="text-white font-medium">{item.task}</div>
                          </div>
                          <div className="flex items-center gap-4">
                            <div className="text-zinc-400 text-sm min-w-[60px] text-right">{item.time}</div>
                            <div className={`px-3 py-1 rounded-full text-xs font-medium ${stressColors[item.stress as keyof typeof stressColors]}`}>
                              {item.stress === 'none' ? 'Easy' : 
                               item.stress === 'joy' ? 'Fun!' :
                               item.stress === 'medium' ? 'Okay' : 'Stressful'}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="text-center border-t border-zinc-800 pt-6">
                      <div className={`text-lg font-bold ${currentView === 0 ? 'text-red-400' : 'text-green-400'}`}>
                        {view.content.total}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Next Section Hint */}
          {currentView === 1 && (
            <div className="text-center mt-16 scroll-fade">
              <div className="inline-flex items-center gap-2 text-zinc-400">
                <Sparkles className="w-4 h-4" />
                <span className="text-sm">Continue to see how</span>
              </div>
              <ArrowDown className="w-5 h-5 text-zinc-500 mx-auto mt-4 animate-bounce" />
            </div>
          )}
        </div>
      </div>

      {/* How Section - Only show after comparison */}
      {currentView === 1 && (
        <div className="min-h-screen flex items-center justify-center px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center">
            <div className="scroll-fade space-y-16">
              <div>
                <H2 className="text-white mb-8 text-3xl">How?</H2>
                <Body className="text-zinc-400 text-lg mb-12">
                  Three simple steps transform your reality
                </Body>
              </div>

              {/* Simple Steps */}
              <div className="space-y-12">
                {[
                  {
                    number: "01",
                    title: "Connect",
                    description: "2 minutes to link your accounts"
                  },
                  {
                    number: "02", 
                    title: "Create",
                    description: "Focus on content, Jungl handles everything else"
                  },
                  {
                    number: "03",
                    title: "Collect",
                    description: "Money flows, reports generate, stress disappears"
                  }
                ].map((step, index) => (
                  <div key={index} className="flex items-center justify-center gap-8">
                    <div className="text-6xl font-light text-zinc-700 min-w-[100px]">{step.number}</div>
                    <div className="text-left">
                      <H3 className="text-white mb-2">{step.title}</H3>
                      <Body className="text-zinc-400">{step.description}</Body>
                    </div>
                  </div>
                ))}
              </div>

              <ArrowDown className="w-5 h-5 text-zinc-500 mx-auto animate-bounce" />
            </div>
          </div>
        </div>
      )}

      {/* Demo Section */}
      {currentView === 1 && (
        <div className="min-h-screen flex items-center justify-center px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mx-auto text-center">
            <div className="scroll-fade space-y-12">
              <div>
                <H2 className="text-white mb-8 text-3xl">Proof</H2>
                <Body className="text-zinc-400 text-lg mb-12">
                  See the transformation in 15 seconds
                </Body>
              </div>

              {/* Clean Video Presentation */}
              <div className="relative">
                <div className="max-w-xs mx-auto">
                  <div className="relative bg-zinc-950 rounded-3xl overflow-hidden border border-zinc-800 aspect-[9/19]">
                    <video
                      ref={videoRef}
                      className="w-full h-full object-cover rounded-3xl"
                      loop
                      muted
                      playsInline
                      onPlay={() => setIsPlaying(true)}
                      onPause={() => setIsPlaying(false)}
                      poster="/video-placeholder.jpg"
                    >
                      <source src="/video-placeholder.jpg" type="video/mp4" />
                    </video>
                    
                    <button
                      onClick={togglePlay}
                      className="absolute inset-0 flex items-center justify-center bg-black/20 hover:bg-black/30 transition-all duration-200 group rounded-3xl"
                    >
                      <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-full p-4 group-hover:bg-white/20 transition-all duration-200">
                        {isPlaying ? (
                          <Pause className="w-6 h-6 text-white" />
                        ) : (
                          <Play className="w-6 h-6 text-white ml-0.5" />
                        )}
                      </div>
                    </button>
                  </div>
                </div>
              </div>

              {/* Minimal CTA */}
              <div className="space-y-8">
                <div className="w-1 h-12 bg-gradient-to-b from-transparent via-white to-transparent mx-auto"></div>
                
                <Body className="text-zinc-400">
                  Ready for your tomorrow?
                </Body>

                <div className="flex flex-row gap-4 justify-center items-center">
                  <a 
                    href="https://apps.apple.com/dk/app/jungl-creator-business-hub/id6741893457" 
                    className="block transition-opacity hover:opacity-80" 
                    target="_blank" 
                    rel="noopener noreferrer"
                  >
                    <img 
                      src="https://ehfsfqmzmrwzlgnbpyzz.supabase.co/storage/v1/object/public/assets//2.svg" 
                      alt="Download Jungl on the App Store" 
                      className="h-12 w-auto"
                    />
                  </a>
                  <a 
                    href="#" 
                    className="block transition-opacity hover:opacity-80" 
                    target="_blank" 
                    rel="noopener noreferrer"
                  >
                    <img 
                      src="https://ehfsfqmzmrwzlgnbpyzz.supabase.co/storage/v1/object/public/assets//1.svg" 
                      alt="Get Jungl on Google Play" 
                      className="h-12 w-auto"
                    />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MinimalistFlow;