import { H2, H3, Body } from "@/components/Typography";
import { Play, Pause, CreditCard, Briefcase, Users, Link, Zap, TrendingUp } from "lucide-react";
import { useState, useRef, useEffect } from "react";
import React from "react";

const SplitScreenDemo = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentSection, setCurrentSection] = useState(0);
  const videoRef = useRef<HTMLVideoElement>(null);

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const sections = [
    {
      title: "Finance Made Simple",
      subtitle: "Your Command Center",
      icon: CreditCard,
      step: "Connect",
      description: "Link your socials & payment method in < 2 min.",
      feature: "One-click invoices, automated reminders, multi-currency payouts, and real-time earnings dashboard."
    },
    {
      title: "Smart Job Matching", 
      subtitle: "AI-Powered Opportunities",
      icon: Briefcase,
      step: "Create",
      description: "Keep posting; Jungl tracks your brand mentions & converts them to invoices.",
      feature: "Curated brand briefs that actually match your audience. Accept offers or counter in a tap."
    },
    {
      title: "Team Collaboration",
      subtitle: "Scale Together",
      icon: Users,
      step: "Cash-out", 
      description: "Get paid, export tax-ready reports, and climb the leaderboard for bigger deals.",
      feature: "Secure file-sharing, shared calendars, and role-based access for agents & editors."
    }
  ];

  // Auto-rotate content every 4 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSection((prev) => (prev + 1) % sections.length);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-black flex">
      {/* Left Side - Video */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8 lg:p-16">
        <div className="relative max-w-sm w-full">
          <div className="relative bg-zinc-900 rounded-3xl overflow-hidden shadow-2xl border border-zinc-800 aspect-[9/19]">
            <video
              ref={videoRef}
              className="w-full h-full object-cover rounded-3xl"
              loop
              muted
              playsInline
              onPlay={() => setIsPlaying(true)}
              onPause={() => setIsPlaying(false)}
              poster="/lovable-uploads/56495540-5978-42a9-b48e-d0df60b46803.png"
            >
              <source src="#" type="video/mp4" />
            </video>
            
            <button
              onClick={togglePlay}
              className="absolute inset-0 flex items-center justify-center bg-black/20 hover:bg-black/30 transition-all duration-200 group rounded-3xl"
            >
              <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-full p-4 group-hover:bg-white/20 transition-all duration-200">
                {isPlaying ? (
                  <Pause className="w-8 h-8 text-white" />
                ) : (
                  <Play className="w-8 h-8 text-white ml-1" />
                )}
              </div>
            </button>
          </div>
          
          {/* Video Progress Indicators */}
          <div className="flex gap-2 justify-center mt-6">
            {sections.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSection(index)}
                className={`w-12 h-1 rounded-full transition-all duration-300 ${
                  currentSection === index ? 'bg-white' : 'bg-white/30'
                }`}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Right Side - Synchronized Content */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8 lg:p-16">
        <div className="max-w-lg w-full space-y-8">
          {/* Main Header */}
          <div className="scroll-fade">
            <H2 className="text-white mb-4">
              How Jungl Works
            </H2>
            <Body className="text-zinc-300 text-lg">
              AI-powered workflows made for creators
            </Body>
          </div>

          {/* Current Section Content */}
          <div className="space-y-6 animate-fade-in" key={currentSection}>
            {/* Step Number & Icon */}
            <div className="flex items-center gap-4">
              <div className="relative">
                <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center">
                  {React.createElement(sections[currentSection].icon, { className: "h-8 w-8 text-black" })}
                </div>
                <div className="absolute -top-2 -right-2 w-8 h-8 bg-white text-black rounded-full flex items-center justify-center text-sm font-bold font-khinterference">
                  {currentSection + 1}
                </div>
              </div>
              <div>
                <H3 className="text-white">{sections[currentSection].step}</H3>
                <Body className="text-zinc-400 text-sm">{sections[currentSection].subtitle}</Body>
              </div>
            </div>

            {/* Step Description */}
            <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-lg">
              <Body className="text-zinc-300 mb-4">
                {sections[currentSection].description}
              </Body>
              <div className="h-px bg-zinc-800 my-4"></div>
              <Body className="text-zinc-400 text-sm">
                <strong className="text-white">{sections[currentSection].title}:</strong> {sections[currentSection].feature}
              </Body>
            </div>

            {/* Progress Through Steps */}
            <div className="flex gap-3">
              {sections.map((section, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentSection(index)}
                  className={`flex-1 p-3 rounded-lg border transition-all duration-300 ${
                    currentSection === index
                      ? 'border-white bg-white/5 text-white'
                      : 'border-zinc-800 text-zinc-400 hover:border-zinc-600'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    {React.createElement(section.icon, { className: "h-4 w-4" })}
                    <span className="text-sm font-medium">{section.step}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* App Store Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 pt-8">
            <a 
              href="https://apps.apple.com/dk/app/jungl-creator-business-hub/id6741893457" 
              className="block transition-opacity hover:opacity-80" 
              target="_blank" 
              rel="noopener noreferrer"
            >
              <img 
                src="https://ehfsfqmzmrwzlgnbpyzz.supabase.co/storage/v1/object/public/assets//2.svg" 
                alt="Download Jungl on the App Store" 
                className="h-12 w-auto"
              />
            </a>
            <a 
              href="#" 
              className="block transition-opacity hover:opacity-80" 
              target="_blank" 
              rel="noopener noreferrer"
            >
              <img 
                src="https://ehfsfqmzmrwzlgnbpyzz.supabase.co/storage/v1/object/public/assets//1.svg" 
                alt="Get Jungl on Google Play" 
                className="h-12 w-auto"
              />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SplitScreenDemo;