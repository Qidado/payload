import { H2, H3, Body } from "@/components/Typography";
import { Play, Pause, CreditCard, Briefcase, Users, Link, Zap, TrendingUp } from "lucide-react";
import { useState, useRef } from "react";

const InteractiveJourney = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const journeySteps = [
    {
      step: "01",
      title: "Connect Your World",
      description: "Link your socials & payment method in < 2 min.",
      icon: Link,
      solution: {
        icon: CreditCard,
        title: "Finance Hub",
        description: "One-click invoices, automated reminders, multi-currency payouts, and real-time earnings dashboard."
      }
    },
    {
      step: "02", 
      title: "Create & Track Everything",
      description: "Keep posting; Jungl tracks your brand mentions & converts them to invoices.",
      icon: Zap,
      solution: {
        icon: Briefcase,
        title: "Smart Jobs",
        description: "Curated brand briefs that actually match your audience. Accept offers or counter in a tap."
      }
    },
    {
      step: "03",
      title: "Cash-out & Scale",
      description: "Get paid, export tax-ready reports, and climb the leaderboard for bigger deals.",
      icon: TrendingUp,
      solution: {
        icon: Users,
        title: "Team Collaboration",
        description: "Secure file-sharing, shared calendars, and role-based access for agents & editors."
      }
    }
  ];

  return (
    <div className="py-16 sm:py-20 lg:py-24 px-4 sm:px-6 lg:px-8 bg-black">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16 scroll-fade">
          <H2 className="text-white mb-6">
            Your Complete Creator Journey
          </H2>
          <Body className="text-zinc-300 text-lg max-w-2xl mx-auto">
            From setup to scale - see how Jungl transforms your creator business
          </Body>
        </div>

        {/* Interactive Timeline */}
        <div className="relative">
          {/* Timeline Line */}
          <div className="hidden lg:block absolute left-1/2 transform -translate-x-0.5 w-0.5 h-full bg-gradient-to-b from-white/20 via-white/40 to-white/20"></div>
          
          {journeySteps.map((step, index) => (
            <div key={index} className="relative mb-16 lg:mb-24">
              <div className={`flex flex-col lg:flex-row items-center gap-8 ${index % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse'}`}>
                
                {/* Step Content */}
                <div className="flex-1 scroll-fade" style={{ animationDelay: `${index * 200}ms` }}>
                  <div className={`text-center lg:text-${index % 2 === 0 ? 'left' : 'right'}`}>
                    <div className="flex items-center justify-center lg:justify-start gap-4 mb-4">
                      <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center">
                        <step.icon className="h-6 w-6 text-black" />
                      </div>
                      <span className="text-4xl font-bold text-white font-khinterference">{step.step}</span>
                    </div>
                    <H3 className="text-white mb-4">{step.title}</H3>
                    <Body className="text-zinc-300 mb-6">{step.description}</Body>
                    
                    {/* Solution Card */}
                    <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-lg">
                      <div className="flex items-center gap-3 mb-3">
                        <div className="w-8 h-8 bg-white/10 rounded-lg flex items-center justify-center">
                          <step.solution.icon className="h-4 w-4 text-white" />
                        </div>
                        <h4 className="text-white font-semibold">{step.solution.title}</h4>
                      </div>
                      <Body className="text-zinc-400 text-sm">{step.solution.description}</Body>
                    </div>
                  </div>
                </div>

                {/* Center Video (only on middle step) */}
                {index === 1 && (
                  <div className="lg:absolute lg:left-1/2 lg:transform lg:-translate-x-1/2 flex-shrink-0">
                    <div className="relative w-64 h-80 lg:w-48 lg:h-64">
                      <div className="relative bg-zinc-900 rounded-3xl overflow-hidden shadow-2xl border border-zinc-800 w-full h-full">
                        <video
                          ref={videoRef}
                          className="w-full h-full object-cover rounded-3xl"
                          loop
                          muted
                          playsInline
                          onPlay={() => setIsPlaying(true)}
                          onPause={() => setIsPlaying(false)}
                          poster="/lovable-uploads/56495540-5978-42a9-b48e-d0df60b46803.png"
                        >
                          <source src="#" type="video/mp4" />
                        </video>
                        
                        <button
                          onClick={togglePlay}
                          className="absolute inset-0 flex items-center justify-center bg-black/20 hover:bg-black/30 transition-all duration-200 group rounded-3xl"
                        >
                          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-full p-2 group-hover:bg-white/20 transition-all duration-200">
                            {isPlaying ? (
                              <Pause className="w-4 h-4 text-white" />
                            ) : (
                              <Play className="w-4 h-4 text-white ml-0.5" />
                            )}
                          </div>
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* App Store Buttons */}
        <div className="text-center mt-16 scroll-fade">
          <Body className="text-zinc-300 mb-6">Ready to transform your creator business?</Body>
          <div className="flex flex-row gap-4 justify-center items-center">
            <a 
              href="https://apps.apple.com/dk/app/jungl-creator-business-hub/id6741893457" 
              className="block transition-opacity hover:opacity-80" 
              target="_blank" 
              rel="noopener noreferrer"
            >
              <img 
                src="https://ehfsfqmzmrwzlgnbpyzz.supabase.co/storage/v1/object/public/assets//2.svg" 
                alt="Download Jungl on the App Store" 
                className="h-12 w-auto"
              />
            </a>
            <a 
              href="#" 
              className="block transition-opacity hover:opacity-80" 
              target="_blank" 
              rel="noopener noreferrer"
            >
              <img 
                src="https://ehfsfqmzmrwzlgnbpyzz.supabase.co/storage/v1/object/public/assets//1.svg" 
                alt="Get Jungl on Google Play" 
                className="h-12 w-auto"
              />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InteractiveJourney;