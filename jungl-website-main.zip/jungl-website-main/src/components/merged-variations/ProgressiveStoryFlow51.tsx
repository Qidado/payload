import { H2, H3, Body } from "@/components/Typography";
import { Play, Pause, CreditCard, Briefcase, Users, Link, Zap, TrendingUp, ArrowRight, CheckCircle, XCircle } from "lucide-react";
import { useState, useRef } from "react";

const ProgressiveStoryFlow51 = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentChapter, setCurrentChapter] = useState(0);
  const videoRef = useRef<HTMLVideoElement>(null);

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const chapters = [
    {
      title: "The Creator's Reality",
      subtitle: "Why most creators burn out",
      theme: "problem"
    },
    {
      title: "The Jungl Solution", 
      subtitle: "Three tools that change everything",
      theme: "solution"
    },
    {
      title: "Your New Workflow",
      subtitle: "How it actually works",
      theme: "process"
    },
    {
      title: "See It Live",
      subtitle: "Watch the transformation",
      theme: "demo"
    }
  ];

  return (
    <div className="bg-black">
      {/* Simple Navigation */}
      <div className="py-8 px-4 sm:px-6 lg:px-8 bg-zinc-950">
        <div className="max-w-4xl mx-auto text-center">
          <div className="flex gap-2 justify-center mb-6">
            {chapters.map((chapter, index) => (
              <button
                key={index}
                onClick={() => setCurrentChapter(index)}
                className={`px-6 py-2 rounded-lg text-sm transition-all ${
                  currentChapter >= index
                    ? 'bg-white text-black'
                    : 'bg-zinc-800 text-zinc-400'
                }`}
              >
                {chapter.title}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Chapter 1: The Problem */}
      {currentChapter >= 0 && (
        <div className="py-16 sm:py-20 lg:py-24 px-4 sm:px-6 lg:px-8 bg-zinc-950">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16 scroll-fade">
              <div className="inline-flex items-center gap-2 bg-red-500/10 border border-red-500/20 rounded-full px-4 py-2 mb-6">
                <XCircle className="w-4 h-4 text-red-400" />
                <span className="text-red-400 text-sm font-medium">Chapter 1: The Problem</span>
              </div>
              <H2 className="text-white mb-6">
                The Creator's Admin Death Spiral
              </H2>
              <Body className="text-zinc-300 text-lg max-w-2xl mx-auto">
                Every successful creator faces the same inevitable trap
              </Body>
            </div>

            {/* Problem Flow Visualization */}
            <div className="grid md:grid-cols-4 gap-8 mb-16">
              {[
                { title: "Happy Creator", subtitle: "Doing what you love", icon: "😊", color: "bg-green-500/10 border-green-500/20" },
                { title: "Success Grows", subtitle: "More opportunities", icon: "📈", color: "bg-yellow-500/10 border-yellow-500/20" },
                { title: "Admin Chaos", subtitle: "Drowning in paperwork", icon: "📄", color: "bg-orange-500/10 border-orange-500/20" },
                { title: "Burnout", subtitle: "No time to create", icon: "😵", color: "bg-red-500/10 border-red-500/20" }
              ].map((stage, index) => (
                <div key={index} className="scroll-fade text-center" style={{ animationDelay: `${index * 200}ms` }}>
                  <div className={`w-20 h-20 mx-auto mb-4 rounded-full flex items-center justify-center text-3xl ${stage.color}`}>
                    {stage.icon}
                  </div>
                  <H3 className="text-white mb-2 text-lg">{stage.title}</H3>
                  <Body className="text-zinc-400 text-sm">{stage.subtitle}</Body>
                  {index < 3 && (
                    <ArrowRight className="w-5 h-5 text-zinc-600 mx-auto mt-4 hidden md:block" />
                  )}
                </div>
              ))}
            </div>

            <div className="text-center">
              <button
                onClick={() => setCurrentChapter(1)}
                className="bg-white text-black px-8 py-3 rounded-lg font-medium hover:bg-zinc-200 transition-colors inline-flex items-center gap-2"
              >
                Show Me The Solution
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Chapter 2: The Solution */}
      {currentChapter >= 1 && (
        <div className="py-16 sm:py-20 lg:py-24 px-4 sm:px-6 lg:px-8 bg-black">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16 scroll-fade">
              <div className="inline-flex items-center gap-2 bg-green-500/10 border border-green-500/20 rounded-full px-4 py-2 mb-6">
                <CheckCircle className="w-4 h-4 text-green-400" />
                <span className="text-green-400 text-sm font-medium">Chapter 2: The Solution</span>
              </div>
              <H2 className="text-white mb-6">
                Your Command Center
              </H2>
              <Body className="text-zinc-300 text-lg max-w-2xl mx-auto">
                Three powerful tools that eliminate the chaos forever
              </Body>
            </div>

            <div className="grid gap-8 md:grid-cols-3 mb-16">
              {[
                {
                  icon: CreditCard,
                  title: "Finance Autopilot",
                  description: "Invoices, payments, and tax reports - all automated",
                  before: "Hours of spreadsheets",
                  after: "2-click payments",
                  impact: "90% time saved"
                },
                {
                  icon: Briefcase,
                  title: "Smart Opportunities",
                  description: "Perfect brand matches delivered to your inbox",
                  before: "Endless cold emails",
                  after: "Curated perfect fits",
                  impact: "3x better deals"
                },
                {
                  icon: Users,
                  title: "Team Harmony",
                  description: "Seamless collaboration without the email chaos",
                  before: "Scattered communications",
                  after: "Organized workflows",
                  impact: "Zero missed deadlines"
                }
              ].map((solution, index) => (
                <div key={index} className="scroll-fade group" style={{ animationDelay: `${index * 200}ms` }}>
                  <div className="bg-zinc-900 border border-zinc-800 p-8 rounded-xl hover:bg-zinc-800 transition-all duration-500 h-full">
                    <div className="w-16 h-16 bg-gradient-to-br from-white/20 to-white/5 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                      <solution.icon className="h-8 w-8 text-white" />
                    </div>
                    
                    <H3 className="text-white mb-4">{solution.title}</H3>
                    <Body className="text-zinc-300 mb-6">{solution.description}</Body>
                    
                    {/* Before/After Comparison */}
                    <div className="space-y-3">
                      <div className="flex items-center gap-3">
                        <XCircle className="w-4 h-4 text-red-400 shrink-0" />
                        <span className="text-red-300 text-sm line-through">{solution.before}</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <CheckCircle className="w-4 h-4 text-green-400 shrink-0" />
                        <span className="text-green-300 text-sm font-medium">{solution.after}</span>
                      </div>
                      <div className="bg-gradient-to-r from-green-500/10 to-blue-500/10 border border-green-500/20 rounded-lg p-3 mt-4">
                        <span className="text-white font-bold">{solution.impact}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="text-center">
              <button
                onClick={() => setCurrentChapter(2)}
                className="bg-white text-black px-8 py-3 rounded-lg font-medium hover:bg-zinc-200 transition-colors inline-flex items-center gap-2"
              >
                How Does It Work?
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Chapter 3: The Process */}
      {currentChapter >= 2 && (
        <div className="py-16 sm:py-20 lg:py-24 px-4 sm:px-6 lg:px-8 bg-zinc-950">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16 scroll-fade">
              <div className="inline-flex items-center gap-2 bg-blue-500/10 border border-blue-500/20 rounded-full px-4 py-2 mb-6">
                <Zap className="w-4 h-4 text-blue-400" />
                <span className="text-blue-400 text-sm font-medium">Chapter 3: The Process</span>
              </div>
              <H2 className="text-white mb-6">
                Your New Reality
              </H2>
              <Body className="text-zinc-300 text-lg max-w-2xl mx-auto">
                From chaos to control in just three simple steps
              </Body>
            </div>

            {/* Interactive Process Timeline */}
            <div className="relative max-w-4xl mx-auto mb-16">
              <div className="absolute left-1/2 transform -translate-x-0.5 w-1 h-full bg-gradient-to-b from-blue-500 via-purple-500 to-green-500 rounded-full"></div>
              
              {[
                {
                  step: "01",
                  title: "Connect Everything",
                  description: "Link your socials & payment in under 2 minutes",
                  icon: Link,
                  detail: "One-time setup, lifetime benefits",
                  time: "2 min",
                  dotColor: "bg-blue-500"
                },
                {
                  step: "02", 
                  title: "Create Freely",
                  description: "Keep doing what you love while Jungl handles the rest",
                  icon: Zap,
                  detail: "Automatic tracking and invoicing",
                  time: "Ongoing",
                  dotColor: "bg-purple-500"
                },
                {
                  step: "03",
                  title: "Get Paid",
                  description: "Money appears in your account, reports ready for taxes",
                  icon: TrendingUp,
                  detail: "Automated financial management",
                  time: "Instant",
                  dotColor: "bg-green-500"
                }
              ].map((step, index) => (
                <div key={index} className={`relative flex items-center mb-16 ${index % 2 === 0 ? 'justify-start' : 'justify-end'}`}>
                  <div className="scroll-fade w-full max-w-sm" style={{ animationDelay: `${index * 300}ms` }}>
                    <div className={`bg-zinc-900 border border-zinc-800 p-6 rounded-xl ${index % 2 === 0 ? 'mr-8' : 'ml-8'}`}>
                      <div className="flex items-center gap-4 mb-4">
                        <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center">
                          <step.icon className="h-6 w-6 text-black" />
                        </div>
                        <div>
                          <span className="text-2xl font-bold text-white font-khinterference">{step.step}</span>
                          <div className="text-xs text-zinc-400 bg-zinc-800 px-2 py-1 rounded">{step.time}</div>
                        </div>
                      </div>
                      <H3 className="text-white mb-2">{step.title}</H3>
                      <Body className="text-zinc-300 mb-3">{step.description}</Body>
                      <Body className="text-zinc-500 text-sm italic">{step.detail}</Body>
                    </div>
                  </div>
                  
                  {/* Timeline Dot */}
                  <div className={`absolute left-1/2 transform -translate-x-1/2 w-6 h-6 ${step.dotColor} rounded-full border-4 border-zinc-900 z-10`}></div>
                </div>
              ))}
            </div>

            <div className="text-center">
              <button
                onClick={() => setCurrentChapter(3)}
                className="bg-white text-black px-8 py-3 rounded-lg font-medium hover:bg-zinc-200 transition-colors inline-flex items-center gap-2"
              >
                Show Me The Demo
                <Play className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Chapter 4: The Demo */}
      {currentChapter >= 3 && (
        <div className="py-16 sm:py-20 lg:py-24 px-4 sm:px-6 lg:px-8 bg-black">
          <div className="max-w-4xl mx-auto text-center">
            <div className="scroll-fade space-y-8">
              <div className="inline-flex items-center gap-2 bg-purple-500/10 border border-purple-500/20 rounded-full px-4 py-2 mb-6">
                <Play className="w-4 h-4 text-purple-400" />
                <span className="text-purple-400 text-sm font-medium">Chapter 4: The Proof</span>
              </div>
              
              <H2 className="text-white mb-6">
                See The Magic Happen
              </H2>
              
              <Body className="text-zinc-300 text-lg max-w-2xl mx-auto mb-12">
                Watch 30 seconds that will change how you think about creator business forever
              </Body>
              
              {/* Enhanced Video Container */}
              <div className="relative max-w-sm mx-auto mb-12">
                <div className="absolute -inset-4 bg-gradient-to-r from-blue-500/20 via-purple-500/20 to-green-500/20 rounded-3xl blur-xl"></div>
                <div className="relative bg-zinc-900 rounded-3xl overflow-hidden shadow-2xl border border-zinc-800 aspect-[9/19]">
                  <video
                    ref={videoRef}
                    className="w-full h-full object-cover rounded-3xl"
                    loop
                    muted
                    playsInline
                    onPlay={() => setIsPlaying(true)}
                    onPause={() => setIsPlaying(false)}
                    poster="/video-placeholder.jpg"
                  >
                    <source src="/video-placeholder.jpg" type="video/mp4" />
                  </video>
                  
                  <button
                    onClick={togglePlay}
                    className="absolute inset-0 flex items-center justify-center bg-black/20 hover:bg-black/30 transition-all duration-200 group rounded-3xl"
                  >
                    <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-full p-4 group-hover:bg-white/20 transition-all duration-200">
                      {isPlaying ? (
                        <Pause className="w-8 h-8 text-white" />
                      ) : (
                        <Play className="w-8 h-8 text-white ml-1" />
                      )}
                    </div>
                  </button>
                </div>
              </div>

              {/* Story Conclusion */}
              <div className="bg-gradient-to-r from-zinc-900 via-zinc-800 to-zinc-900 border border-zinc-700 p-8 rounded-xl max-w-2xl mx-auto mb-12">
                <H3 className="text-white mb-4">The End Result?</H3>
                <Body className="text-zinc-300 text-lg leading-relaxed mb-6">
                  You spend <span className="text-green-400 font-bold">90% less time</span> on admin, 
                  make <span className="text-green-400 font-bold">40% more money</span>, and finally get back to what you love: creating amazing content.
                </Body>
                <div className="flex items-center justify-center gap-8 text-sm text-zinc-400">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-400">90%</div>
                    <div>Time Saved</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-400">40%</div>
                    <div>More Revenue</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-400">100%</div>
                    <div>Worth It</div>
                  </div>
                </div>
              </div>
              
              {/* Call to Action */}
              <div>
                <Body className="text-zinc-300 mb-6 text-lg">
                  Ready to write your success story?
                </Body>
                <div className="flex flex-row gap-4 justify-center items-center">
                  <a 
                    href="https://apps.apple.com/dk/app/jungl-creator-business-hub/id6741893457" 
                    className="block transition-opacity hover:opacity-80" 
                    target="_blank" 
                    rel="noopener noreferrer"
                  >
                    <img 
                      src="https://ehfsfqmzmrwzlgnbpyzz.supabase.co/storage/v1/object/public/assets//2.svg" 
                      alt="Download Jungl on the App Store" 
                      className="h-12 w-auto"
                    />
                  </a>
                  <a 
                    href="#" 
                    className="block transition-opacity hover:opacity-80" 
                    target="_blank" 
                    rel="noopener noreferrer"
                  >
                    <img 
                      src="https://ehfsfqmzmrwzlgnbpyzz.supabase.co/storage/v1/object/public/assets//1.svg" 
                      alt="Get Jungl on Google Play" 
                      className="h-12 w-auto"
                    />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProgressiveStoryFlow51;