import { H2, H3, Body } from "@/components/Typography";
import { Play, Pause, CreditCard, Briefcase, Users, Link, Zap, TrendingUp, ArrowDown } from "lucide-react";
import { useState, useRef } from "react";

const ProgressiveStoryFlow = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  return (
    <div className="bg-black">
      {/* Story Introduction */}
      <div className="py-16 sm:py-20 lg:py-24 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center scroll-fade">
          <H2 className="text-white mb-6">
            From Chaos to Control
          </H2>
          <Body className="text-zinc-300 text-lg max-w-2xl mx-auto mb-12">
            Every creator knows the struggle: you're amazing at creating content, but drowning in admin work. 
            Here's how Jungl changes everything.
          </Body>
          <ArrowDown className="w-6 h-6 text-white/60 mx-auto animate-bounce" />
        </div>
      </div>

      {/* Chapter 1: The Problem → Solution */}
      <div className="py-16 px-4 sm:px-6 lg:px-8 bg-zinc-950">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16 scroll-fade">
            <H2 className="text-white mb-6">
              What You Get: Your Command Center
            </H2>
            <Body className="text-zinc-300 text-lg">
              Three powerful tools that eliminate the chaos
            </Body>
          </div>

          <div className="grid gap-8 md:grid-cols-3">
            {[
              {
                icon: CreditCard,
                title: "Finance Hub",
                description: "One-click invoices, automated reminders, multi-currency payouts, and real-time earnings dashboard.",
                problem: "No more spreadsheet hell",
                benefit: "Everything automated"
              },
              {
                icon: Briefcase,
                title: "Smart Jobs",
                description: "Curated brand briefs that actually match your audience. Accept offers or counter in a tap.",
                problem: "No more bad-fit brands",
                benefit: "Perfect matches only"
              },
              {
                icon: Users,
                title: "Team Collaboration", 
                description: "Secure file-sharing, shared calendars, and role-based access for agents & editors.",
                problem: "No more email chaos",
                benefit: "Seamless teamwork"
              }
            ].map((card, index) => (
              <div 
                key={index}
                className="scroll-fade group"
                style={{ animationDelay: `${index * 200}ms` }}
              >
                <div className="bg-zinc-900 border border-zinc-800 p-8 rounded-lg hover:bg-zinc-800 transition-all duration-300 h-full">
                  {/* Problem → Solution Flow */}
                  <div className="text-center mb-6">
                    <div className="w-16 h-16 bg-red-500/10 rounded-full flex items-center justify-center mx-auto mb-3">
                      <span className="text-red-400 text-sm font-medium">Before</span>
                    </div>
                    <Body className="text-red-300 text-sm mb-4">{card.problem}</Body>
                    <ArrowDown className="w-4 h-4 text-zinc-600 mx-auto mb-4" />
                    <div className="w-16 h-16 bg-green-500/10 rounded-full flex items-center justify-center mx-auto mb-3">
                      <card.icon className="h-6 w-6 text-green-400" />
                    </div>
                    <Body className="text-green-300 text-sm font-medium">{card.benefit}</Body>
                  </div>
                  
                  <H3 className="text-white mb-4 text-center">{card.title}</H3>
                  <Body className="text-zinc-300 text-center">{card.description}</Body>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Chapter 2: How It Works */}
      <div className="py-16 sm:py-20 lg:py-24 px-4 sm:px-6 lg:px-8 bg-black">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16 scroll-fade">
            <H2 className="text-white mb-6">
              How It Actually Works
            </H2>
            <Body className="text-zinc-300 text-lg">
              Three simple steps. That's it.
            </Body>
          </div>

          <div className="relative">
            {/* Flow Line */}
            <div className="hidden md:block absolute top-1/2 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-white/20 to-transparent transform -translate-y-1/2"></div>
            
            <div className="grid gap-12 md:grid-cols-3 relative">
              {[
                {
                  step: "01",
                  title: "Connect",
                  description: "Link your socials & payment method in < 2 min.",
                  icon: Link,
                  detail: "One-time setup, lifetime benefits"
                },
                {
                  step: "02", 
                  title: "Create",
                  description: "Keep posting; Jungl tracks your brand mentions & converts them to invoices.",
                  icon: Zap,
                  detail: "Keep doing what you love"
                },
                {
                  step: "03",
                  title: "Cash-out",
                  description: "Get paid, export tax-ready reports, and climb the leaderboard for bigger deals.",
                  icon: TrendingUp,
                  detail: "Money in the bank, automatically"
                }
              ].map((step, index) => (
                <div 
                  key={index}
                  className="scroll-fade text-center relative"
                  style={{ animationDelay: `${index * 300}ms` }}
                >
                  {/* Step Circle */}
                  <div className="relative inline-block mb-6">
                    <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center shadow-lg relative z-10">
                      <step.icon className="h-8 w-8 text-black" />
                    </div>
                    <div className="absolute -top-3 -right-3 w-8 h-8 bg-white text-black rounded-full flex items-center justify-center text-sm font-bold font-khinterference border-2 border-black">
                      {index + 1}
                    </div>
                    {/* Flow Arrow */}
                    {index < 2 && (
                      <div className="hidden md:block absolute top-1/2 left-full w-12 transform -translate-y-1/2">
                        <div className="w-full h-0.5 bg-white/40"></div>
                        <div className="absolute right-0 top-1/2 transform -translate-y-1/2 w-0 h-0 border-l-4 border-l-white/40 border-t-2 border-t-transparent border-b-2 border-b-transparent"></div>
                      </div>
                    )}
                  </div>
                  
                  <H3 className="text-white mb-3">{step.title}</H3>
                  <Body className="text-zinc-300 mb-3">{step.description}</Body>
                  <Body className="text-zinc-500 text-sm italic">{step.detail}</Body>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Chapter 3: See It In Action */}
      <div className="py-16 sm:py-20 lg:py-24 px-4 sm:px-6 lg:px-8 bg-zinc-950">
        <div className="max-w-4xl mx-auto text-center">
          <div className="scroll-fade space-y-8">
            <H2 className="text-white mb-6">
              See the Magic Happen
            </H2>
            
            <Body className="text-zinc-300 text-lg max-w-2xl mx-auto mb-12">
              Watch how 30 seconds in Jungl replaces hours of admin work
            </Body>
            
            {/* Phone Mockup Container */}
            <div className="relative max-w-sm mx-auto mb-12">
              <div className="relative bg-zinc-900 rounded-3xl overflow-hidden shadow-2xl border border-zinc-800 aspect-[9/19]">
                <video
                  ref={videoRef}
                  className="w-full h-full object-cover rounded-3xl"
                  loop
                  muted
                  playsInline
                  onPlay={() => setIsPlaying(true)}
                  onPause={() => setIsPlaying(false)}
                  poster="/video-placeholder.jpg"
                >
                  <source src="/video-placeholder.jpg" type="video/mp4" />
                </video>
                
                <button
                  onClick={togglePlay}
                  className="absolute inset-0 flex items-center justify-center bg-black/20 hover:bg-black/30 transition-all duration-200 group rounded-3xl"
                >
                  <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-full p-4 group-hover:bg-white/20 transition-all duration-200">
                    {isPlaying ? (
                      <Pause className="w-8 h-8 text-white" />
                    ) : (
                      <Play className="w-8 h-8 text-white ml-1" />
                    )}
                  </div>
                </button>
              </div>
            </div>

            {/* Story Conclusion */}
            <div className="bg-zinc-900 border border-zinc-800 p-8 rounded-lg max-w-2xl mx-auto mb-12">
              <Body className="text-zinc-300 text-lg leading-relaxed">
                <span className="text-white font-medium">The result?</span> You spend 90% less time on admin, 
                make 40% more money, and finally get back to what you love: creating amazing content.
              </Body>
            </div>
            
            {/* Call to Action */}
            <div>
              <Body className="text-zinc-300 mb-6 text-lg">
                Ready to reclaim your time?
              </Body>
              <div className="flex flex-row gap-4 justify-center items-center">
                <a 
                  href="https://apps.apple.com/dk/app/jungl-creator-business-hub/id6741893457" 
                  className="block transition-opacity hover:opacity-80" 
                  target="_blank" 
                  rel="noopener noreferrer"
                >
                  <img 
                    src="https://ehfsfqmzmrwzlgnbpyzz.supabase.co/storage/v1/object/public/assets//2.svg" 
                    alt="Download Jungl on the App Store" 
                    className="h-12 w-auto"
                  />
                </a>
                <a 
                  href="#" 
                  className="block transition-opacity hover:opacity-80" 
                  target="_blank" 
                  rel="noopener noreferrer"
                >
                  <img 
                    src="https://ehfsfqmzmrwzlgnbpyzz.supabase.co/storage/v1/object/public/assets//1.svg" 
                    alt="Get Jungl on Google Play" 
                    className="h-12 w-auto"
                  />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProgressiveStoryFlow;