
import { H2, BodyLarge, Body } from "./Typography";
import { Check } from "lucide-react";

const features = [
  "Find paid campaigns from brands that get you",
  "Collaborate without chaos (no more lost briefs)",
  "Design your creator portfolio and media kit",
  "Launch your personal storefront in minutes",
  "Get real insights — not analytics noise",
  "Automate invoicing, payments, and taxes",
  "Stay organized, creative, and in control"
];

const WhatYouCanDo = () => {
  return (
    <section className="py-24 px-8 bg-black">
      <div className="max-w-4xl mx-auto text-center">
        <div className="scroll-fade space-y-8">
          {/* Section Title */}
          <H2 className="text-white mb-6">
            What You Can Do With Jungl
          </H2>
          
          {/* Subtitle */}
          <BodyLarge className="text-zinc-300 mb-12">
            Everything you need to operate your creator business — in one app.
          </BodyLarge>
          
          {/* Features list */}
          <div className="grid md:grid-cols-1 gap-4 mb-16 max-w-2xl mx-auto">
            {features.map((feature, index) => (
              <div 
                key={index} 
                className="scroll-fade flex items-start text-left"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="flex-shrink-0 w-2 h-2 bg-white rounded-full mt-3 mr-4"></div>
                <Body className="text-white text-lg">
                  {feature}
                </Body>
              </div>
            ))}
          </div>
          
          {/* Closing statement */}
          <div className="text-center">
            <BodyLarge className="text-white font-medium">
              No agents. No gatekeepers. No burnout.
            </BodyLarge>
          </div>
        </div>
      </div>
    </section>
  );
};

export default WhatYouCanDo;
