import { H2, H3, Body } from "./Typography";
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  {
    question: "When will I get access?",
    answer: "We onboard new users every Monday. Your spot in the queue depends on referrals."
  },
  {
    question: "Is Jungl free?",
    answer: "Beta is free. After launch we'll offer a free tier plus Pro starting at €19/mo."
  },
  {
    question: "How does Jungl make money?",
    answer: "We charge brands a small platform fee for using Jungl to find creators. You keep 100% of your earnings with zero transaction fees."
  },
  {
    question: "Are there any hidden fees?",
    answer: "No. We believe in transparent pricing. No transaction fees, no payment processing fees, no surprises."
  },
  {
    question: "What happens after the free beta?",
    answer: "You can continue with our free tier or upgrade to Pro (€19/mo) for premium features like priority brand matching and advanced analytics."
  },
  {
    question: "What countries are supported?",
    answer: "Payouts: EU, UK, US, CA. Tax reports: DK, SE, NO (more soon)."
  },
  {
    question: "What platforms do you integrate?",
    answer: "Instagram, TikTok, YouTube, Twitch, and Patreon today; Snapchat and Kick are on the roadmap."
  },
  {
    question: "Do you touch my money?",
    answer: "Funds flow via Stripe Treasury. Jungl never holds your cash—compliance audited."
  },
  {
    question: "Can agencies use Jungl?",
    answer: "Yes, with multi-seat dashboards and role permissions. Ask about our agency beta."
  }
];

const FAQSection = () => {
  return (
    <div className="py-12 sm:py-16 lg:py-20 px-4 sm:px-6 lg:px-8 bg-black">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-8 sm:mb-12 scroll-fade">
          <H2 className="text-white mb-4">
            Frequently Asked Questions
          </H2>
        </div>

        <div className="scroll-fade">
          <Accordion type="single" collapsible className="space-y-2">
            {faqs.map((faq, index) => (
              <AccordionItem 
                key={index} 
                value={`item-${index}`}
                className="bg-zinc-900 border border-zinc-800 rounded-lg px-4"
              >
                <AccordionTrigger 
                  className="text-white hover:text-zinc-300 text-left py-4 min-h-[40px] focus:outline-none focus:ring-2 focus:ring-white/20 rounded"
                  aria-expanded="false"
                >
                  <H3 className="text-sm sm:text-base">
                    {faq.question}
                  </H3>
                </AccordionTrigger>
                <AccordionContent>
                  <Body className="text-zinc-300 pb-3 text-sm">
                    {faq.answer}
                  </Body>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </div>
  );
};

export default FAQSection;