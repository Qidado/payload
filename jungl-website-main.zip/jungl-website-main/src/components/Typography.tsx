import { cn } from "@/lib/utils";
interface TypographyProps {
  children: React.ReactNode;
  className?: string;
  id?: string;
  itemProp?: string;
}

// Display components (KH INTERFERENCE, Bold, -2% letter-spacing)
export const HeroMegaDisplay = ({
  children,
  className
}: TypographyProps) => <h1 className={cn("text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-bold leading-none font-khinterference tracking-tight", className)}>
    {children}
  </h1>;
export const HeroDisplay = ({
  children,
  className,
  itemProp
}: TypographyProps) => <h2 className={cn("text-xl sm:text-2xl md:text-3xl lg:text-4xl xl:text-5xl font-bold leading-none font-khinterference tracking-tight", className)} itemProp={itemProp}>
    {children}
  </h2>;

// Alternate Display components (KH INTERFERENCE, Bold, -2% letter-spacing)
export const AlternateDisplay = ({
  children,
  className
}: TypographyProps) => <h1 className={cn("text-xl sm:text-2xl md:text-3xl lg:text-4xl font-bold leading-tight font-khinterference tracking-tight", className)}>
    {children}
  </h1>;

// Headline components (KH Teka, Regular, -2% letter-spacing)

export const H2 = ({
  children,
  className,
  id
}: TypographyProps) => <h2 className={cn("text-lg sm:text-xl md:text-2xl lg:text-3xl font-bold leading-tight font-khinterference tracking-tight", className)} id={id}>
  {children}
</h2>;
export const H3 = ({
  children,
  className,
  id
}: TypographyProps) => <h3 className={cn("text-xl sm:text-2xl md:text-3xl lg:text-4xl xl:text-5xl font-bold leading-none font-khinterference tracking-tight", className)} id={id}>
    {children}
  </h3>;

// Bodytext components (KH Teka, Regular, -2% letter-spacing)
export const Body = ({
  children,
  className
}: TypographyProps) => <p className={cn("text-base leading-6 font-khteka text-foreground tracking-normal", className)}>
    {children}
  </p>;
export const BodyLarge = ({
  children,
  className,
  itemProp
}: TypographyProps) => <p className={cn("text-base sm:text-lg leading-6 font-khteka text-foreground tracking-normal", className)} itemProp={itemProp}>
    {children}
  </p>;
export const BodySmall = ({
  children,
  className
}: TypographyProps) => <p className={cn("text-sm sm:text-base leading-6 text-foreground/80 font-khteka tracking-normal", className)}>
    {children}
  </p>;
export const Caption = ({
  children,
  className
}: TypographyProps) => <p className={cn("text-sm leading-5 text-foreground/70 font-khteka tracking-normal", className)}>
    {children}
  </p>;

// Alternate components (KH Giga, Regular, -2% letter-spacing)
export const Emphasis = ({
  children,
  className
}: TypographyProps) => <em className={cn("text-base italic font-khgiga tracking-tight", className)}>
    {children}
  </em>;
export const AlternateText = ({
  children,
  className
}: TypographyProps) => <p className={cn("text-base font-khgiga text-foreground tracking-normal", className)}>
    {children}
  </p>;

// Specialized display components with hard-coded colors (legacy)
export const PriceDisplay = ({
  children,
  className
}: TypographyProps) => <div className={cn("text-2xl font-bold text-black font-khinterference tracking-tight", className)}>
    {children}
  </div>;
export const StepNumber = ({
  children,
  className
}: TypographyProps) => <div className={cn("text-3xl sm:text-4xl font-bold text-black font-khinterference tracking-tight", className)}>
    {children}
  </div>;
export const StatDisplay = ({
  children,
  className
}: TypographyProps) => <div className={cn("text-3xl font-bold text-black font-khinterference tracking-tight", className)}>
    {children}
  </div>;