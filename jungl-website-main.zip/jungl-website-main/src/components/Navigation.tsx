import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";
import { useState } from "react";
import { useLocation } from "react-router-dom";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { trackCTAClick, trackNavigation } from "@/lib/posthog";
interface NavigationProps {
  variant?: "light" | "dark";
}
const Navigation = ({
  variant = "light"
}: NavigationProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();
  const isLight = variant === "light";
  const textColor = isLight ? "text-white" : "text-black";
  const hoverColor = isLight ? "hover:opacity-80" : "hover:opacity-70";
  const logoSrc = isLight ? "https://ehfsfqmzmrwzlgnbpyzz.supabase.co/storage/v1/object/public/assets//logo%20white.png" : "/lovable-uploads/fae03d47-1e70-4416-979a-4aedf430d269.png";
  const menuIconColor = isLight ? "text-white" : "text-black";
  const mobileMenuBg = isLight ? "bg-black border-zinc-800" : "bg-white border-zinc-200";
  const mobileMenuText = isLight ? "text-white" : "text-black";
  const buttonClasses = isLight ? "bg-white text-black hover:opacity-90" : "bg-black text-white hover:opacity-90";

  // Dynamic CTA link based on current route
  const ctaLink = location.pathname === "/brands" ? "https://getjungl.link/D3lpkHD" : "https://apps.apple.com/dk/app/jungl-creator-business-hub/id6741893457";
  const ctaLabel = location.pathname === "/brands" ? "Get started with Jungl for brands" : "Download Jungl app";
  const handleCTAClick = () => {
    const ctaType = location.pathname === "/brands" ? "brands_beta_signup" : "app_store_download";
    trackCTAClick(ctaType, "header", ctaLink);
  };
  const handleNavClick = (destination: string) => {
    trackNavigation(location.pathname, destination);
  };
  return <header role="banner" className="absolute top-0 left-0 right-0 w-full z-50 px-4 sm:px-6 md:px-8 flex items-center justify-between py-[26px] my-[8px] md:py-0">
      {/* Left Navigation - Hidden on mobile */}
      <nav className={`hidden lg:flex gap-6 xl:gap-8 text-sm font-khteka ${textColor}`} role="navigation" aria-label="Main navigation">
        <a href="/" className={`${hoverColor} transition-opacity`} aria-label="Navigate to Creators page" onClick={() => handleNavClick('/')}>Creators</a>
        <a href="/brands" className={`${hoverColor} transition-opacity`} aria-label="Navigate to For Brands page" onClick={() => handleNavClick('/brands')}>Brands</a>
        <a href="/resources" className={`${hoverColor} transition-opacity`} aria-label="Navigate to Resources page" onClick={() => handleNavClick('/resources')}>Resources</a>
        <a href="/blog" className={`${hoverColor} transition-opacity`} aria-label="Navigate to Blog page" onClick={() => handleNavClick('/blog')}>Blog</a>
        <a href="/book-demo" className={`${hoverColor} transition-opacity`} aria-label="Navigate to Book a demo page" onClick={() => handleNavClick('/book-demo')}>Book a demo</a>
      </nav>

      {/* Center Logo */}
      <div className="absolute left-1/2 transform -translate-x-1/2">
        <a href="/" className="block">
          <img src={logoSrc} alt="Jungl - Creator Business Hub" className={`h-5 sm:h-6 w-auto ${hoverColor} transition-opacity`} onError={e => {
          const target = e.target as HTMLImageElement;
          target.style.display = 'none';
          const parent = target.parentElement;
          if (parent && !parent.querySelector('.fallback-logo')) {
            const fallbackDiv = document.createElement('div');
            fallbackDiv.className = `fallback-logo ${textColor} font-bold text-lg`;
            fallbackDiv.textContent = 'JUNGL';
            parent.appendChild(fallbackDiv);
          }
        }} />
        </a>
      </div>

      {/* Right Navigation - Hidden on mobile/tablet */}
      <div className="hidden lg:flex items-center gap-4 xl:gap-6">
        <a href="/login" className={`${textColor} text-sm font-khteka ${hoverColor} transition-opacity`} aria-label="Log in to your account">
          Log in
        </a>
        <Button className={`${buttonClasses} font-khteka px-4 py-2 text-sm xl:px-6`} aria-label={ctaLabel} asChild>
          <a href={ctaLink} target="_blank" rel="noopener noreferrer" onClick={handleCTAClick}>
            Get started
          </a>
        </Button>
      </div>

      {/* Mobile Menu - Visible on mobile and tablet */}
      <div className="lg:hidden">
        <Sheet open={isOpen} onOpenChange={setIsOpen}>
          <SheetTrigger asChild>
            <button className="p-2" aria-label="Open mobile menu" aria-expanded={isOpen}>
              <Menu className={`h-6 w-6 ${menuIconColor}`} />
            </button>
          </SheetTrigger>
          <SheetContent side="right" className={`${mobileMenuBg} w-80`}>
            <div className="flex flex-col gap-6 mt-8">
              <a href="/" className={`${mobileMenuText} text-lg font-khteka ${hoverColor} transition-opacity`} onClick={() => handleNavClick('/')}>Creators</a>
              <a href="/brands" className={`${mobileMenuText} text-lg font-khteka ${hoverColor} transition-opacity`} onClick={() => handleNavClick('/brands')}>For Brands</a>
              <a href="/resources" className={`${mobileMenuText} text-lg font-khteka ${hoverColor} transition-opacity`} onClick={() => handleNavClick('/resources')}>Resources</a>
              <a href="/blog" className={`${mobileMenuText} text-lg font-khteka ${hoverColor} transition-opacity`} onClick={() => handleNavClick('/blog')}>Blog</a>
              <a href="/book-demo" className={`${mobileMenuText} text-lg font-khteka ${hoverColor} transition-opacity`} onClick={() => handleNavClick('/book-demo')}>Book a demo</a>
              <hr className={isLight ? "border-zinc-800" : "border-zinc-200"} />
              <a href="/login" className={`${mobileMenuText} text-lg font-khteka ${hoverColor} transition-opacity`}>
                Log in
              </a>
              <Button className={`${buttonClasses} font-khteka w-full`} asChild>
                <a href={ctaLink} target="_blank" rel="noopener noreferrer" onClick={handleCTAClick}>
                  Get started
                </a>
              </Button>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </header>;
};
export default Navigation;