import { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';

const mainPageSections = [
  { id: 'hero', label: 'Hero' },
  { id: 'problem', label: 'Problem' },
  { id: 'demo', label: 'Demo' },
  { id: 'solution', label: 'Solution' },
  { id: 'truth', label: 'Truth' },
  { id: 'showcase', label: 'Showcase' },
  { id: 'how-it-works', label: 'How It Works' },
  { id: 'pricing', label: 'Pricing' },
  { id: 'faq', label: 'FAQ' },
];

const brandsPageSections = [
  { id: 'hero', label: 'Hero' },
  { id: 'pain', label: 'Pain' },
  { id: 'solution', label: 'Solution' },
  { id: 'how', label: 'How It Works' },
  { id: 'proof', label: 'Proof' },
  { id: 'features', label: 'Features' },
  { id: 'pricing', label: 'Pricing' },
  { id: 'faq', label: 'FAQ' },
];

interface SectionNavigationProps {
  sections?: { id: string; label: string; }[];
}

const SectionNavigation = ({ sections: propSections }: SectionNavigationProps = {}) => {
  const [activeSection, setActiveSection] = useState('hero');
  const [isVisible, setIsVisible] = useState(false);
  const location = useLocation();
  
  const sections = propSections || (location.pathname === '/brands' ? brandsPageSections : mainPageSections);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActiveSection(entry.target.id);
          }
        });
      },
      { 
        threshold: 0.3,
        rootMargin: '-20% 0px -20% 0px'
      }
    );

    // Add IDs to sections if they don't exist
    const heroSection = document.querySelector('section[role="banner"]');
    if (heroSection && !heroSection.id) heroSection.id = 'hero';

    const allSections = document.querySelectorAll('section');
    allSections.forEach((section, index) => {
      if (!section.id) {
        const sectionNames = ['hero', 'truth', 'problem', 'solution', 'demo', 'pricing', 'how-it-works', 'faq'];
        section.id = sectionNames[index] || `section-${index}`;
      }
      observer.observe(section);
    });

    // Show navigation after scrolling past hero
    const handleScroll = () => {
      const scrollY = window.pageYOffset;
      setIsVisible(scrollY > window.innerHeight * 0.5);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });

    return () => {
      observer.disconnect();
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  if (!isVisible) return null;

  return (
    <div className="fixed right-4 top-1/2 transform -translate-y-1/2 z-40 hidden lg:block">
      <div className="bg-zinc-900/80 backdrop-blur-sm border border-zinc-800 rounded-lg p-2">
        <div className="flex flex-col space-y-2">
          {sections.map((section) => (
            <button
              key={section.id}
              onClick={() => scrollToSection(section.id)}
              className={`w-3 h-3 rounded-full border-2 transition-all duration-200 ${
                activeSection === section.id
                  ? 'bg-white border-white'
                  : 'bg-transparent border-zinc-600 hover:border-zinc-400'
              }`}
              title={section.label}
              aria-label={`Go to ${section.label} section`}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default SectionNavigation;