import { H2, Body } from "./Typography";

const testimonials = [
  {
    quote: "I cut my invoicing time from 3 hours to 10 minutes per week.",
    name: "Clara",
    handle: "@clarafilm",
    followers: "128K YT",
    avatar: "/lovable-uploads/1a5f57e5-8210-4e92-9a64-0834f3027266.png"
  },
  {
    quote: "The referral leaderboard had me onboarded in days. Brands pay me on time—finally.",
    name: "Leo F.",
    handle: "@leo",
    followers: "Twitch Partner",
    avatar: "/lovable-uploads/3d8690ac-1ce9-4e14-b2be-53745c43eea8.png"
  },
  {
    quote: "We invested because Jungl removes friction no tool in Europe has solved yet.",
    name: "Nordic Angels",
    handle: "@NordicAngels",
    followers: "Fund",
    avatar: "/lovable-uploads/56495540-5978-42a9-b48e-d0df60b46803.png"
  }
];

const TestimonialsSection = () => {
  return (
    <section className="py-16 sm:py-20 lg:py-24 px-4 sm:px-6 lg:px-8 bg-black" id="proof">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12 sm:mb-16 scroll-fade">
          <H2 className="text-white mb-6" id="testimonials-heading">
            Trusted by Early Creators & Backers
          </H2>
        </div>

        <div className="grid gap-8 md:grid-cols-3">
          {testimonials.map((testimonial, index) => (
            <div 
              key={index}
              className="scroll-fade bg-zinc-900 border border-zinc-800 p-6 rounded-lg"
              style={{ animationDelay: `${index * 150}ms` }}
            >
              <blockquote className="mb-6">
                <Body className="text-white text-lg leading-relaxed">
                  "{testimonial.quote}"
                </Body>
              </blockquote>
              
              <footer className="flex items-center">
                <img 
                  src={testimonial.avatar} 
                  alt={`${testimonial.name} avatar`}
                  className="w-10 h-10 rounded-full mr-3 object-cover"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.src = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIGZpbGw9Im5vbmUiIHZpZXdCb3g9IjAgMCA0MCA0MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIGZpbGw9IiMzZjNmNDYiIHJ4PSI5OSIvPjxwYXRoIGQ9Im0yMCAyMGEzIDMgMCAxIDAgMC02IDMgMyAwIDAgMCAwIDZ6bS03IDlhNyA3IDAgMSAxIDE0IDBoLTE0eiIgZmlsbD0iIzlmOWY5ZiIvPjwvc3ZnPg==";
                  }}
                />
                <div>
                  <div className="text-white font-medium text-sm">
                    {testimonial.name} {testimonial.handle}
                  </div>
                  <div className="text-zinc-400 text-sm">
                    {testimonial.followers}
                  </div>
                </div>
              </footer>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;