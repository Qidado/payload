
import { Button } from "@/components/ui/button";
import { ArrowRight, Clock, Users, Zap } from "lucide-react";
import { H2, BodyLarge, Body } from "./Typography";
import EarlyAccessForm from "./EarlyAccessForm";

const EarlyAccessCTA = () => {
  return (
    <section className="py-16 sm:py-20 lg:py-24 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-zinc-950 to-black">
      <div className="max-w-container mx-auto">
        <div className="text-center max-w-4xl mx-auto">
          <div className="scroll-fade">
            <H2 className="text-white mb-4 sm:mb-6">
              Ready to grow your creator business?
            </H2>
            
            <BodyLarge className="text-zinc-300 mb-8">
              Download Jungl and join thousands of creators who are building sustainable businesses without the burnout.
            </BodyLarge>

            <div className="flex flex-row gap-3 justify-center mb-8">
              <a href="https://apps.apple.com/dk/app/jungl-creator-business-hub/id6741893457" className="block transition-opacity hover:opacity-80 cursor-pointer" aria-label="Download on the App Store" target="_blank" rel="noopener noreferrer">
                <img src="https://ehfsfqmzmrwzlgnbpyzz.supabase.co/storage/v1/object/public/assets//2.svg" alt="Download on the App Store" className="h-12 sm:h-14 w-auto pointer-events-none" />
              </a>
              
              <div className="relative">
                <a href="#" className="block transition-opacity hover:opacity-80 cursor-pointer" aria-label="Download on Google Play" target="_blank" rel="noopener noreferrer">
                  <img src="https://ehfsfqmzmrwzlgnbpyzz.supabase.co/storage/v1/object/public/assets//1.svg" alt="Get it on Google Play" className="h-12 sm:h-14 w-auto pointer-events-none" />
                </a>
              </div>
            </div>

          </div>
        </div>
      </div>
    </section>
  );
};

export default EarlyAccessCTA;
