import { useState, useEffect } from "react";
import { H2, Body, BodySmall } from "./Typography";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { trackFormInteraction, trackFormSubmission, trackUserIdentification } from "@/lib/posthog";

const WaitlistSection = () => {
  const [email, setEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [hasStartedForm, setHasStartedForm] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (email && !hasStartedForm) {
      trackFormInteraction('waitlist', 'started');
      setHasStartedForm(true);
    }
  }, [email, hasStartedForm]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email || !email.includes("@")) {
      trackFormSubmission('waitlist', false, { error: 'invalid_email' });
      toast({
        title: "Oops—double-check that email.",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Track successful submission and identify user
      trackUserIdentification(email, {
        source: 'waitlist',
        signup_type: 'early_access'
      });
      
      trackFormSubmission('waitlist', true, { 
        email_domain: email.split('@')[1] 
      });
      
      toast({
        title: "Invite requested! Check your inbox for your spot number.",
        description: "We send product updates, nothing else."
      });
      
      setEmail("");
    } catch (error) {
      trackFormSubmission('waitlist', false, { error: 'submission_failed' });
      toast({
        title: "Something went wrong. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <section className="py-16 sm:py-20 lg:py-24 px-4 sm:px-6 lg:px-8 bg-zinc-950" id="waitlist">
      <div className="max-w-4xl mx-auto text-center">
        <div className="scroll-fade space-y-8">
          <H2 className="text-white mb-6">
            Jump the Line
          </H2>
          
          <Body className="text-zinc-300 text-lg mb-8">
            Every friend you invite moves you ↑ and unlocks perks like 0% fee for 3 months.
          </Body>
          
          <form onSubmit={handleSubmit} className="max-w-md mx-auto mb-6">
            <div className="flex gap-3">
               <Input
                type="email"
                placeholder="name@creator.me"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                onFocus={() => trackFormInteraction('waitlist', 'field_focused', 'email')}
                className="flex-1 bg-zinc-900 border-zinc-800 text-white placeholder:text-zinc-500"
                disabled={isLoading}
              />
              <Button 
                type="submit" 
                disabled={isLoading}
                aria-label="Request early access invitation"
              >
                {isLoading ? "Swinging through the vines..." : "Get My Invite"}
              </Button>
            </div>
          </form>
          
          <div className="space-y-2">
            <Body className="text-zinc-400">
              You're #837 • 2 referrals → Top 100
            </Body>
            <BodySmall className="text-zinc-500">
              We send product updates, nothing else.
            </BodySmall>
          </div>
        </div>
      </div>
    </section>
  );
};

export default WaitlistSection;