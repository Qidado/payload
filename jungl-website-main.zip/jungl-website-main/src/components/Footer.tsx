import { Body, BodySmall } from "./Typography";

const Footer = () => {
  return (
    <footer className="bg-black py-12 sm:py-16 px-4 sm:px-6 lg:px-8 border-t border-zinc-800">
      <div className="max-w-container mx-auto">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-8 sm:mb-12">
          {/* Brand */}
          <div className="col-span-1 sm:col-span-2">
            <div className="mb-4">
              <img 
                src="https://ehfsfqmzmrwzlgnbpyzz.supabase.co/storage/v1/object/public/assets//logo%20white.png" 
                alt="Jungl - Creator Business Platform" 
                width="80"
                height="20"
                loading="lazy"
                className="h-4 sm:h-5 w-auto"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.style.display = 'none';
                  const parent = target.parentElement;
                  if (parent && !parent.querySelector('.fallback-footer-logo')) {
                    const fallbackDiv = document.createElement('div');
                    fallbackDiv.className = 'fallback-footer-logo text-white font-bold text-sm';
                    fallbackDiv.textContent = 'JUNGL';
                    parent.appendChild(fallbackDiv);
                  }
                }}
              />
            </div>
            <Body className="text-zinc-300 max-w-md text-sm sm:text-base">
              The quiet powerhouse behind the creator economy. 
              Helping next-gen creators turn momentum into business.
            </Body>
          </div>

          {/* Navigation */}
          <div>
            <h4 className="text-white font-semibold mb-4 font-khinterference text-base sm:text-lg">Navigation</h4>
            <ul className="space-y-2">
              <li><a href="/" className="text-zinc-300 hover:text-white transition-colors font-khteka text-sm sm:text-base">Creators</a></li>
              <li><a href="/brands" className="text-zinc-300 hover:text-white transition-colors font-khteka text-sm sm:text-base">For Brands</a></li>
              <li><a href="/login" className="text-zinc-300 hover:text-white transition-colors font-khteka text-sm sm:text-base">Log in</a></li>
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="text-white font-semibold mb-4 font-khinterference text-base sm:text-lg">Company</h4>
            <ul className="space-y-2">
              <li><a href="/about" className="text-zinc-300 hover:text-white transition-colors font-khteka text-sm sm:text-base">About</a></li>
              <li><a href="/legal" className="text-zinc-300 hover:text-white transition-colors font-khteka text-sm sm:text-base">Legal</a></li>
              <li><a href="/press" className="text-zinc-300 hover:text-white transition-colors font-khteka text-sm sm:text-base">Press</a></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-zinc-800 pt-6 sm:pt-8 flex flex-col sm:flex-row justify-between items-center gap-4">
          <BodySmall className="text-zinc-500">
            © 2025 Jungl ApS · <a href="/privacy" className="hover:text-white transition-colors">Privacy</a> · <a href="/legal/terms" className="hover:text-white transition-colors">Terms</a> · <a href="mailto:security@jungl.co" className="hover:text-white transition-colors">security@jungl.co</a>
          </BodySmall>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
