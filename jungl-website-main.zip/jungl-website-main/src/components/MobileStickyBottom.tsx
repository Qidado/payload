import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { X, ArrowUp } from 'lucide-react';
import { useScrollPercentage } from '@/hooks/useScrollPercentage';

const MobileStickyBottom = () => {
  const [isDismissed, setIsDismissed] = useState(false);
  const { isVisible } = useScrollPercentage(60);

  const handleRequestInvite = () => {
    // Track analytics event
    console.log('Mobile sticky CTA clicked');
    
    // Open App Store link
    window.open('https://apps.apple.com/dk/app/jungl-creator-business-hub/id6741893457', '_blank', 'noopener,noreferrer');
  };

  const handleDismiss = () => {
    setIsDismissed(true);
  };

  if (!isVisible || isDismissed) {
    return null;
  }

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 md:hidden animate-slide-in-bottom">
      <div className="bg-gradient-to-r from-zinc-900 to-black border-t border-zinc-800 px-4 py-3 shadow-2xl">
        <div className="flex items-center justify-between gap-3">
          <div className="flex-1">
            <p className="text-white text-sm font-medium">Ready to grow your creator business?</p>
            <p className="text-zinc-400 text-xs">Download Jungl now</p>
          </div>
          
          <div className="flex items-center gap-2">
            <Button
              onClick={handleRequestInvite}
              size="sm"
              className="bg-white text-black hover:bg-zinc-100 font-medium min-h-[44px] px-4"
            >
              <ArrowUp className="w-4 h-4 mr-1" />
              Get App
            </Button>
            
            <button
              onClick={handleDismiss}
              className="p-2 text-zinc-400 hover:text-white transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center"
              aria-label="Dismiss"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MobileStickyBottom;