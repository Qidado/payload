
import { FileText, Handshake, BarChart3, Briefcase, CheckCircle } from "lucide-react";
import { H2, BodyLarge, Body } from "./Typography";

const benefits = [
  {
    icon: Handshake,
    title: "Brand Partnership Hub",
    description: "Connect with brands that align with your values—no more cold outreach or gatekeepers.",
    highlight: "Find paid campaigns instantly"
  },
  {
    icon: Briefcase,
    title: "All-in-One Creator Dashboard",
    description: "Manage collaborations, track earnings, and showcase your work in one organized space.",
    highlight: "End the chaos of scattered tools"
  },
  {
    icon: FileText,
    title: "Professional Business Tools",
    description: "Generate invoices, contracts, and media kits that make you look like the professional you are.",
    highlight: "Get paid faster, look more credible"
  },
  {
    icon: BarChart3,
    title: "Real Growth Insights",
    description: "Understand what's actually working with clear analytics—not just vanity metrics.",
    highlight: "Focus on what drives results"
  }
];

const WhatYouGet = () => {
  return (
    <section className="py-16 sm:py-20 lg:py-24 px-4 sm:px-6 lg:px-8 bg-zinc-950">
      <div className="max-w-container mx-auto">
        <div className="text-center mb-12 sm:mb-16 scroll-fade">
          <H2 className="text-white mb-4 sm:mb-6" id="features-heading">
            What You Get as an Early Creator
          </H2>
          <BodyLarge className="text-zinc-300 max-w-3xl mx-auto">
            Everything you need to turn your content into a sustainable business—without the overwhelm.
          </BodyLarge>
        </div>

        <div className="grid gap-6 sm:gap-8 md:grid-cols-2">
          {benefits.map((benefit, index) => (
            <div 
              key={index} 
              className="scroll-fade p-6 sm:p-8 bg-zinc-900 border border-zinc-800 hover:bg-zinc-800 transition-all duration-300"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="flex items-start mb-4">
                <div className="p-3 bg-white/10 mr-4 flex-shrink-0 rounded-lg">
                  <benefit.icon className="h-6 w-6 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="text-white text-xl font-bold mb-2 font-khinterference">
                    {benefit.title}
                  </h3>
                  <div className="flex items-center mb-3">
                    <CheckCircle className="h-4 w-4 text-white mr-2 flex-shrink-0" />
                    <Body className="text-white font-medium text-sm">
                      {benefit.highlight}
                    </Body>
                  </div>
                </div>
              </div>
              <Body className="text-zinc-300">
                {benefit.description}
              </Body>
            </div>
          ))}
        </div>

        <div className="text-center mt-12 sm:mt-16 scroll-fade">
          <div className="inline-flex items-center justify-center p-4 bg-zinc-900 border border-zinc-800 rounded-lg">
            <CheckCircle className="h-5 w-5 text-white mr-2" />
            <Body className="text-white font-medium">
              Early Access = Lifetime discounts + Priority support + Shape the product
            </Body>
          </div>
        </div>
      </div>
    </section>
  );
};

export default WhatYouGet;
