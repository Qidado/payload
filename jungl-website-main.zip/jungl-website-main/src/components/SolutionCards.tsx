import { H2, H3, Body } from "./Typography";
import { CreditCard, Briefcase, Users } from "lucide-react";

const solutionCards = [
  {
    icon: CreditCard,
    title: "Finance",
    description: "One-click invoices, automated reminders, multi-currency payouts, and real-time earnings dashboard."
  },
  {
    icon: Briefcase,
    title: "Jobs",
    description: "Curated brand briefs that actually match your audience. Accept offers or counter in a tap."
  },
  {
    icon: Users,
    title: "Collaboration",
    description: "Secure file-sharing, shared calendars, and role-based access for agents & editors."
  }
];

const SolutionCards = () => {
  return (
    <div className="py-16 sm:py-20 lg:py-24 px-4 sm:px-6 lg:px-8 bg-black">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12 sm:mb-16 scroll-fade">
          <H2 className="text-white mb-6">
            Your Command Center
          </H2>
        </div>

        <div className="grid gap-8 md:grid-cols-3">
          {solutionCards.map((card, index) => (
            <div 
              key={index}
              className="scroll-fade bg-zinc-900 border border-zinc-800 p-8 rounded-lg hover:bg-zinc-800 transition-all duration-300"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="mb-6">
                <div className="w-12 h-12 bg-white/10 rounded-lg flex items-center justify-center mb-4">
                  <card.icon className="h-6 w-6 text-white" />
                </div>
                <H3 className="text-white mb-4">
                  {card.title}
                </H3>
              </div>
              <Body className="text-zinc-300">
                {card.description}
              </Body>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default SolutionCards;