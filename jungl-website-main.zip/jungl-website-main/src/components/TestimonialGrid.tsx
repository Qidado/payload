
import { H2, BodyLarge, Body, BodySmall } from "./Typography";

const testimonials = [
  {
    quote: "This took 4 hours off my week. I can finally focus on creating instead of admin.",
    name: "Sarah Chen",
    handle: "@sarahcreates",
    followers: "47K",
    image: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=400"
  },
  {
    quote: "Finally, a tool that gets it. I'm not a corporation, but I'm not a hobby either.",
    name: "Marcus Johnson",
    handle: "@mjvideo",
    followers: "128K",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400"
  },
  {
    quote: "Jungl made me feel like a real business owner, not just someone posting content.",
    name: "Luna Rodriguez",
    handle: "@lunalifestyle",
    followers: "89K",
    image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400"
  },
  {
    quote: "I went from spreadsheet chaos to organized professional in one weekend.",
    name: "David Park",
    handle: "@davidtech",
    followers: "156K",
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400"
  }
];

const TestimonialGrid = () => {
  return (
    <section className="py-16 sm:py-20 lg:py-24 px-4 sm:px-6 lg:px-8 bg-black">
      <div className="max-w-container mx-auto">
        <div className="text-center mb-12 sm:mb-16 scroll-fade">
          <H2 className="text-white mb-4 sm:mb-6">
            What creators are saying
          </H2>
          <BodyLarge className="text-zinc-300">
            Real feedback from real creators building real businesses.
          </BodyLarge>
        </div>

        <div className="grid gap-6 sm:gap-8 md:grid-cols-2">
          {testimonials.map((testimonial, index) => (
            <div 
              key={index}
              className="scroll-fade p-6 sm:p-8 bg-zinc-950 border border-zinc-800 hover:bg-zinc-900 transition-all duration-300"
              style={{ animationDelay: `${index * 150}ms` }}
            >
              <div className="flex items-start space-x-4">
                <img 
                  src={testimonial.image} 
                  alt={`Profile photo of ${testimonial.name}, content creator with ${testimonial.followers} followers`}
                  width="64"
                  height="64"
                  loading="lazy"
                  decoding="async"
                  className="w-12 h-12 sm:w-16 sm:h-16 object-cover border border-zinc-700 flex-shrink-0 rounded aspect-square"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.style.display = 'none';
                    const parent = target.parentElement;
                    if (parent && !parent.querySelector('.fallback-avatar')) {
                      const avatarDiv = document.createElement('div');
                      avatarDiv.className = 'fallback-avatar w-12 h-12 sm:w-16 sm:h-16 bg-zinc-800 border border-zinc-700 flex-shrink-0 rounded flex items-center justify-center';
                      avatarDiv.innerHTML = `
                        <svg class="w-6 h-6 sm:w-8 sm:h-8 text-zinc-600" fill="currentColor" viewBox="0 0 20 20">
                          <path fill-rule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clip-rule="evenodd" />
                        </svg>
                      `;
                      parent.insertBefore(avatarDiv, target);
                    }
                  }}
                />
                <div className="flex-1 min-w-0">
                  <div className="mb-4">
                    <Body className="text-white italic text-sm sm:text-base">
                      "{testimonial.quote}"
                    </Body>
                  </div>
                  <div>
                    <Body className="text-white font-medium text-sm sm:text-base">
                      {testimonial.name}
                    </Body>
                    <BodySmall className="text-zinc-400 text-xs sm:text-sm">
                      {testimonial.handle} • {testimonial.followers} followers
                    </BodySmall>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        {/* No-JavaScript fallback */}
        <noscript>
          <div className="grid gap-6 sm:gap-8 md:grid-cols-2">
            {testimonials.map((testimonial, index) => (
              <div 
                key={index}
                className="p-6 sm:p-8 bg-zinc-950 border border-zinc-800"
              >
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 sm:w-16 sm:h-16 bg-zinc-800 border border-zinc-700 flex-shrink-0 rounded flex items-center justify-center">
                    <svg className="w-6 h-6 sm:w-8 sm:h-8 text-zinc-600" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="mb-4">
                      <Body className="text-white italic text-sm sm:text-base">
                        "{testimonial.quote}"
                      </Body>
                    </div>
                    <div>
                      <Body className="text-white font-medium text-sm sm:text-base">
                        {testimonial.name}
                      </Body>
                      <BodySmall className="text-zinc-400 text-xs sm:text-sm">
                        {testimonial.handle} • {testimonial.followers} followers
                      </BodySmall>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </noscript>
      </div>
    </section>
  );
};

export default TestimonialGrid;
