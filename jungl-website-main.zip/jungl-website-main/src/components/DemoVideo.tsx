import { H2, Body } from "./Typography";
import { Play, Pause } from "lucide-react";
import { useState, useRef } from "react";
const DemoVideo = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };
  return <div className="min-h-screen flex items-center px-4 sm:px-6 lg:px-8 bg-black py-4 sm:py-8">
      <div className="max-w-4xl mx-auto text-center w-full">
        <div className="scroll-fade space-y-4 sm:space-y-8">
          <H2 className="text-white mb-4 sm:mb-6">
            How Jungl works...
          </H2>
          
          <Body className="text-zinc-300 text-base sm:text-lg max-w-2xl mx-auto mb-6 sm:mb-12">
            Find out more with<br />
            <br />
            made for you
          </Body>
          
          {/* Phone Mockup Container */}
          <div className="relative max-w-xs sm:max-w-sm mx-auto mb-6 sm:mb-12">
            <div className="relative bg-zinc-900 rounded-3xl overflow-hidden shadow-2xl border border-zinc-800 aspect-[9/19]">
              {/* Phone Content */}
              <div className="w-full h-full bg-zinc-900 flex items-center justify-center relative">
                <video ref={videoRef} className="w-full h-full object-cover rounded-3xl" loop muted playsInline onPlay={() => setIsPlaying(true)} onPause={() => setIsPlaying(false)} poster="/lovable-uploads/56495540-5978-42a9-b48e-d0df60b46803.png">
                  {/* Add video source when available */}
                  <source src="#" type="video/mp4" />
                </video>
                
                {/* Play/Pause Button Overlay */}
                <button onClick={togglePlay} className="absolute inset-0 flex items-center justify-center bg-black/20 hover:bg-black/30 transition-all duration-200 group rounded-3xl" aria-label={isPlaying ? "Pause video" : "Play video"}>
                  <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-full p-3 group-hover:bg-white/20 transition-all duration-200">
                    {isPlaying ? <Pause className="w-6 h-6 text-white" /> : <Play className="w-6 h-6 text-white ml-0.5" />}
                  </div>
                </button>
                
                {/* Fallback content when video isn't available */}
                <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-6 rounded-3xl">
                  <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-full p-4 mb-3">
                    <Play className="w-8 h-8 text-white" />
                  </div>
                  <Body className="text-white mb-2 text-sm">
                    15-Second Demo
                  </Body>
                  <Body className="text-zinc-400 text-xs px-4">
                    See Jungl streamline your workflow
                  </Body>
                </div>
              </div>
            </div>
          </div>
          
          {/* App Store Buttons */}
          <div className="flex flex-row gap-4 justify-center items-center">
            <a href="https://apps.apple.com/dk/app/jungl-creator-business-hub/id6741893457" className="block transition-opacity hover:opacity-80" aria-label="Download Jungl on the App Store" target="_blank" rel="noopener noreferrer">
              <img src="https://ehfsfqmzmrwzlgnbpyzz.supabase.co/storage/v1/object/public/assets//2.svg" alt="Download Jungl on the App Store" className="h-12 w-auto" onError={e => {
              const target = e.target as HTMLImageElement;
              target.style.display = 'none';
              const parent = target.parentElement;
              if (parent && !parent.querySelector('.fallback-appstore')) {
                const fallbackDiv = document.createElement('div');
                fallbackDiv.className = 'fallback-appstore h-12 px-6 bg-white text-black rounded-lg flex items-center text-sm font-medium';
                fallbackDiv.textContent = '📱 App Store';
                parent.appendChild(fallbackDiv);
              }
            }} />
            </a>
            
            <a href="#" className="block transition-opacity hover:opacity-80" aria-label="Download Jungl on Google Play" target="_blank" rel="noopener noreferrer">
              <img src="https://ehfsfqmzmrwzlgnbpyzz.supabase.co/storage/v1/object/public/assets//1.svg" alt="Get Jungl on Google Play" className="h-12 w-auto" onError={e => {
              const target = e.target as HTMLImageElement;
              target.style.display = 'none';
              const parent = target.parentElement;
              if (parent && !parent.querySelector('.fallback-googleplay')) {
                const fallbackDiv = document.createElement('div');
                fallbackDiv.className = 'fallback-googleplay h-12 px-6 bg-zinc-800 text-white rounded-lg flex items-center text-sm font-medium border border-zinc-600';
                fallbackDiv.textContent = '📱 Google Play';
                parent.appendChild(fallbackDiv);
              }
            }} />
            </a>
          </div>
        </div>
      </div>
    </div>;
};
export default DemoVideo;