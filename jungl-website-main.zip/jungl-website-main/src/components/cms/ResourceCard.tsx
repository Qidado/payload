import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Resource } from "../../payload/payload-types"
import { Clock, ExternalLink, Download } from "lucide-react"

interface ResourceCardProps {
  resource: Resource
  className?: string
}

export const ResourceCard = ({ resource, className }: ResourceCardProps) => {
  const handleClick = () => {
    if (resource.externalUrl) {
      window.open(resource.externalUrl, '_blank')
    } else if (resource.downloadUrl) {
      window.open(resource.downloadUrl, '_blank')
    } else {
      // Navigate to resource detail page
      window.location.href = `/resources/${resource.slug}`
    }
  }

  return (
    <Card 
      className={`cursor-pointer transition-all duration-300 hover:shadow-lg hover:scale-[1.02] ${className}`}
      onClick={handleClick}
    >
      {resource.image && (
        <div className="aspect-video overflow-hidden rounded-t-lg">
          <img 
            src={resource.image} 
            alt={resource.title}
            className="w-full h-full object-cover"
          />
        </div>
      )}
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-2">
          <CardTitle className="text-lg leading-tight">{resource.title}</CardTitle>
          {(resource.externalUrl || resource.downloadUrl) && (
            <div className="flex-shrink-0">
              {resource.downloadUrl ? (
                <Download className="h-4 w-4 text-muted-foreground" />
              ) : (
                <ExternalLink className="h-4 w-4 text-muted-foreground" />
              )}
            </div>
          )}
        </div>
        <CardDescription className="line-clamp-2">
          {resource.description}
        </CardDescription>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="flex flex-wrap gap-2 mb-3">
          <Badge variant="secondary" className="text-xs">
            {resource.type}
          </Badge>
          {typeof resource.category === 'object' && resource.category?.name && (
            <Badge variant="outline" className="text-xs">
              {resource.category.name}
            </Badge>
          )}
          {resource.difficulty && (
            <Badge 
              variant={resource.difficulty === 'beginner' ? 'default' : 
                     resource.difficulty === 'intermediate' ? 'secondary' : 'destructive'} 
              className="text-xs"
            >
              {resource.difficulty}
            </Badge>
          )}
        </div>
        
        {resource.estimatedTime && (
          <div className="flex items-center gap-1 text-sm text-muted-foreground">
            <Clock className="h-3 w-3" />
            <span>{resource.estimatedTime}</span>
          </div>
        )}
        
        {resource.tags && resource.tags.length > 0 && (
          <div className="flex flex-wrap gap-1 mt-2">
            {resource.tags.slice(0, 3).map((tagObj, index) => (
              <span 
                key={index} 
                className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded"
              >
                {typeof tagObj === 'object' && tagObj.tag ? tagObj.tag : String(tagObj)}
              </span>
            ))}
            {resource.tags.length > 3 && (
              <span className="text-xs text-muted-foreground">
                +{resource.tags.length - 3} more
              </span>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  )
}