import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Post } from "../../payload/payload-types"
import { Clock, Calendar, User } from "lucide-react"
import { format } from "date-fns"

interface BlogPostCardProps {
  post: Post
  className?: string
}

export const BlogPostCard = ({ post, className }: BlogPostCardProps) => {
  const handleClick = () => {
    window.location.href = `/blog/${post.slug}`
  }

  return (
    <Card 
      className={`cursor-pointer transition-all duration-300 hover:shadow-lg hover:scale-[1.02] ${className}`}
      onClick={handleClick}
    >
      {post.featuredImage && (
        <div className="aspect-video overflow-hidden rounded-t-lg">
          <img 
            src={post.featuredImage} 
            alt={post.title}
            className="w-full h-full object-cover"
          />
        </div>
      )}
      <CardHeader className="pb-3">
        <CardTitle className="text-lg leading-tight line-clamp-2">{post.title}</CardTitle>
        <CardDescription className="line-clamp-2">
          {post.excerpt}
        </CardDescription>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="flex flex-wrap gap-2 mb-3">
          {typeof post.category === 'object' && post.category?.name && (
            <Badge variant="secondary" className="text-xs">
              {post.category.name}
            </Badge>
          )}
          {post.tags && post.tags.slice(0, 2).map((tagObj, index) => (
            <Badge key={index} variant="outline" className="text-xs">
              {typeof tagObj === 'object' && tagObj.tag ? tagObj.tag : String(tagObj)}
            </Badge>
          ))}
        </div>
        
        <div className="flex items-center justify-between text-sm text-muted-foreground">
          <div className="flex items-center gap-4">
            {post.publishedAt && (
              <div className="flex items-center gap-1">
                <Calendar className="h-3 w-3" />
                <span>{format(new Date(post.publishedAt), 'MMM d, yyyy')}</span>
              </div>
            )}
            {post.readTime && (
              <div className="flex items-center gap-1">
                <Clock className="h-3 w-3" />
                <span>{post.readTime} min read</span>
              </div>
            )}
          </div>
          
          {typeof post.author === 'object' && post.author?.name && (
            <div className="flex items-center gap-1">
              <User className="h-3 w-3" />
              <span className="text-xs">{post.author.name}</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}