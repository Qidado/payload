import { H2, Body, BodySmall } from "@/components/Typography";
import { FileX, Clock, DollarSign, MessageSquareX, Calculator, Inbox } from "lucide-react";

const ProblemOption4 = () => {
  const problems = [
    {
      icon: FileX,
      title: "Missing Paperwork",
      description: "Constantly chasing brands for contracts, tax forms, and basic business details",
      stat: "47%",
      statLabel: "payment delays"
    },
    {
      icon: Clock,
      title: "Payment Delays",
      description: "Waiting 30-90 days for payments while your bills arrive monthly",
      stat: "78%",
      statLabel: "late payments"
    },
    {
      icon: MessageSquareX,
      title: "Ghosted Communications",
      description: "Endless back-and-forth emails with no clear process or accountability",
      stat: "63%",
      statLabel: "ignored emails"
    },
    {
      icon: DollarSign,
      title: "Pricing Confusion",
      description: "No clear rates or standards, making every negotiation a guessing game",
      stat: "52%",
      statLabel: "undercharge"
    },
    {
      icon: Calculator,
      title: "Tax Season Panic",
      description: "Scrambling to organize a year's worth of chaotic financial records",
      stat: "89%",
      statLabel: "stress levels"
    },
    {
      icon: Inbox,
      title: "Inbox Overwhelm",
      description: "Managing dozens of brand relationships across email, DMs, and platforms",
      stat: "13+",
      statLabel: "hours weekly"
    }
  ];

  return (
    <div className="py-16 sm:py-20 lg:py-24 px-4 sm:px-6 lg:px-8 bg-zinc-950">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <H2 className="text-white mb-6">
            The Admin Trap Is Killing Your Creativity
          </H2>
          <Body className="text-zinc-300 text-lg max-w-3xl mx-auto">
            Every hour spent on admin is an hour not spent creating. Here's what's stealing your time and killing your momentum.
          </Body>
        </div>

        {/* Problems Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {problems.map((problem, index) => {
            const Icon = problem.icon;
            return (
              <div
                key={index}
                className="group bg-zinc-900/50 p-6 rounded-xl border border-zinc-800 hover:border-zinc-600 hover:bg-zinc-800/50 transition-all duration-300 hover:-translate-y-1"
              >
                <div className="flex items-center gap-4 mb-4">
                  <div className="bg-red-500/10 p-3 rounded-lg">
                    <Icon className="h-6 w-6 text-red-400" />
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-white">{problem.stat}</div>
                    <div className="text-xs text-zinc-400">{problem.statLabel}</div>
                  </div>
                </div>
                
                <h3 className="text-lg font-semibold text-white mb-3 group-hover:text-white transition-colors">
                  {problem.title}
                </h3>
                
                <Body className="text-zinc-400 group-hover:text-zinc-300 transition-colors">
                  {problem.description}
                </Body>
              </div>
            );
          })}
        </div>

        {/* Central Message */}
        <div className="text-center bg-zinc-900/50 p-8 rounded-xl border border-zinc-800">
          <div className="text-5xl font-bold text-white mb-4">34%</div>
          <Body className="text-zinc-300 text-lg mb-4">
            of creator time spent on administrative tasks instead of creating
          </Body>
          <BodySmall className="text-zinc-500 italic">
            Source: Jungl user survey, June 2025 (n = 112)
          </BodySmall>
        </div>
      </div>
    </div>
  );
};

export default ProblemOption4;