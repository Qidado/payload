import { HeroDisplay, H2, Body, BodyLarge, BodySmall, AlternateDisplay } from "@/components/Typography";
import { Button } from "@/components/ui/button";
import { Zap, Sparkles, CreditCard, Search, Clock, MessageSquare, CheckCircle, ArrowRight } from "lucide-react";
const ProblemOption5 = () => {
  const painSolutions = [{
    pain: "Manual invoice templates",
    solution: "60-second invoicing with auto-reminders",
    painIcon: CreditCard,
    solutionIcon: CheckCircle
  }, {
    pain: "\"Any upcoming collabs?\" hunt",
    solution: "Ready-to-apply brand briefs chosen for your audience",
    painIcon: Search,
    solutionIcon: CheckCircle
  }, {
    pain: "Chasing late payments",
    solution: "Automated collections + instant payouts when brands pay",
    painIcon: Clock,
    solutionIcon: CheckCircle
  }, {
    pain: "Scattered DMs & contracts",
    solution: "Unified chat + workspace for every collab",
    painIcon: MessageSquare,
    solutionIcon: CheckCircle
  }];
  return <div className="min-h-screen flex items-center px-4 sm:px-6 lg:px-8 bg-black py-8">
      <div className="max-w-4xl mx-auto w-full">
        {/* Hero Header */}
        <div className="text-center mb-16">
          <HeroDisplay className="text-white mb-6 font-bold tracking-tight">
            COLLAB → INVOICE → PAYDAY.
          </HeroDisplay>
          <Body className="text-zinc-300 mb-8">
            One app. Zero admin.
          </Body>
          
        </div>

        {/* Micro-Explanation Block */}
        <div className="grid md:grid-cols-2 gap-8 mb-16">
          {/* What Jungl Kills */}
          <div className="bg-red-50 border border-red-200 rounded-xl p-8">
            <div className="flex items-center mb-6">
              <Zap className="h-6 w-6 text-red-600 mr-3" />
              <AlternateDisplay className="text-red-600">What Jungl Kills</AlternateDisplay>
            </div>
            <div className="space-y-6">
              {painSolutions.map((item, index) => <div key={index} className="flex items-start space-x-4">
                  <item.painIcon className="h-5 w-5 text-red-600 mt-1 flex-shrink-0" />
                  <BodySmall className="text-red-700">{item.pain}</BodySmall>
                </div>)}
            </div>
          </div>

          {/* What You Get */}
          <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-8">
            <div className="flex items-center mb-6">
              <Sparkles className="h-6 w-6 text-emerald-600 mr-3" />
              <AlternateDisplay className="text-emerald-600">What You Get</AlternateDisplay>
            </div>
            <div className="space-y-6">
              {painSolutions.map((item, index) => <div key={index} className="flex items-start space-x-4">
                  <item.solutionIcon className="h-5 w-5 text-emerald-600 mt-1 flex-shrink-0" />
                  <BodySmall className="text-emerald-700">{item.solution}</BodySmall>
                </div>)}
            </div>
          </div>
        </div>

        {/* Closing Statement */}
        <div className="text-center bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 rounded-xl p-8">
          <H2 className="text-black mb-4">
            Stop the busywork. Start earning.
          </H2>
          <BodySmall className="text-zinc-700">
            Creators already use Jungl to reclaim <span className="text-emerald-600 font-bold">13h/week</span>—now it's your turn.
          </BodySmall>
        </div>
      </div>
    </div>;
};
export default ProblemOption5;