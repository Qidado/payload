import { H2, Body, BodySmall } from "@/components/Typography";
import { Clock, FileText, DollarSign, Frown } from "lucide-react";
import { useState } from "react";

const ProblemOption2 = () => {
  const [activeStep, setActiveStep] = useState<number | null>(null);

  const timelineSteps = [
    {
      time: "9:00 AM",
      icon: Clock,
      title: "Start Your Day",
      description: "Ready to create amazing content",
      mood: "😊",
      color: "bg-green-500"
    },
    {
      time: "10:30 AM",
      icon: FileText,
      title: "Invoice Chase Begins",
      description: "Three brands haven't paid. Time to follow up... again.",
      mood: "😐",
      color: "bg-yellow-500"
    },
    {
      time: "12:00 PM",
      icon: DollarSign,
      title: "Payment Drama",
      description: "Brand claims they never received your tax forms. For the third time.",
      mood: "😠",
      color: "bg-orange-500"
    },
    {
      time: "3:00 PM",
      icon: FileText,
      title: "Spreadsheet Hell",
      description: "Updating 47 different tracking sheets. Still can't find that contract.",
      mood: "😵",
      color: "bg-red-500"
    },
    {
      time: "6:00 PM",
      icon: Frown,
      title: "Day Lost",
      description: "No content created. No progress made. Just admin.",
      mood: "😞",
      color: "bg-zinc-500"
    }
  ];

  return (
    <div className="py-16 sm:py-20 lg:py-24 px-4 sm:px-6 lg:px-8 bg-zinc-950">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-16">
          <H2 className="text-white mb-6">
            A Day in the Life: The Admin Trap
          </H2>
          <Body className="text-zinc-300 text-lg">
            Watch how administrative tasks slowly drain a creator's productivity and passion
          </Body>
        </div>

        {/* Timeline */}
        <div className="relative">
          {/* Vertical line */}
          <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-zinc-700"></div>
          
          <div className="space-y-8">
            {timelineSteps.map((step, index) => {
              const Icon = step.icon;
              return (
                <div
                  key={index}
                  className="relative cursor-pointer group"
                  onMouseEnter={() => setActiveStep(index)}
                  onMouseLeave={() => setActiveStep(null)}
                >
                  {/* Timeline dot */}
                  <div className={`absolute left-6 w-4 h-4 rounded-full border-2 border-zinc-700 transition-all duration-300 ${
                    activeStep === index ? step.color : 'bg-zinc-900'
                  }`}></div>
                  
                  {/* Content */}
                  <div className={`ml-16 p-6 rounded-xl border transition-all duration-300 ${
                    activeStep === index 
                      ? 'bg-zinc-800/80 border-zinc-600 scale-102' 
                      : 'bg-zinc-900/50 border-zinc-800'
                  }`}>
                    <div className="flex items-center gap-4 mb-3">
                      <Icon className={`h-5 w-5 transition-colors duration-300 ${
                        activeStep === index ? 'text-white' : 'text-zinc-400'
                      }`} />
                      <span className="text-sm font-medium text-zinc-400">{step.time}</span>
                      <span className="text-lg">{step.mood}</span>
                    </div>
                    
                    <h3 className={`text-lg font-semibold mb-2 transition-colors duration-300 ${
                      activeStep === index ? 'text-white' : 'text-zinc-300'
                    }`}>
                      {step.title}
                    </h3>
                    
                    <Body className={`transition-colors duration-300 ${
                      activeStep === index ? 'text-zinc-200' : 'text-zinc-400'
                    }`}>
                      {step.description}
                    </Body>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Bottom Stats */}
        <div className="mt-16 text-center bg-zinc-900/50 p-8 rounded-xl border border-zinc-800">
          <div className="text-4xl font-bold text-white mb-2">34%</div>
          <Body className="text-zinc-300 mb-4">of creator time spent on admin</Body>
          <BodySmall className="text-zinc-500 italic">
            Source: Jungl user survey, June 2025 (n = 112)
          </BodySmall>
        </div>
      </div>
    </div>
  );
};

export default ProblemOption2;