import { H2, Body, BodySmall } from "@/components/Typography";
import { X } from "lucide-react";

const ProblemOption3 = () => {
  return (
    <div className="py-16 sm:py-20 lg:py-24 px-4 sm:px-6 lg:px-8 bg-zinc-950">
      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Image Column */}
          <div className="order-2 lg:order-1">
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1581090464777-f3220bbe1b8b?auto=format&fit=crop&w=800&q=80"
                alt="Overwhelmed creator working on laptop with multiple tasks"
                className="w-full h-[500px] object-cover rounded-2xl"
                onError={(e) => {
                  e.currentTarget.style.display = 'none';
                  e.currentTarget.nextElementSibling?.classList.remove('hidden');
                }}
              />
              <div className="hidden w-full h-[500px] bg-zinc-800 rounded-2xl flex items-center justify-center">
                <span className="text-zinc-400">Creator workspace image</span>
              </div>
              {/* Overlay with stat */}
              <div className="absolute top-6 right-6 bg-black/80 backdrop-blur-sm rounded-lg p-4 border border-zinc-700">
                <div className="text-3xl font-bold text-white mb-1">34%</div>
                <div className="text-sm text-zinc-300">of creator time</div>
                <div className="text-xs text-zinc-400">spent on admin</div>
              </div>
            </div>
          </div>

          {/* Content Column */}
          <div className="order-1 lg:order-2 space-y-8">
            <div>
              <H2 className="text-white mb-6">
                The Admin Trap Is Killing Your Creativity
              </H2>
              
              <Body className="text-zinc-300 text-lg mb-8">
                While you're drowning in spreadsheets and chasing invoices, your competitors are creating. The endless admin work isn't just boring—it's costing you money and momentum.
              </Body>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-start">
                <X className="h-5 w-5 text-red-400 mr-4 flex-shrink-0 mt-1" />
                <div>
                  <Body className="text-white font-medium mb-1">Late payments & missing paperwork</Body>
                  <Body className="text-zinc-400 text-sm">Chasing brands for basic business details</Body>
                </div>
              </div>
              <div className="flex items-start">
                <X className="h-5 w-5 text-red-400 mr-4 flex-shrink-0 mt-1" />
                <div>
                  <Body className="text-white font-medium mb-1">Ghosted brand conversations</Body>
                  <Body className="text-zinc-400 text-sm">Endless back-and-forth with no clear process</Body>
                </div>
              </div>
              <div className="flex items-start">
                <X className="h-5 w-5 text-red-400 mr-4 flex-shrink-0 mt-1" />
                <div>
                  <Body className="text-white font-medium mb-1">Tax season anxiety</Body>
                  <Body className="text-zinc-400 text-sm">Scrambling to organize a year of chaos</Body>
                </div>
              </div>
            </div>
            
            <BodySmall className="text-zinc-500 italic border-l-2 border-zinc-700 pl-4">
              Source: Jungl user survey, June 2025 (n = 112). 34% of creators report spending over 13 hours per week on administrative tasks.
            </BodySmall>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProblemOption3;