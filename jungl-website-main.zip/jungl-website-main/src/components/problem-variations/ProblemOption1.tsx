import { H2, Body, BodySmall } from "@/components/Typography";
import { TrendingDown, Clock, FileX } from "lucide-react";
import { useEffect, useState } from "react";

const ProblemOption1 = () => {
  const [animatedCount, setAnimatedCount] = useState(0);

  useEffect(() => {
    const timer = setTimeout(() => {
      let count = 0;
      const interval = setInterval(() => {
        count += 1;
        setAnimatedCount(count);
        if (count >= 34) {
          clearInterval(interval);
        }
      }, 50);
    }, 500);

    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="py-16 sm:py-20 lg:py-24 px-4 sm:px-6 lg:px-8 bg-zinc-950">
      <div className="max-w-6xl mx-auto text-center">
        <H2 className="text-white mb-16">
          The Admin Trap Is Killing Your Creativity
        </H2>
        
        {/* Central Statistic */}
        <div className="relative mb-16">
          <div className="text-8xl sm:text-9xl md:text-[12rem] font-bold text-white mb-4 font-khinterference">
            {animatedCount}%
          </div>
          <div className="text-xl sm:text-2xl text-zinc-300 mb-2">of creator time</div>
          <div className="text-lg text-zinc-400 mb-8">spent on admin work</div>
          
          {/* Progress Bar */}
          <div className="max-w-md mx-auto bg-zinc-800 rounded-full h-3 mb-8">
            <div 
              className="bg-red-500 h-3 rounded-full transition-all duration-2000 ease-out"
              style={{ width: `${animatedCount}%` }}
            />
          </div>
        </div>

        {/* Statistics Grid */}
        <div className="grid sm:grid-cols-3 gap-8 mb-12">
          <div className="bg-zinc-900/50 p-6 rounded-xl border border-zinc-800">
            <TrendingDown className="h-8 w-8 text-red-400 mx-auto mb-4" />
            <div className="text-3xl font-bold text-white mb-2">13+</div>
            <Body className="text-zinc-300">hours per week</Body>
            <BodySmall className="text-zinc-500 mt-2">lost to admin tasks</BodySmall>
          </div>
          
          <div className="bg-zinc-900/50 p-6 rounded-xl border border-zinc-800">
            <Clock className="h-8 w-8 text-red-400 mx-auto mb-4" />
            <div className="text-3xl font-bold text-white mb-2">47%</div>
            <Body className="text-zinc-300">payment delays</Body>
            <BodySmall className="text-zinc-500 mt-2">due to missing paperwork</BodySmall>
          </div>
          
          <div className="bg-zinc-900/50 p-6 rounded-xl border border-zinc-800">
            <FileX className="h-8 w-8 text-red-400 mx-auto mb-4" />
            <div className="text-3xl font-bold text-white mb-2">78%</div>
            <Body className="text-zinc-300">stressed creators</Body>
            <BodySmall className="text-zinc-500 mt-2">during tax season</BodySmall>
          </div>
        </div>
        
        <Body className="text-zinc-300 text-lg max-w-3xl mx-auto mb-8">
          While you're drowning in spreadsheets and chasing invoices, your competitors are creating. The endless admin work isn't just boring—it's costing you money and momentum.
        </Body>
        
        <BodySmall className="text-zinc-500 italic">
          Source: Jungl user survey, June 2025 (n = 112)
        </BodySmall>
      </div>
    </div>
  );
};

export default ProblemOption1;