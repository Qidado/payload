import { H2, BodyLarge, HeroDisplay } from "@/components/Typography";
import { Button } from "@/components/ui/button";
import { ArrowRight, Target, TrendingUp, DollarSign } from "lucide-react";
const KeyDifferentiator = () => {
  return <section className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8 bg-black text-white lg:py-24">
      <div className="max-w-6xl mx-auto text-center">
        <div className="inline-block bg-zinc-800 text-zinc-300 px-4 py-2 rounded-full text-sm font-medium mb-6">
          Coming Soon
        </div>
        
        <HeroDisplay className="text-white mb-4 text-2xl sm:text-3xl lg:text-4xl">
          Stop Paying for Likes.
        </HeroDisplay>
        
        <BodyLarge className="text-zinc-300 mb-12 lg:mb-16 max-w-3xl mx-auto text-sm sm:text-base lg:text-lg">
          With Jungl, you only pay when creators drive real sales. No fluff. No wasted spend.
        </BodyLarge>
        
        {/* Conversion Funnel */}
        <div className="flex flex-col lg:flex-row justify-center items-center gap-6 lg:gap-12 mb-12 lg:mb-16">
          <div className="flex flex-col items-center bg-zinc-900 rounded-lg p-6 lg:p-8 w-full lg:w-72">
            <Target className="w-10 h-10 lg:w-12 lg:h-12 text-white mb-4" />
            <div className="text-lg lg:text-xl font-bold text-white mb-2 text-center">CREATORS GO LIVE</div>
            <div className="text-sm text-zinc-400 text-center">Authentic content goes live</div>
          </div>
          
          <ArrowRight className="w-6 h-6 lg:w-8 lg:h-8 text-zinc-400 rotate-90 lg:rotate-0" />
          
          <div className="flex flex-col items-center bg-zinc-900 rounded-lg p-6 lg:p-8 w-full lg:w-72">
            <TrendingUp className="w-10 h-10 lg:w-12 lg:h-12 text-white mb-4" />
            <div className="text-lg lg:text-xl font-bold text-white mb-2 text-center">SALES TRACKED REAL-TIME</div>
            <div className="text-sm text-zinc-400 text-center">Revenue tracked in real-time</div>
          </div>
          
          <ArrowRight className="w-6 h-6 lg:w-8 lg:h-8 text-zinc-400 rotate-90 lg:rotate-0" />
          
          <div className="flex flex-col items-center bg-zinc-900 rounded-lg p-6 lg:p-8 w-full lg:w-72">
            <DollarSign className="w-10 h-10 lg:w-12 lg:h-12 text-white mb-4" />
            <div className="text-lg lg:text-xl font-bold text-white mb-2 text-center">YOU ONLY PAY FOR SALES</div>
            <div className="text-sm text-zinc-400 text-center">Only for verified sales</div>
          </div>
        </div>

        {/* CTA Section */}
        
      </div>
    </section>;
};
export default KeyDifferentiator;