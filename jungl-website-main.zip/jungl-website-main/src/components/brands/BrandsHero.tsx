import { HeroMegaDisplay, BodyLarge } from "@/components/Typography";
import { Button } from "@/components/ui/button";
import { ChevronDown } from "lucide-react";
const BrandsHero = () => {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({
        behavior: 'smooth'
      });
    }
  };
  return <section id="hero" className="relative h-screen w-full overflow-hidden bg-white" itemScope itemType="https://schema.org/Service">
      {/* Light gradient background */}
      <div className="absolute inset-0 bg-gradient-to-br from-white via-zinc-50 to-white z-10" />
      
      {/* Grain texture */}
      <div className="absolute inset-0 opacity-5 bg-[url('/grain.svg')] z-20" />

      {/* Hero Content */}
      <div className="relative z-30 flex flex-col items-center justify-center text-center h-full px-4 sm:px-6">
        <div className="animate-fade-in max-w-4xl mx-auto">
          {/* Early Access Badge */}
          

          <HeroMegaDisplay className="text-black mb-6" itemProp="name">Only pay creators when you see results.</HeroMegaDisplay>
          
          <BodyLarge className="text-zinc-600 mb-8 max-w-3xl mx-auto" itemProp="description">Find, brief, and pay verified creators — risk-free, performance-only, zero subscriptions.</BodyLarge>
          
          <div className="flex flex-col gap-4 justify-center items-center w-full max-w-sm mx-auto sm:max-w-none sm:flex-row sm:gap-6">
            <Button size="lg" className="bg-black text-white hover:bg-zinc-800 hover:shadow-lg hover:scale-[1.02] focus:ring-2 focus:ring-black focus:ring-offset-2 focus:ring-offset-white px-6 py-3 text-base sm:px-8 sm:py-4 sm:text-lg font-khteka font-medium transition-all duration-200 w-full sm:w-auto" title="Secure my slot" asChild>
              <a href="https://getjungl.link/D3lpkHD" target="_blank" rel="noopener noreferrer">
                Start your first campaign free
              </a>
            </Button>
            
            <button onClick={() => scrollToSection('how')} className="text-black/80 hover:text-black text-sm sm:text-base font-khteka underline underline-offset-4 hover:underline-offset-2 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-black/50 rounded px-2 py-1">
              Watch 60‑sec overview ↓
            </button>
          </div>

          {/* Social Proof */}
          <div className="flex items-center justify-center gap-4 mt-6 text-zinc-600 text-sm">
            <div className="flex items-center gap-1">
              <div className="w-2 h-2 bg-black rounded-full"></div>
              <span>28 brands joined</span>
            </div>
            <div className="w-px h-4 bg-zinc-400"></div>
            <div className="flex items-center gap-1">
              <div className="w-2 h-2 bg-zinc-600 rounded-full"></div>
              <span>22 spots left</span>
            </div>
          </div>
        </div>
      </div>
    </section>;
};
export default BrandsHero;