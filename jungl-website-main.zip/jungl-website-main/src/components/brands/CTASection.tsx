import { H2 } from "@/components/Typography";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
const CTASection = () => {
  return (
    <div className="py-24 px-4 bg-primary text-primary-foreground">
      <div className="max-w-4xl mx-auto text-center">
        <H2 className="mb-6">Ready to transform your creator campaigns?</H2>
        <p className="text-xl mb-8 opacity-90">
          Join forward-thinking brands who've ditched the spreadsheets and embrace efficient creator marketing.
        </p>
        <Button size="lg" variant="secondary" className="group">
          Get Early Access
          <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
        </Button>
      </div>
    </div>
  );
};
export default CTASection;