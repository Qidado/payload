import { H2, BodyLarge, Body } from "@/components/Typography";
import { Star } from "lucide-react";
const ProofSection = () => {
  return null;
};
export default ProofSection;