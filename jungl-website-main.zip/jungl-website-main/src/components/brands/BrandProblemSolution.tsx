import { H2, H3, HeroDisplay, BodyLarge, AlternateDisplay } from "@/components/Typography";
import { X, Check } from "lucide-react";
const BrandProblemSolution = () => {
  const painSolutions = [{
    pain: "Paying for stuff that doesn't work",
    solution: "Verified creators apply directly to your briefs",
    painIcon: X,
    solutionIcon: Check
  }, {
    pain: "Wasting hours chasing creators",
    solution: "Audience insights you can trust",
    painIcon: X,
    solutionIcon: Check
  }, {
    pain: "Expensive subscriptions and contracts",
    solution: "Automated payouts handled in one place",
    painIcon: X,
    solutionIcon: Check
  }, {
    pain: "Campaign chaos spread across spreadsheets",
    solution: "Real-time ROI tracking (Soon Affiliate)",
    painIcon: X,
    solutionIcon: Check
  }];
  return <section className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8 bg-zinc-800 lg:py-24">
      <div className="max-w-6xl mx-auto">
        {/* Hero Section */}
        <div className="text-center mb-12 lg:mb-16">
          <HeroDisplay className="text-white mb-4 lg:mb-6 text-2xl sm:text-3xl lg:text-4xl">
            DISCOVER → COLLABORATE → CONVERT
          </HeroDisplay>
          <H2 className="text-zinc-300 font-normal text-lg sm:text-xl lg:text-2xl">
            One platform. Zero outreach.
          </H2>
        </div>

        {/* Problem vs Solution Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-8 mb-12 lg:mb-16">
          {/* What Jungl Kills */}
          <div className="bg-white rounded-2xl p-6 lg:p-8 border border-zinc-200">
            <div className="text-center mb-6 lg:mb-8">
              <AlternateDisplay className="text-red-600 mb-2 text-sm sm:text-base">WHAT JUNGL KILLS</AlternateDisplay>
              <div className="w-16 h-1 bg-red-600 mx-auto"></div>
            </div>
            <div className="space-y-4 lg:space-y-6">
              {painSolutions.map((item, index) => <div key={index} className="flex items-start gap-3 lg:gap-4">
                  <div className="bg-red-100 rounded-full p-2 flex-shrink-0">
                    <item.painIcon className="w-4 h-4 lg:w-5 lg:h-5 text-red-600" />
                  </div>
                  <BodyLarge className="text-zinc-800 text-sm sm:text-base">{item.pain}</BodyLarge>
                </div>)}
            </div>
          </div>

          {/* What You Get */}
          <div className="bg-white rounded-2xl p-6 lg:p-8 border border-zinc-200">
            <div className="text-center mb-6 lg:mb-8">
              <AlternateDisplay className="text-green-600 mb-2 text-sm sm:text-base">WHAT YOU GET</AlternateDisplay>
              <div className="w-16 h-1 bg-green-600 mx-auto"></div>
            </div>
            <div className="space-y-4 lg:space-y-6">
              {painSolutions.map((item, index) => <div key={index} className="flex items-start gap-3 lg:gap-4">
                  <div className="bg-green-100 rounded-full p-2 flex-shrink-0">
                    <item.solutionIcon className="w-4 h-4 lg:w-5 lg:h-5 text-green-600" />
                  </div>
                  <BodyLarge className="text-zinc-800 text-sm sm:text-base">{item.solution}</BodyLarge>
                </div>)}
            </div>
          </div>
        </div>

        {/* Bottom CTA */}
        <div className="text-center px-4">
          <HeroDisplay className="text-white mb-4 text-xl sm:text-2xl lg:text-3xl">
            STOP THE CHAOS. START CONVERTING.
          </HeroDisplay>
          <BodyLarge className="text-zinc-300 text-sm sm:text-base lg:text-lg">
            Brands already save 20+ hours/week with Jungl—now it's your turn.
          </BodyLarge>
        </div>
      </div>
    </section>;
};
export default BrandProblemSolution;