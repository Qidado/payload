import { H2, BodyLarge } from "@/components/Typography";
import { Button } from "@/components/ui/button";
import { trackCTAClick } from "@/lib/posthog";

const FooterCTA = () => {
  const handleCTAClick = () => {
    trackCTAClick("brands_beta_signup", "footer_cta", "https://getjungl.link/D3lpkHD");
  };

  return (
    <section className="py-16 sm:py-20 lg:py-24 px-4 sm:px-6 lg:px-8 bg-white">
      <div className="max-w-4xl mx-auto text-center">
        <H2 className="text-black mb-6">
          Ready to activate top creators in 24 hours?
        </H2>
        <BodyLarge className="text-zinc-700 mb-8 text-lg">
          Join leading brands who trust Jungl to connect them with creators that drive real results.
        </BodyLarge>
        <Button 
          size="lg"
          className="bg-black text-white hover:bg-zinc-800 hover:shadow-lg hover:scale-[1.02] focus:ring-2 focus:ring-black focus:ring-offset-2 focus:ring-offset-white px-8 py-4 text-lg font-khteka font-medium transition-all duration-200"
          title="Secure my slot"
          asChild
        >
          <a href="https://getjungl.link/D3lpkHD" target="_blank" rel="noopener noreferrer" onClick={handleCTAClick}>
            Apply For Beta Access →
          </a>
        </Button>
        <div className="mt-4">
          <BodyLarge className="text-zinc-600 text-sm">
            Crunching audience data…
          </BodyLarge>
        </div>
      </div>
    </section>
  );
};

export default FooterCTA;