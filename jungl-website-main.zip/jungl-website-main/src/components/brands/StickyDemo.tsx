import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { trackCTAClick } from "@/lib/posthog";
const StickyDemo = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      // Show sticky CTA after scrolling past hero (roughly 100vh)
      const scrollPosition = window.scrollY;
      const windowHeight = window.innerHeight;
      setIsVisible(scrollPosition > windowHeight * 0.8);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  if (!isVisible) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50 animate-slide-in-bottom">
      <Button 
        size="lg"
        className="bg-white text-black hover:bg-white/90 shadow-lg"
        title="Secure my slot"
        asChild
      >
        <a href="/book-demo" onClick={() => trackCTAClick('book_demo', 'sticky', '/book-demo')}>
          Book a demo →
        </a>
      </Button>
    </div>
  );
};

export default StickyDemo;