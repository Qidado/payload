import { H2, H3, Body } from "@/components/Typography";
import { 
  Accordion, 
  AccordionContent, 
  AccordionItem, 
  AccordionTrigger 
} from "@/components/ui/accordion";

const BrandsFAQ = () => {
  const faqs = [
    {
      question: "Do creators see my budget?",
      answer: "Only after you approve them. You control final offers."
    },
    {
      question: "Which markets are supported?",
      answer: "EU, UK, US, CA for payments; any country for organic seeding."
    },
    {
      question: "How are fraud & fake followers handled?",
      answer: "Our data layer pulls from TikTok, IG & YouTube APIs + machine‑learning bot‑detection. Offending creators are auto‑flagged."
    },
    {
      question: "What about legal & tax?",
      answer: "Jungl issues a consolidated VAT‑compliant invoice; creators receive localised tax docs."
    }
  ];

  return (
    <section className="py-16 sm:py-20 lg:py-24 px-4 sm:px-6 lg:px-8 bg-zinc-50">
      <div className="max-w-4xl mx-auto">
        <H2 className="text-black text-center mb-12">
          Frequently Asked Questions
        </H2>
        
        <Accordion type="single" collapsible className="w-full">
          {faqs.map((faq, index) => (
            <AccordionItem key={index} value={`faq-${index}`} className="border-zinc-200">
              <AccordionTrigger className="text-left text-black hover:text-black">
                <H3 className="text-black">{faq.question}</H3>
              </AccordionTrigger>
              <AccordionContent className="pt-2">
                <Body className="text-zinc-700">{faq.answer}</Body>
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
};

export default BrandsFAQ;