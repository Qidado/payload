import { H2, H3, Body } from "@/components/Typography";
import { Check } from "lucide-react";
const BenefitsGrid = () => {
  const benefits = [{
    headline: "No subscription fees",
    proof: "Pay only when you run campaigns."
  }, {
    headline: "EU payouts in days",
    proof: "Creators get paid fast, content delivered on time."
  }, {
    headline: "Built-in recruitment",
    proof: "We find and match the best creators for you."
  }, {
    headline: "Clear brief templates",
    proof: "Reduce revisions and get better content faster."
  }, {
    headline: "Sales tracking (beta)",
    proof: "Pay creators based on actual revenue generated."
  }, {
    headline: "No setup complexity",
    proof: "Start your first campaign in under 10 minutes."
  }];
  return (
    <div className="py-24 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <H2 className="mb-4">Why brands choose Jungl</H2>
          <Body className="text-muted-foreground max-w-2xl mx-auto">
            Everything you need to run successful creator campaigns, without the headaches.
          </Body>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {benefits.map((benefit, index) => (
            <div key={index} className="text-center">
              <div className="flex items-center justify-center w-12 h-12 bg-primary/10 rounded-full mb-4 mx-auto">
                <Check className="w-6 h-6 text-primary" />
              </div>
              <H3 className="mb-2">{benefit.headline}</H3>
              <Body className="text-muted-foreground">{benefit.proof}</Body>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
export default BenefitsGrid;