import { H2, H3, Body } from "@/components/Typography";
import { Button } from "@/components/ui/button";
import { Check, X } from "lucide-react";
const PricingSection = () => {
  const othersFeatures = ["Monthly Subscription Fees → Pay every month, no matter what.", "Locked Into Contracts → Can't leave when campaigns slow down.", "Pay Even When You Don't Run Campaigns → Money wasted during off-months.", "Manual Payout Hassle → You're stuck chasing invoices & compliance."];
  const junglFeatures = ["No Subscription, No Contracts → Use it only when you need it.", "Pay Only for Active Campaigns → Zero wasted spend.", "Automated Creator Payouts & Compliance → Hands off, stress free.", "5% Beta Fee (10–15% later) → Still cheaper than subscriptions."];
  const featureColumns = [
    {
      title: "Campaign Management",
      features: [
        {
          title: "Creator Recruitment Included",
          description: "Verified creators apply directly to your briefs."
        },
        {
          title: "Smart Brief Builder",
          description: "Deliverables, hashtags & deadlines set in minutes."
        },
        {
          title: "Collaboration Hub",
          description: "Chat, approve, and manage campaigns in one place."
        },
        {
          title: "Content Library",
          description: "All campaign content automatically saved and organized."
        }
      ]
    },
    {
      title: "Payments & Compliance",
      features: [
        {
          title: "Automated Creator Payouts",
          description: "Funds released instantly once work is approved."
        },
        {
          title: "Instant Payouts (Optional)",
          description: "Same-day Stripe payouts (1% fee)."
        },
        {
          title: "Tax & Legal Compliance Built-in",
          description: "Invoices, reporting & contracts handled automatically."
        },
        {
          title: "DAC7 Compliance",
          description: "Fully compliant with EU reporting requirements."
        }
      ]
    },
    {
      title: "Performance & Tracking",
      features: [
        {
          title: "Affiliate & Sales Tracking (Coming Soon)",
          description: "Only pay creators on revenue they generate."
        },
        {
          title: "Real-Time Dashboard",
          description: "Track clicks, reach, conversions & ROI in one place."
        },
        {
          title: "Audience Insights You Can Trust",
          description: "Real demographics — no inflated screenshots."
        },
        {
          title: "Data Export & Downloads",
          description: "Export campaign results & reports on demand."
        }
      ]
    }
  ];
  return <section id="pricing" className="py-16 sm:py-20 lg:py-24 px-4 sm:px-6 lg:px-8 bg-zinc-50">
      <div className="max-w-6xl mx-auto">
        {/* Big headline */}
        <H2 className="text-black text-center mb-8 px-4">
          Stop Paying for Empty Subscriptions. Only Pay When You Run.
        </H2>
        
        {/* 2-column comparison */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-12 mb-12">
          {/* Others Column */}
          <div className="bg-white rounded-2xl p-6 lg:p-8 border border-zinc-200 shadow-sm">
            <H3 className="text-black mb-4 text-center">Others</H3>
            <div className="text-center mb-6">
              <div className="text-2xl lg:text-3xl font-bold text-red-600">400€ - 1000€</div>
              <div className="text-sm text-zinc-600">Monthly subscription</div>
            </div>
            
            <div className="space-y-4">
              {othersFeatures.map((feature, index) => {
                const [title, subtitle] = feature.split(' → ');
                return (
                  <div key={index} className="flex items-start gap-3">
                    <X className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" strokeWidth={2} />
                    <div>
                      <Body className="text-zinc-900 font-semibold">{title}</Body>
                      <Body className="text-zinc-600 text-sm">{subtitle}</Body>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Jungl Column */}
          <div className="bg-white rounded-2xl p-6 lg:p-8 border-2 border-black shadow-lg">
            <H3 className="text-black mb-4 text-center">Jungl</H3>
            <div className="text-center mb-6">
              <div className="text-2xl lg:text-3xl font-bold text-green-600">0€</div>
              <div className="text-sm text-zinc-600">Monthly subscription</div>
            </div>
            
            <div className="space-y-4">
              {junglFeatures.map((feature, index) => {
                const [title, subtitle] = feature.split(' → ');
                return (
                  <div key={index} className="flex items-start gap-3">
                    <Check className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" strokeWidth={2} />
                    <div>
                      <Body className="text-zinc-900 font-semibold">{title}</Body>
                      <Body className="text-zinc-600 text-sm">{subtitle}</Body>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* CTA Button */}
        

        {/* What's Included */}
        <div className="bg-white rounded-2xl p-6 lg:p-8 border border-zinc-200">
          <H3 className="text-black mb-6 text-center text-lg">What's Included</H3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {featureColumns.map((column, columnIndex) => (
              <div key={columnIndex} className="space-y-4">
                <Body className="text-black text-center mb-4 font-bold text-sm">{column.title}</Body>
                {column.features.map((feature, featureIndex) => (
                  <div key={featureIndex} className="flex items-start gap-3">
                    <Check className="w-5 h-5 text-black flex-shrink-0 mt-0.5" strokeWidth={2} />
                    <div>
                      <Body className="font-medium text-black mb-1">{feature.title}</Body>
                      <Body className="text-zinc-600 text-sm">{feature.description}</Body>
                    </div>
                  </div>
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>;
};
export default PricingSection;