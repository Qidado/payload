import { H2, BodyLarge } from "@/components/Typography";
const RebellionSection = () => {
  return null;
};
export default RebellionSection;