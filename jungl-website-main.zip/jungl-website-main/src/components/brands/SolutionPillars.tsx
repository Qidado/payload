import { H2, H3, BodyLarge } from "@/components/Typography";
import { Brain, CreditCard, BarChart3, Shield } from "lucide-react";

const SolutionPillars = () => {
  const pillars = [
    {
      icon: Brain,
      title: "Creator Marketplace",
      description: "Creators apply to your campaigns—no more cold outreach or hunting for the right talent."
    },
    {
      icon: CreditCard,
      title: "Automated Payment Distribution",
      description: "Save 20+ hours/week with automated creator payments and streamlined contract management."
    },
    {
      icon: BarChart3,
      title: "Live Performance Dashboard",
      description: "Track clicks, sales and CPA in real time. No more screenshots."
    },
    {
      icon: Shield,
      title: "Brand‑Safety Firewall",
      description: "Automatic profanity, politics & ESG scans keep your reputation intact."
    }
  ];

  return (
    <section id="solution" className="py-16 sm:py-20 lg:py-24 px-4 sm:px-6 lg:px-8 bg-white">
      <div className="max-w-6xl mx-auto">
        <H2 className="text-black text-center mb-12 sm:mb-16">
          The Jungl Advantage
        </H2>
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          {pillars.map((pillar, index) => (
            <div key={index} className="scroll-fade text-center">
              <div className="bg-black/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-6">
                <pillar.icon className="w-8 h-8 text-black" />
              </div>
              <H3 className="text-black mb-4">{pillar.title}</H3>
              <BodyLarge className="text-zinc-700">
                {pillar.description}
              </BodyLarge>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SolutionPillars;