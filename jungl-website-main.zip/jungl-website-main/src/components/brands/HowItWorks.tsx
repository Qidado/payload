import { H2, H3, BodyLarge, HeroDisplay } from "@/components/Typography";
import { FileText, Users, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
const HowItWorks = () => {
  const steps = [{
    number: "1",
    title: "Post Your Brief",
    description: "Set deliverables, deadlines & links in minutes.",
    icon: FileText
  }, {
    number: "2",
    title: "Creators Apply",
    description: "Verified creators apply directly — no chasing DMs.",
    icon: Users
  }, {
    number: "3",
    title: "Approve & Pay",
    description: "Approve work, track ROI live, and payouts happen automatically.",
    icon: TrendingUp
  }];
  return <section id="how-it-works" className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8 bg-white lg:py-24">
      <div className="max-w-6xl mx-auto">
        <HeroDisplay className="text-black text-center mb-12 sm:mb-16 text-2xl sm:text-3xl lg:text-4xl">
          How It Works
        </HeroDisplay>
        
        {/* 3-column grid for desktop, stacked for mobile */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8 mb-12 relative">
          {steps.map((step, index) => <div key={index} className="bg-white rounded-2xl p-6 lg:p-8 shadow-lg border border-zinc-100 hover:shadow-xl transition-shadow duration-300 animate-fade-in relative">
              {/* Icon with minimal illustration style */}
              <div className="bg-zinc-50 rounded-2xl w-12 h-12 lg:w-16 lg:h-16 flex items-center justify-center mb-4 lg:mb-6">
                <step.icon className="w-6 h-6 lg:w-8 lg:h-8 text-zinc-700" strokeWidth={1.5} />
              </div>
              
              {/* Step Number - subtle */}
              <div className="text-xs font-medium text-zinc-400 mb-2 uppercase tracking-wider">
                Step {step.number}
              </div>
              
              {/* Title */}
              <H3 className="text-black mb-3 text-lg lg:text-xl">{step.title}</H3>
              
              {/* One-line description */}
              <BodyLarge className="text-zinc-600 leading-relaxed text-sm lg:text-base">
                {step.description}
              </BodyLarge>
              
              {/* Flow arrow - only show between cards on desktop */}
              {index < steps.length - 1 && <div className="hidden lg:block absolute top-1/2 -right-4 transform -translate-y-1/2 z-10">
                  <div className="w-8 h-0.5 bg-zinc-300"></div>
                  <div className="absolute -right-1 -top-1 w-2 h-2 bg-zinc-300 rotate-45"></div>
                </div>}
            </div>)}
        </div>

        {/* CTA */}
        <div className="text-center">
          <Button size="lg" className="bg-black text-white hover:bg-zinc-800 hover:shadow-lg hover:scale-[1.02] focus:ring-2 focus:ring-black focus:ring-offset-2 focus:ring-offset-white px-8 py-4 text-lg font-khteka font-medium transition-all duration-200" asChild>
            <a href="https://getjungl.link/D3lpkHD" target="_blank" rel="noopener noreferrer">
              Create Your First Campaign
            </a>
          </Button>
        </div>
      </div>
    </section>;
};
export default HowItWorks;