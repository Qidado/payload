import { H2, BodyLarge, StatDisplay, BodySmall, Caption } from "@/components/Typography";
import { X } from "lucide-react";

const PainBlock = () => {
  return (
    <section id="pain" className="py-16 sm:py-20 lg:py-24 px-4 sm:px-6 lg:px-8 bg-zinc-50">
      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Image Column */}
          <div className="scroll-fade order-2 lg:order-1">
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1581090464777-f3220bbe1b8b?auto=format&fit=crop&w=800&q=80"
                alt="Chaotic influencer marketing workspace"
                className="w-full h-[500px] object-cover rounded-2xl"
                onError={(e) => {
                  e.currentTarget.style.display = 'none';
                  e.currentTarget.nextElementSibling?.classList.remove('hidden');
                }}
              />
              <div className="hidden w-full h-[500px] bg-zinc-800 rounded-2xl flex items-center justify-center">
                <span className="text-zinc-400">Chaotic workspace image</span>
              </div>
              {/* Overlay with stat */}
              <div className="absolute top-6 right-6 bg-white/90 backdrop-blur-sm rounded-lg p-4 border border-zinc-200">
                <StatDisplay className="mb-1">Wild</StatDisplay>
                <BodySmall className="text-zinc-600">West</BodySmall>
                <Caption className="text-zinc-500">chaos</Caption>
              </div>
            </div>
          </div>

          {/* Content Column */}
          <div className="scroll-fade order-1 lg:order-2 space-y-8">
            <div>
              <H2 className="text-black mb-6">
                Influencer Marketing Still Feels Like the Wild West.
              </H2>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-start">
                <X className="h-5 w-5 text-red-500 mr-4 flex-shrink-0 mt-1" />
                <div>
                  <BodyLarge className="text-black font-medium mb-1">Endless DM chasing & spreadsheets</BodyLarge>
                </div>
              </div>
              <div className="flex items-start">
                <X className="h-5 w-5 text-red-500 mr-4 flex-shrink-0 mt-1" />
                <div>
                  <BodyLarge className="text-black font-medium mb-1">Fake followers & brand‑safety risks</BodyLarge>
                </div>
              </div>
              <div className="flex items-start">
                <X className="h-5 w-5 text-red-500 mr-4 flex-shrink-0 mt-1" />
                <div>
                  <BodyLarge className="text-black font-medium mb-1">30‑day payment terms creators hate</BodyLarge>
                </div>
              </div>
              <div className="flex items-start">
                <X className="h-5 w-5 text-red-500 mr-4 flex-shrink-0 mt-1" />
                <div>
                  <BodyLarge className="text-black font-medium mb-1">Zero clarity on true ROAS</BodyLarge>
                </div>
              </div>
            </div>
            
            <BodyLarge className="text-black font-medium text-lg">
              Jungl cuts the chaos so your team ships campaigns—not admin.
            </BodyLarge>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PainBlock;