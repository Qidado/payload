
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowRight, Users } from "lucide-react";
import { Body, BodySmall } from "./Typography";
import { trackFormInteraction, trackFormSubmission, trackUserIdentification, trackCTAClick } from "@/lib/posthog";

const EarlyAccessForm = () => {
  const [formData, setFormData] = useState({
    email: '',
    name: '',
    creatorType: '',
    followerCount: '',
    category: ''
  });
  const [hasStartedForm, setHasStartedForm] = useState(false);

  useEffect(() => {
    if ((formData.email || formData.name) && !hasStartedForm) {
      trackFormInteraction('early_access', 'started');
      setHasStartedForm(true);
    }
  }, [formData.email, formData.name, hasStartedForm]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Track user identification with detailed creator info
    if (formData.email) {
      trackUserIdentification(formData.email, {
        name: formData.name,
        creator_type: formData.creatorType,
        follower_count: formData.followerCount,
        content_category: formData.category,
        source: 'early_access_form',
        signup_type: 'detailed_form'
      });
    }
    
    // Track form submission
    trackFormSubmission('early_access', true, {
      creator_type: formData.creatorType,
      follower_count: formData.followerCount,
      content_category: formData.category,
      email_domain: formData.email ? formData.email.split('@')[1] : undefined
    });
    
    // Track CTA click
    trackCTAClick('app_store_redirect', 'early_access_form', 'https://apps.apple.com/dk/app/jungl-creator-business-hub/id6741893457');
    
    // Redirect to App Store
    window.open("https://apps.apple.com/dk/app/jungl-creator-business-hub/id6741893457", "_blank");
  };

  return (
    <Card className="w-full max-w-md mx-auto bg-zinc-900 border-zinc-800">
      <CardHeader className="text-center">
        <div className="flex items-center justify-center gap-2 mb-2">
          <Users className="h-5 w-5 text-white" />
          <CardTitle className="text-white text-xl">Join Early Access</CardTitle>
        </div>
        <CardDescription className="text-zinc-300">
          Be among the first 1000 creators to transform your business
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email" className="text-white">Email Address</Label>
            <Input
              id="email"
              type="email"
              placeholder="your@email.com"
              value={formData.email}
              onChange={(e) => setFormData({...formData, email: e.target.value})}
              onFocus={() => trackFormInteraction('early_access', 'field_focused', 'email')}
              className="bg-zinc-800 border-zinc-700 text-white placeholder:text-zinc-400"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="name" className="text-white">Creator Name</Label>
            <Input
              id="name"
              type="text"
              placeholder="Your name or handle"
              value={formData.name}
              onChange={(e) => setFormData({...formData, name: e.target.value})}
              onFocus={() => trackFormInteraction('early_access', 'field_focused', 'name')}
              className="bg-zinc-800 border-zinc-700 text-white placeholder:text-zinc-400"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="creatorType" className="text-white">Creator Type</Label>
            <Select onValueChange={(value) => setFormData({...formData, creatorType: value})}>
              <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white">
                <SelectValue placeholder="Select your type" />
              </SelectTrigger>
              <SelectContent className="bg-zinc-800 border-zinc-700">
                <SelectItem value="influencer">Influencer</SelectItem>
                <SelectItem value="content-creator">Content Creator</SelectItem>
                <SelectItem value="blogger">Blogger</SelectItem>
                <SelectItem value="podcaster">Podcaster</SelectItem>
                <SelectItem value="photographer">Photographer</SelectItem>
                <SelectItem value="videographer">Videographer</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="followerCount" className="text-white">Follower Count</Label>
            <Select onValueChange={(value) => setFormData({...formData, followerCount: value})}>
              <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white">
                <SelectValue placeholder="Select range" />
              </SelectTrigger>
              <SelectContent className="bg-zinc-800 border-zinc-700">
                <SelectItem value="1k-10k">1K - 10K</SelectItem>
                <SelectItem value="10k-50k">10K - 50K</SelectItem>
                <SelectItem value="50k-100k">50K - 100K</SelectItem>
                <SelectItem value="100k-500k">100K - 500K</SelectItem>
                <SelectItem value="500k+">500K+</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="category" className="text-white">Content Category</Label>
            <Select onValueChange={(value) => setFormData({...formData, category: value})}>
              <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white">
                <SelectValue placeholder="Select category" />
              </SelectTrigger>
              <SelectContent className="bg-zinc-800 border-zinc-700">
                <SelectItem value="lifestyle">Lifestyle</SelectItem>
                <SelectItem value="fashion">Fashion</SelectItem>
                <SelectItem value="fitness">Fitness</SelectItem>
                <SelectItem value="food">Food</SelectItem>
                <SelectItem value="travel">Travel</SelectItem>
                <SelectItem value="tech">Tech</SelectItem>
                <SelectItem value="business">Business</SelectItem>
                <SelectItem value="entertainment">Entertainment</SelectItem>
                <SelectItem value="education">Education</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button 
            type="submit" 
            className="w-full bg-white text-black hover:opacity-90 hover:scale-105 transition-all duration-300"
            size="lg"
          >
            Join Early Access
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>

          <BodySmall className="text-zinc-400 text-center">
            Limited spots available • No spam, ever
          </BodySmall>
        </form>
      </CardContent>
    </Card>
  );
};

export default EarlyAccessForm;
