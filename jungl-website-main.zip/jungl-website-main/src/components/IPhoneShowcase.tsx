import { Button } from "@/components/ui/button";
import { ArrowRight, Download, Save, Share, DollarSign } from "lucide-react";
import { H2, BodyLarge } from "./Typography";
const IPhoneShowcase = () => {
  const handleAppStoreClick = (e: React.MouseEvent) => {
    console.log('App Store button clicked from iPhone showcase!');
    console.log('Event details:', e);
  };
  const handleGooglePlayClick = (e: React.MouseEvent) => {
    console.log('Google Play button clicked from iPhone showcase!');
    console.log('Event details:', e);
  };
  const handleRequestInvite = (e: React.MouseEvent) => {
    console.log('Request Invite button clicked!');
    console.log('Event details:', e);
  };
  return <section className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8 bg-black lg:py-[130px] my-0">
      <div className="max-w-container mx-auto">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center max-w-6xl mx-auto">
          {/* Left side - Content - Centered */}
          <div className="scroll-fade flex flex-col justify-center order-2 lg:order-1">
            <H2 className="text-white mb-4 sm:mb-6 text-center lg:text-left" id="showcase-heading">
              Less Hustle. More Growth.
            </H2>
            <BodyLarge className="text-zinc-300 mb-6 sm:mb-8 max-w-lg mx-auto lg:mx-0 text-center lg:text-left">
              Simplify your creator business, amplify your impact.<br />
              Invoice instantly, land better brand collabs, get paid on autopilot.<br /><br />
              Join thousands of creators already growing faster with Jungl.
            </BodyLarge>
            

            {/* App Store / Google Play buttons - Mobile centered */}
            <div className="flex flex-row gap-3 justify-center lg:justify-start">
              <a href="https://apps.apple.com/dk/app/jungl-creator-business-hub/id6741893457" className="block transition-opacity hover:opacity-80 cursor-pointer" aria-label="Download Jungl on the App Store" target="_blank" rel="noopener noreferrer" onClick={handleAppStoreClick}>
                <img 
                  src="https://ehfsfqmzmrwzlgnbpyzz.supabase.co/storage/v1/object/public/assets//2.svg" 
                  alt="Download Jungl on the App Store" 
                  className="h-12 sm:h-14 w-auto pointer-events-none"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.style.display = 'none';
                    const parent = target.parentElement;
                    if (parent && !parent.querySelector('.fallback-appstore')) {
                      const fallbackDiv = document.createElement('div');
                      fallbackDiv.className = 'fallback-appstore h-12 sm:h-14 px-4 bg-white text-black rounded-lg flex items-center text-sm font-medium';
                      fallbackDiv.textContent = '📱 Download on App Store';
                      parent.appendChild(fallbackDiv);
                    }
                  }}
                />
              </a>
              
              <div className="relative">
                <a href="#" className="block transition-opacity hover:opacity-80 cursor-pointer" aria-label="Download Jungl on Google Play" target="_blank" rel="noopener noreferrer" onClick={handleGooglePlayClick}>
                  <img 
                    src="https://ehfsfqmzmrwzlgnbpyzz.supabase.co/storage/v1/object/public/assets//1.svg" 
                    alt="Get Jungl on Google Play" 
                    className="h-12 sm:h-14 w-auto pointer-events-none"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.style.display = 'none';
                      const parent = target.parentElement;
                      if (parent && !parent.querySelector('.fallback-googleplay')) {
                        const fallbackDiv = document.createElement('div');
                        fallbackDiv.className = 'fallback-googleplay h-12 sm:h-14 px-4 bg-zinc-800 text-white rounded-lg flex items-center text-sm font-medium border border-zinc-600';
                        fallbackDiv.textContent = '📱 Get on Google Play';
                        parent.appendChild(fallbackDiv);
                      }
                    }}
                  />
                </a>
              </div>
            </div>
          </div>

          {/* Right side - App image - Centered */}
          <div className="scroll-fade flex justify-center items-center order-1 lg:order-2">
            <img 
              src="/lovable-uploads/56495540-5978-42a9-b48e-d0df60b46803.png" 
              alt="Jungl mobile app interface showing creator business dashboard with revenue tracking, brand partnerships, and content management tools" 
              width="320"
              height="640"
              loading="lazy"
              decoding="async"
              className="w-64 sm:w-72 lg:w-80 h-auto rounded-2xl shadow-2xl aspect-[1/2]"
              onError={(e) => {
                const target = e.target as HTMLImageElement;
                target.style.display = 'none';
                const parent = target.parentElement;
                if (parent && !parent.querySelector('.fallback-phone')) {
                  const fallbackDiv = document.createElement('div');
                  fallbackDiv.className = 'fallback-phone w-64 sm:w-72 lg:w-80 h-[500px] rounded-2xl bg-zinc-900 border border-zinc-700 flex flex-col items-center justify-center p-8 shadow-2xl';
                  const svgElement = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
                  svgElement.setAttribute('class', 'w-16 h-16 text-zinc-600 mb-4');
                  svgElement.setAttribute('fill', 'currentColor');
                  svgElement.setAttribute('viewBox', '0 0 20 20');
                  svgElement.innerHTML = '<path d="M3 4a1 1 0 011-1h12a1 1 0 011 1v12a1 1 0 01-1 1H4a1 1 0 01-1-1V4z"/><path d="M6 6h8v6H6V6z"/>';
                  const textElement = document.createElement('p');
                  textElement.className = 'text-zinc-400 text-center text-sm';
                  textElement.textContent = 'Jungl App - Your Creator Business Hub';
                  fallbackDiv.appendChild(svgElement);
                  fallbackDiv.appendChild(textElement);
                  parent.appendChild(fallbackDiv);
                }
              }}
            />
            
            {/* No-JavaScript fallback */}
            <noscript>
              <div className="w-64 sm:w-72 lg:w-80 h-[500px] rounded-2xl bg-zinc-900 border border-zinc-700 flex flex-col items-center justify-center p-8 shadow-2xl">
                <svg className="w-16 h-16 text-zinc-600 mb-4" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M3 4a1 1 0 011-1h12a1 1 0 011 1v12a1 1 0 01-1 1H4a1 1 0 01-1-1V4z"/>
                  <path d="M6 6h8v6H6V6z"/>
                </svg>
                <p className="text-zinc-400 text-center text-sm">Jungl mobile app - The creator business platform that simplifies your workflow</p>
              </div>
            </noscript>
          </div>
        </div>
      </div>
    </section>;
};
export default IPhoneShowcase;