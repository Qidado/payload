import { HeroDisplay, H3, Body, BodySmall, Caption } from "./Typography";
const TruthBlock = () => {
  return <div style={{
    backgroundColor: '#0a0a0a'
  }} className="pt-24 pb-24 sm:pt-32 sm:pb-32 lg:pt-40 lg:pb-40 my-[250px]">
      <div className="max-w-container mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Two-Column Layout - Mobile stacked, desktop 50/50 split */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 sm:gap-12 lg:gap-16 xl:gap-32 items-center">
          
          {/* Left Column - Image (50%) */}
          <div className="scroll-fade relative overflow-hidden h-48 sm:h-64 lg:h-[480px] xl:h-[640px] bg-zinc-900 mx-auto lg:mx-0 max-w-md lg:max-w-none">
            <img src="/lovable-uploads/27eaf013-07b3-4a12-984c-0e94a986f122.png" alt="Creator overwhelmed by business administration tasks and paperwork while trying to focus on content creation" width="600" height="480" loading="lazy" decoding="async" className="w-full h-full object-cover aspect-[5/4]" onError={e => {
            const target = e.target as HTMLImageElement;
            target.style.display = 'none';
            const parent = target.parentElement;
            if (parent && !parent.querySelector('.fallback-content')) {
              const fallbackDiv = document.createElement('div');
              fallbackDiv.className = 'fallback-content w-full h-full flex flex-col items-center justify-center bg-zinc-900 text-zinc-400 p-8';
              const svgElement = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
              svgElement.setAttribute('class', 'w-16 h-16 mb-4');
              svgElement.setAttribute('fill', 'currentColor');
              svgElement.setAttribute('viewBox', '0 0 20 20');
              svgElement.innerHTML = '<path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>';
              const textElement = document.createElement('p');
              textElement.className = 'text-center text-sm';
              textElement.textContent = 'The struggle is real: drowning in admin while trying to create';
              fallbackDiv.appendChild(svgElement);
              fallbackDiv.appendChild(textElement);
              parent.appendChild(fallbackDiv);
            }
          }} />
            
            {/* No-JavaScript fallback */}
            <noscript>
              <div className="w-full h-full flex flex-col items-center justify-center bg-zinc-900 text-zinc-400 p-8">
                <svg className="w-16 h-16 mb-4" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <p className="text-center text-sm">Creator overwhelmed by business tasks while trying to focus on content creation</p>
              </div>
            </noscript>
          </div>

          {/* Right Column - Copy (50%) */}
          <div className="scroll-fade space-y-4 sm:space-y-6 lg:space-y-8 text-center lg:text-left" style={{
          animationDelay: '200ms'
        }}>
            
            {/* Section Label */}
            <div className="flex flex-col items-center lg:items-start">
              <Caption className="text-white uppercase tracking-[0.2em] text-sm sm:text-base mb-3 font-khteka font-medium">
                THE TRUTH
              </Caption>
              <div className="w-16 h-0.5 bg-white"></div>
            </div>

            {/* Main Heading + Content - Mobile optimized */}
            <div className="space-y-3 sm:space-y-4">
              <H3 className="text-white text-xl sm:text-2xl lg:text-3xl xl:text-4xl leading-tight" id="truth-heading">
                Building an audience was the easy part.
              </H3>
              
              <Body className="text-zinc-300 leading-relaxed text-lg sm:text-xl lg:text-2xl font-khinterference font-medium">
                Keeping it alive is the grind.
              </Body>
              
              <div className="space-y-2 pt-2">
                <Body className="text-zinc-400 leading-relaxed text-base sm:text-lg font-khteka">
                  You crush the post, the pitch, the viral spark—then drown in briefs, invoices, and DMs.
                </Body>
                
                <Body className="text-white leading-relaxed text-base sm:text-lg font-khteka font-medium pt-2">
                  Jungl cuts the admin noise, so the next win is yours alone.
                </Body>
              </div>
            </div>

          </div>

        </div>
      </div>
    </div>;
};
export default TruthBlock;