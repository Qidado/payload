import { H2 } from "@/components/Typography";
import { useScreenSize } from "@/hooks/use-mobile";

const FacesOfJungl = () => {
  const screenSize = useScreenSize();
  
  const creators = [
    // Professional headshots and portraits (9)
    "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=300&h=300&fit=crop&fm=webp&q=75",
    "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&h=300&fit=crop&fm=webp&q=75",
    "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&h=300&fit=crop&fm=webp&q=75",
    "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=300&h=300&fit=crop&fm=webp&q=75",
    "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=300&h=300&fit=crop&fm=webp&q=75",
    "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=300&h=300&fit=crop&fm=webp&q=75",
    "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=300&h=300&fit=crop&fm=webp&q=75",
    "https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=300&h=300&fit=crop&fm=webp&q=75",
    "https://images.unsplash.com/photo-1488426862026-3ee34a7d66df?w=300&h=300&fit=crop&fm=webp&q=75",
    // Lifestyle creators (9)
    "https://images.unsplash.com/photo-1499952127939-9bbf5af6c51c?w=300&h=300&fit=crop&fm=webp&q=75",
    "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=300&h=300&fit=crop&fm=webp&q=75",
    "https://images.unsplash.com/photo-1496345875659-11f7dd282d1d?w=300&h=300&fit=crop&fm=webp&q=75",
    "https://images.unsplash.com/photo-1492633423870-43d1cd2775eb?w=300&h=300&fit=crop&fm=webp&q=75",
    "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&h=300&fit=crop&fm=webp&q=75",
    "https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=300&h=300&fit=crop&fm=webp&q=75",
    "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=300&h=300&fit=crop&fm=webp&q=75",
    "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=300&h=300&fit=crop&fm=webp&q=75",
    "https://images.unsplash.com/photo-1567532939604-b6b5b0db2604?w=300&h=300&fit=crop&fm=webp&q=75",
    // Content creators and professionals (9)
    "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=300&h=300&fit=crop&fm=webp&q=75",
    "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=300&h=300&fit=crop&fm=webp&q=75",
    "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=300&h=300&fit=crop&fm=webp&q=75",
    "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=300&h=300&fit=crop&fm=webp&q=75",
    "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&h=300&fit=crop&fm=webp&q=75",
    "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&h=300&fit=crop&fm=webp&q=75",
    "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=300&h=300&fit=crop&fm=webp&q=75",
    "https://images.unsplash.com/photo-1517365830460-955ce3ccd263?w=300&h=300&fit=crop&fm=webp&q=75",
    "https://images.unsplash.com/photo-1519345182560-3f2917c472ef?w=300&h=300&fit=crop&fm=webp&q=75"
  ];

  const creatorDescriptions = [
    "Professional headshot of female content creator",
    "Portrait of male business creator",
    "Headshot of diverse lifestyle influencer", 
    "Professional photo of male tech creator",
    "Portrait of female lifestyle blogger",
    "Headshot of young male entrepreneur",
    "Professional photo of female business owner",
    "Portrait of male content strategist",
    "Headshot of female digital creator",
    "Photo of lifestyle content creator",
    "Portrait of fashion influencer",
    "Headshot of travel content creator",
    "Photo of wellness lifestyle blogger",
    "Portrait of beauty content creator",
    "Headshot of fitness influencer",
    "Photo of food content creator",
    "Portrait of home lifestyle blogger",
    "Headshot of parenting content creator",
    "Photo of professional business creator",
    "Portrait of female entrepreneur",
    "Headshot of diverse content strategist",
    "Photo of male business influencer",
    "Portrait of female digital marketer",
    "Headshot of tech content creator",
    "Photo of creative entrepreneur",
    "Portrait of brand strategist",
    "Headshot of marketing professional"
  ];

  // Responsive face count: mobile (12), tablet (20), desktop (27)
  const faceCount = screenSize === 'mobile' ? 12 : screenSize === 'tablet' ? 20 : 27;
  
  const shuffledCreators = [...creators]
    .sort(() => Math.random() - 0.5)
    .slice(0, faceCount);

  const shuffledDescriptions = [...creatorDescriptions]
    .sort(() => Math.random() - 0.5)
    .slice(0, faceCount);

  return (
    <div className="py-20 px-4 bg-black relative">
      <div className="w-full">
        {/* App Download Section */}
        <div className="text-center mb-12 sm:mb-16 scroll-fade">
          <H2 className="text-3xl md:text-4xl font-bold text-white mb-4" id="testimonials-heading">
            Ready to grow your creator business?
          </H2>
          <p className="text-lg text-zinc-300 mb-8 max-w-2xl mx-auto">
            Download Jungl and join thousands of creators who are building sustainable businesses without the burnout.
          </p>
          <div className="flex flex-row gap-3 justify-center">
            <a href="https://apps.apple.com/dk/app/jungl-creator-business-hub/id6741893457" className="block transition-opacity hover:opacity-80 cursor-pointer" aria-label="Download on the App Store" target="_blank" rel="noopener noreferrer">
              <img src="https://ehfsfqmzmrwzlgnbpyzz.supabase.co/storage/v1/object/public/assets//2.svg" alt="Download on the App Store" className="h-12 sm:h-14 w-auto pointer-events-none" />
            </a>
            
            <div className="relative">
              <a href="#" className="block transition-opacity hover:opacity-80 cursor-pointer" aria-label="Download on Google Play" target="_blank" rel="noopener noreferrer">
                <img src="https://ehfsfqmzmrwzlgnbpyzz.supabase.co/storage/v1/object/public/assets//1.svg" alt="Get it on Google Play" className="h-12 sm:h-14 w-auto pointer-events-none" />
              </a>
            </div>
          </div>
        </div>
        
        <div className="relative container mx-auto px-4 overflow-hidden scroll-fade">
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-9 gap-1 sm:gap-2 md:gap-4">
            {shuffledCreators.map((url, index) => (
              <div 
                key={index} 
                className="aspect-square overflow-hidden rounded-lg bg-zinc-800"
                style={{
                  opacity: `${1 - (Math.floor(index / 9) * 0.2)}`,
                  transform: `scale(${1 - (Math.floor(index / 9) * 0.05)})`,
                  transition: 'opacity 0.3s ease-out, transform 0.3s ease-out'
                }}
              >
                <img
                  src={url}
                  alt={shuffledDescriptions[index] || `Professional creator headshot ${index + 1}`}
                  width="300"
                  height="300"
                  loading="lazy"
                  decoding="async"
                  className="w-full h-full object-cover transform transition-all duration-300 hover:scale-105 active:scale-105 md:hover:scale-110 aspect-square"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.style.display = 'none';
                    const parent = target.parentElement;
                    if (parent && !parent.querySelector('.fallback-icon')) {
                      const fallbackDiv = document.createElement('div');
                      fallbackDiv.className = 'fallback-icon w-full h-full flex items-center justify-center bg-zinc-800';
                      fallbackDiv.innerHTML = '<svg class="w-8 h-8 text-zinc-600" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clip-rule="evenodd" /></svg>';
                      parent.appendChild(fallbackDiv);
                    }
                  }}
                />
              </div>
            ))}
          </div>
          
          {/* No-JavaScript fallback */}
          <noscript>
            <div className="text-center py-12">
              <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-9 gap-2 md:gap-4 mb-8">
                {Array.from({ length: 12 }, (_, i) => (
                  <div key={i} className="aspect-square bg-zinc-800 rounded-lg flex items-center justify-center">
                    <svg className="w-8 h-8 text-zinc-600" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
                    </svg>
                  </div>
                ))}
              </div>
              <p className="text-zinc-300 text-lg">Join thousands of creators building sustainable businesses with Jungl</p>
            </div>
          </noscript>
          
          <div 
            className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-black to-transparent pointer-events-none"
            aria-hidden="true"
          />
        </div>
      </div>
    </div>
  );
};

export default FacesOfJungl;