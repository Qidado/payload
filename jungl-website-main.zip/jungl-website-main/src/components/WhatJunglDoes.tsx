
import { FileText, Handshake, BarChart3, Briefcase } from "lucide-react";
import { H2, BodyLarge, Body, H3 } from "./Typography";

const features = [
  {
    icon: FileText,
    title: "Invoices—instant & on brand",
    description: "Create, send and track invoices in seconds—no more chasing payments."
  },
  {
    icon: Handshake,
    title: "Collaborations—pitch to payout",
    description: "Find brand gigs, negotiate terms, sign & get paid—all in one place."
  },
  {
    icon: BarChart3,
    title: "Insights—real-time success metrics",
    description: "See what's working—engagement, earnings and growth—so you can double down."
  },
  {
    icon: Briefcase,
    title: "Portfolio—your work, spotlighted",
    description: "Showcase your best projects and testimonials with a single share link."
  }
];

const WhatJunglDoes = () => {
  return (
    <section className="py-16 sm:py-20 lg:py-24 px-4 sm:px-6 lg:px-8 bg-zinc-950">
      <div className="max-w-container mx-auto">
        <div className="text-center mb-12 sm:mb-16 scroll-fade">
          <H2 className="text-white mb-4 sm:mb-6">
            We help you run the business behind your content
          </H2>
          <BodyLarge className="text-zinc-300 max-w-3xl mx-auto">
            One platform to tame every business task.
          </BodyLarge>
        </div>

        <div className="grid gap-6 sm:gap-8 md:grid-cols-2">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="scroll-fade p-4 sm:p-6 bg-zinc-900 border border-zinc-800 hover:bg-zinc-800 transition-all duration-300 hover:transform hover:scale-105"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="flex items-start sm:items-center mb-4">
                <div className="p-2 sm:p-3 bg-white/10 mr-3 sm:mr-4 flex-shrink-0">
                  <feature.icon className="h-5 w-5 sm:h-6 sm:w-6 text-white" />
                </div>
                <H3 className="text-white text-lg sm:text-xl leading-tight">
                  {feature.title}
                </H3>
              </div>
              <Body className="text-zinc-300 text-sm sm:text-base">
                {feature.description}
              </Body>
            </div>
          ))}
        </div>

        <div className="text-center mt-12 sm:mt-16 scroll-fade">
          <H3 className="text-zinc-300 font-medium font-khinterference">
            Your vision, our backbone.
          </H3>
        </div>
      </div>
    </section>
  );
};

export default WhatJunglDoes;
