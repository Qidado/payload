import { H2, Body } from "./Typography";
import { Check, Shield } from "lucide-react";

const PricingPreview = () => {
  return (
    <div className="py-16 sm:py-20 lg:py-24 px-4 sm:px-6 lg:px-8 bg-black">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12 scroll-fade">
          <div className="inline-flex items-center gap-2 bg-white/10 border border-white/20 rounded-full px-4 py-2 mb-6 backdrop-blur-sm">
            <Shield className="w-4 h-4 text-white" />
            <span className="text-white text-sm font-medium">Transparent Pricing</span>
          </div>
          
          <H2 className="text-white mb-6">
            No Hidden Fees, No Surprises
          </H2>
          
          <Body className="text-zinc-300 mb-8 max-w-2xl mx-auto">
            Simple, transparent pricing with no transaction fees.
          </Body>
        </div>

        <div className="grid md:grid-cols-2 gap-8 scroll-fade">
          {/* Current: Free Beta */}
          <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-6">
            <div className="text-center">
              <h3 className="text-xl font-bold text-white mb-2">Beta (Current)</h3>
              <div className="text-3xl font-bold text-white mb-4">Free</div>
              <Body className="text-zinc-400 mb-6">
                Full access during beta period
              </Body>
              
              <div className="space-y-3 text-left">
                <div className="flex items-center gap-3">
                  <Check className="w-4 h-4 text-white" />
                  <span className="text-zinc-300 text-sm">Unlimited invoices</span>
                </div>
                <div className="flex items-center gap-3">
                  <Check className="w-4 h-4 text-white" />
                  <span className="text-zinc-300 text-sm">Real-time payments</span>
                </div>
                <div className="flex items-center gap-3">
                  <Check className="w-4 h-4 text-white" />
                  <span className="text-zinc-300 text-sm">Tax reporting</span>
                </div>
                <div className="flex items-center gap-3">
                  <Check className="w-4 h-4 text-white" />
                  <span className="text-zinc-300 text-sm">Brand discovery</span>
                </div>
              </div>
            </div>
          </div>

          {/* Future: Pro Plan */}
          <div className="bg-zinc-900 border border-zinc-700 rounded-lg p-6 relative">
            <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
              <span className="bg-white text-black px-3 py-1 rounded-full text-xs font-medium">
                After Launch
              </span>
            </div>
            
            <div className="text-center">
              <h3 className="text-xl font-bold text-white mb-2">Pro</h3>
              <div className="text-3xl font-bold text-white mb-4">€19<span className="text-lg text-zinc-400">/mo</span></div>
              <Body className="text-zinc-400 mb-6">
                Everything in beta + premium features
              </Body>
              
              <div className="space-y-3 text-left">
                <div className="flex items-center gap-3">
                  <Check className="w-4 h-4 text-white" />
                  <span className="text-zinc-300 text-sm">All beta features</span>
                </div>
                <div className="flex items-center gap-3">
                  <Check className="w-4 h-4 text-white" />
                  <span className="text-zinc-300 text-sm">Priority brand matching</span>
                </div>
                <div className="flex items-center gap-3">
                  <Check className="w-4 h-4 text-white" />
                  <span className="text-zinc-300 text-sm">Advanced analytics</span>
                </div>
                <div className="flex items-center gap-3">
                  <Check className="w-4 h-4 text-white" />
                  <span className="text-zinc-300 text-sm">Email & phone support</span>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};

export default PricingPreview;