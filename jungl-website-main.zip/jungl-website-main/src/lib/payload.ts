import { Resource, Post, Category } from '../payload/payload-types'

// Update this URL after deploying to Railway (e.g., 'https://your-app.railway.app/api')
const PAYLOAD_API_URL = import.meta.env.VITE_PAYLOAD_API_URL || 'http://localhost:3001/api'

// Generic fetch function for Payload API
async function payloadFetch<T>(endpoint: string): Promise<T> {
  const response = await fetch(`${PAYLOAD_API_URL}${endpoint}`)
  if (!response.ok) {
    throw new Error(`Failed to fetch ${endpoint}`)
  }
  return response.json()
}

// Resources API
export async function getResources(params?: {
  category?: string
  featured?: boolean
  limit?: number
  search?: string
}): Promise<{ docs: Resource[]; totalDocs: number }> {
  const searchParams = new URLSearchParams()
  
  if (params?.category) {
    searchParams.append('where[category][equals]', params.category)
  }
  if (params?.featured) {
    searchParams.append('where[featured][equals]', 'true')
  }
  if (params?.limit) {
    searchParams.append('limit', params.limit.toString())
  }
  if (params?.search) {
    searchParams.append('where[or][0][title][contains]', params.search)
    searchParams.append('where[or][1][description][contains]', params.search)
  }

  return payloadFetch(`/resources?${searchParams.toString()}`)
}

export async function getResourceBySlug(slug: string): Promise<Resource | null> {
  try {
    const result = await payloadFetch<{ docs: Resource[] }>(`/resources?where[slug][equals]=${slug}&limit=1`)
    return result.docs[0] || null
  } catch {
    return null
  }
}

// Posts API
export async function getPosts(params?: {
  category?: string
  limit?: number
  search?: string
  status?: string
}): Promise<{ docs: Post[]; totalDocs: number }> {
  const searchParams = new URLSearchParams()
  
  searchParams.append('where[status][equals]', params?.status || 'published')
  
  if (params?.category) {
    searchParams.append('where[category][equals]', params.category)
  }
  if (params?.limit) {
    searchParams.append('limit', params.limit.toString())
  }
  if (params?.search) {
    searchParams.append('where[or][0][title][contains]', params.search)
    searchParams.append('where[or][1][excerpt][contains]', params.search)
  }

  return payloadFetch(`/posts?${searchParams.toString()}`)
}

export async function getPostBySlug(slug: string): Promise<Post | null> {
  try {
    const result = await payloadFetch<{ docs: Post[] }>(`/posts?where[slug][equals]=${slug}&where[status][equals]=published&limit=1`)
    return result.docs[0] || null
  } catch {
    return null
  }
}

// Categories API
export async function getCategories(): Promise<{ docs: Category[]; totalDocs: number }> {
  return payloadFetch('/categories')
}

export async function getCategoryBySlug(slug: string): Promise<Category | null> {
  try {
    const result = await payloadFetch<{ docs: Category[] }>(`/categories?where[slug][equals]=${slug}&limit=1`)
    return result.docs[0] || null
  } catch {
    return null
  }
}