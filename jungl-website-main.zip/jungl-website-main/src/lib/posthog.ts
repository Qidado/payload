import posthog from 'posthog-js';
import { supabase } from '@/integrations/supabase/client';

let posthogInitialized = false;

export const initializePostHog = async () => {
  if (posthogInitialized) return;

  try {
    // Get PostHog API key from Supabase secrets
    const { data, error } = await supabase.functions.invoke('get-posthog-key');
    
    if (error || !data?.key) {
      console.warn('PostHog key not configured');
      return;
    }

    posthog.init(data.key, {
      api_host: 'https://eu.i.posthog.com',
      person_profiles: 'identified_only',
      capture_pageview: true, // Enable automatic web analytics
      capture_pageleave: true,
      loaded: (posthog) => {
        if (process.env.NODE_ENV === 'development') posthog.debug();
      }
    });

    posthogInitialized = true;
  } catch (error) {
    console.error('Failed to initialize PostHog:', error);
  }
};

export const trackPageView = (pathname: string) => {
  if (posthogInitialized) {
    posthog.capture('$pageview', {
      $current_url: window.location.href,
      path: pathname
    });
  }
};

export const trackEvent = (eventName: string, properties?: Record<string, any>) => {
  if (posthogInitialized) {
    posthog.capture(eventName, properties);
  }
};

export const trackCTAClick = (ctaType: string, location: string, targetUrl?: string) => {
  trackEvent('cta_clicked', {
    cta_type: ctaType,
    location: location,
    target_url: targetUrl
  });
};

export const trackFormSubmission = (formType: string, success: boolean, additionalData?: Record<string, any>) => {
  trackEvent('form_submitted', {
    form_type: formType,
    success: success,
    ...additionalData
  });
};

export const trackFormInteraction = (formType: string, action: string, field?: string) => {
  trackEvent('form_interaction', {
    form_type: formType,
    action: action, // 'started', 'field_focused', 'field_completed', 'abandoned'
    field: field
  });
};

export const trackUserIdentification = (email: string, properties: Record<string, any>) => {
  if (posthogInitialized) {
    posthog.identify(email, properties);
    trackEvent('user_identified', { email, ...properties });
  }
};

export const trackScrollDepth = (percentage: number, section?: string) => {
  trackEvent('scroll_depth', {
    percentage: percentage,
    section: section
  });
};

export const trackEngagement = (action: string, details?: Record<string, any>) => {
  trackEvent('engagement', {
    action: action,
    ...details
  });
};

export const trackNavigation = (from: string, to: string) => {
  trackEvent('navigation', {
    from_page: from,
    to_page: to
  });
};

export { posthog };