import { useEffect, useState } from "react";
import Cal, { getCalApi } from "@calcom/embed-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import SiteSEO from "@/components/SEO/SiteSEO";
import { trackEvent, trackCTAClick } from "@/lib/posthog";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";

/**
 * BookDemo page
 * TODO: Replace the Cal.com slugs below with your actual scheduling links.
 * Example: const CAL_BRAND_LINK = "jungl/brand-demo"; const CAL_CREATOR_LINK = "jungl/creator-demo";
 */
const CAL_BRAND_SLUG = "rasmus-bruus/jungl-brand-intro";
const CAL_CREATOR_SLUG = "rasmus-bruus/jungl-creator-intro";
const CAL_BRAND_NAMESPACE = "jungl-brand-intro";
const CAL_CREATOR_NAMESPACE = "jungl-creator-intro";
const BookDemo = () => {
  const [activeTab, setActiveTab] = useState<"brands" | "creators">("brands");
  useEffect(() => {
    (async () => {
      const namespace = activeTab === "brands" ? CAL_BRAND_NAMESPACE : CAL_CREATOR_NAMESPACE;
      const cal = await getCalApi({
        namespace
      });
      // Configure the UI for this namespace
      cal("ui", {
        theme: "dark",
        hideEventTypeDetails: false,
        layout: "month_view"
      });
      // Track successful bookings
      cal("on", {
        action: "bookingSuccessful",
        callback: (e: any) => {
          trackEvent("demo_booking_success", {
            tab: activeTab,
            calLink: activeTab === "brands" ? CAL_BRAND_SLUG : CAL_CREATOR_SLUG,
            ...e?.data
          });
        }
      });
    })();
  }, [activeTab]);
  const handleTabChange = (val: string) => {
    setActiveTab(val as "brands" | "creators");
    trackEvent("book_demo_tab_change", {
      tab: val
    });
  };
  return <>
      <SiteSEO title="Book a Demo | Jungl" description="Book a live demo of Jungl for brands and creators." url="https://jungl.co/book-demo" />

      <Navigation />

      <header className="px-4 sm:px-6 md:px-8 py-16 sm:py-20">
        <div className="mx-auto max-w-3xl text-center">
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-semibold tracking-tight py-[16px]">
            Book a demo
          </h1>
          <p className="mt-4 text-base sm:text-lg opacity-80">
            See how Jungl helps brands and creators collaborate, track deals, and get paid—fast.
          </p>
          
        </div>
      </header>

      <main id="scheduler" className="px-4 sm:px-6 md:px-8 pb-20">
        <section className="mx-auto max-w-5xl">
          <Tabs defaultValue="brands" onValueChange={handleTabChange}>
            <TabsList className="grid grid-cols-2 w-full max-w-md mx-auto">
              <TabsTrigger value="brands">For brands</TabsTrigger>
              <TabsTrigger value="creators">For creators</TabsTrigger>
            </TabsList>

            <TabsContent value="brands">
              <article className="mt-6 h-[820px] sm:h-[760px] rounded-xl overflow-hidden border">
                <Cal namespace={CAL_BRAND_NAMESPACE} calLink={CAL_BRAND_SLUG} style={{
                width: "100%",
                height: "100%",
                overflow: "scroll"
              }} config={{
                layout: "month_view",
                theme: "dark"
              }} />
              </article>
            </TabsContent>

            <TabsContent value="creators">
              <article className="mt-6 h-[820px] sm:h-[760px] rounded-xl overflow-hidden border">
                <Cal namespace={CAL_CREATOR_NAMESPACE} calLink={CAL_CREATOR_SLUG} style={{
                width: "100%",
                height: "100%",
                overflow: "scroll"
              }} config={{
                layout: "month_view",
                theme: "dark"
              }} />
              </article>
            </TabsContent>
          </Tabs>
        </section>
      </main>
      <Footer />
    </>;
};
export default BookDemo;