import { useEffect } from "react";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { AlternateDisplay, H2, Body, BodyLarge } from "@/components/Typography";
import ScrollProgress from "@/components/ScrollProgress";
import BackToTop from "@/components/BackToTop";

const Legal = () => {
  useEffect(() => {
    // Scroll animation observer
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
          }
        });
      },
      { threshold: 0.1, rootMargin: '0px 0px -50px 0px' }
    );

    // Observe all scroll-fade elements
    const scrollElements = document.querySelectorAll('.scroll-fade');
    scrollElements.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  return (
    <>
      <ScrollProgress />
      <Navigation />
      <main role="main">
        {/* Hero Section */}
        <section className="py-20 sm:py-24 lg:py-32 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-black to-zinc-900">
          <div className="max-w-4xl mx-auto text-center">
            <AlternateDisplay className="text-white mb-6">
              Legal Information
            </AlternateDisplay>
            <BodyLarge className="text-zinc-300 text-lg max-w-2xl mx-auto">
              Our terms, policies, and legal commitments to users.
            </BodyLarge>
          </div>
        </section>

        {/* Legal Documents */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
          <div className="max-w-4xl mx-auto">
            <div className="scroll-fade">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="p-6 border border-gray-200 rounded-lg">
                  <H2 className="mb-4 text-black">Terms of Service</H2>
                  <Body className="mb-4 text-black">
                    Our terms of service outline the rules and regulations for using Jungl's platform and services.
                  </Body>
                  <a href="/terms" className="text-black hover:underline">
                    Read Terms of Service →
                  </a>
                </div>

                <div className="p-6 border border-gray-200 rounded-lg">
                  <H2 className="mb-4 text-black">Privacy Policy</H2>
                  <Body className="mb-4 text-black">
                    Learn how we collect, use, and protect your personal information and data.
                  </Body>
                  <a href="/privacy" className="text-black hover:underline">
                    Read Privacy Policy →
                  </a>
                </div>

                <div className="p-6 border border-gray-200 rounded-lg">
                  <H2 className="mb-4 text-black">Cookie Policy</H2>
                  <Body className="mb-4 text-black">
                    Information about how we use cookies and similar technologies on our platform.
                  </Body>
                  <span className="text-gray-500">Coming Soon</span>
                </div>

                <div className="p-6 border border-gray-200 rounded-lg">
                  <H2 className="mb-4 text-black">GDPR Compliance</H2>
                  <Body className="mb-4 text-black">
                    How we ensure compliance with data protection regulations and your rights.
                  </Body>
                  <span className="text-gray-500">Coming Soon</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-50">
          <div className="max-w-4xl mx-auto text-center">
            <div className="scroll-fade">
              <H2 className="mb-8 text-black">Legal Questions?</H2>
              <Body className="text-lg mb-8 text-black">
                If you have any questions about our legal policies or need to report an issue, please contact our legal team.
              </Body>
              <a 
                href="mailto:legal@jungl.com" 
                className="inline-block px-6 py-3 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors"
              >
                Contact Legal Team
              </a>
            </div>
          </div>
        </section>

        <Footer />
      </main>
      <BackToTop />
    </>
  );
};

export default Legal;