import { useEffect } from "react";
import { H2, Body } from "@/components/Typography";
import { Button } from "@/components/ui/button";
import ProblemOption1 from "@/components/problem-variations/ProblemOption1";
import ProblemOption2 from "@/components/problem-variations/ProblemOption2";
import ProblemOption3 from "@/components/problem-variations/ProblemOption3";
import ProblemOption4 from "@/components/problem-variations/ProblemOption4";
import ProblemOption5 from "@/components/problem-variations/ProblemOption5";
import InteractiveJourney from "@/components/merged-variations/InteractiveJourney";
import FeatureDrivenWorkflow from "@/components/merged-variations/FeatureDrivenWorkflow";
import SplitScreenDemo from "@/components/merged-variations/SplitScreenDemo";
import TabbedDemoCenter from "@/components/merged-variations/TabbedDemoCenter";
import ProgressiveStoryFlow from "@/components/merged-variations/ProgressiveStoryFlow";
import ProgressiveStoryFlow51 from "@/components/merged-variations/ProgressiveStoryFlow51";
import ProgressiveStoryFlow52 from "@/components/merged-variations/ProgressiveStoryFlow52";
import ScrollDrivenExperience from "@/components/merged-variations/ScrollDrivenExperience";
import CardFlipReveal from "@/components/merged-variations/CardFlipReveal";
import MinimalistFlow from "@/components/merged-variations/MinimalistFlow";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import ScrollProgress from "@/components/ScrollProgress";
import BackToTop from "@/components/BackToTop";

const TestSections = () => {
  // Add scroll animation functionality
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
          }
        });
      },
      { threshold: 0.1, rootMargin: '0px 0px -50px 0px' }
    );

    const scrollElements = document.querySelectorAll('.scroll-fade');
    scrollElements.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  const options = [
    // Original Problem Section Variations
    {
      id: 'option1',
      title: 'Option 1: Statistical Visual Impact Design',
      description: 'Large central statistic with animated counters and visual data representations',
      component: ProblemOption1
    },
    {
      id: 'option2', 
      title: 'Option 2: Interactive Timeline Design',
      description: 'Timeline showing creator\'s day deteriorating with interactive hover states',
      component: ProblemOption2
    },
    {
      id: 'option3',
      title: 'Option 3: Two-Column Narrative Design',
      description: 'Balanced image and text layout with story-driven approach (current)',
      component: ProblemOption3
    },
    {
      id: 'option4',
      title: 'Option 4: Card-Based Problem Showcase', 
      description: 'Multiple problem cards in a grid with hover effects',
      component: ProblemOption4
    },
    {
      id: 'option5',
      title: 'Option 5: Infographic-Style Design',
      description: 'Visual flow chart showing the creator admin death spiral',
      component: ProblemOption5
    },
    // New Merged Variations
    {
      id: 'interactive-journey',
      title: 'Merged 1: Interactive Journey Timeline',
      description: 'Scrolling timeline integrating video, features, and process steps',
      component: InteractiveJourney
    },
    {
      id: 'feature-driven',
      title: 'Merged 2: Feature-Driven Workflow',
      description: 'Clickable solution cards revealing workflow steps and demos',
      component: FeatureDrivenWorkflow
    },
    {
      id: 'split-screen',
      title: 'Merged 3: Split-Screen Experience',
      description: 'Video on left, synchronized content on right with auto-rotation',
      component: SplitScreenDemo
    },
    {
      id: 'tabbed-center',
      title: 'Merged 4: Tabbed Demo Center',
      description: 'Clean tabbed interface organizing features, process, and demo',
      component: TabbedDemoCenter
    },
    {
      id: 'story-flow',
      title: 'Merged 5: Progressive Story Flow',
      description: 'Natural narrative progression through problem → solution → demo',
      component: ProgressiveStoryFlow
    },
    {
      id: 'story-flow-51',
      title: 'Merged 5.1: Interactive Chapter Story',
      description: 'Chapter-based navigation with progress tracking and enhanced before/after comparisons',
      component: ProgressiveStoryFlow51
    },
    {
      id: 'story-flow-52',
      title: 'Merged 5.2: Auto-Reveal Narrative',
      description: 'Time-based story reveals with dramatic before/after splits and enhanced visuals',
      component: ProgressiveStoryFlow52
    },
    {
      id: 'scroll-driven',
      title: 'New 6: Scroll-Driven Experience',
      description: 'Immersive scroll-based interaction with content that changes as you scroll through features',
      component: ScrollDrivenExperience
    },
    {
      id: 'card-flip',
      title: 'New 7: Card Flip Reveal',
      description: 'Interactive problem→solution cards that flip to reveal transformations with progressive disclosure',
      component: CardFlipReveal
    },
    {
      id: 'minimalist',
      title: 'New 8: Minimalist Flow',
      description: 'Clean before/after comparison with elegant typography and minimal distractions',
      component: MinimalistFlow
    }
  ];

  return (
    <div className="min-h-screen bg-black">
      <Navigation />
      <ScrollProgress />
      
      {/* Page Header */}
      <div className="py-16 px-4 sm:px-6 lg:px-8 bg-black border-b border-zinc-800">
        <div className="max-w-4xl mx-auto text-center">
          <H2 className="text-white mb-4">
            Section Design Testing
          </H2>
          <Body className="text-zinc-300 text-lg">
            Compare ProblemSection variations + 5 new merged approaches combining SolutionCards, HowItWorks & DemoVideo
          </Body>
        </div>
      </div>
      
      {/* Design Options */}
      {options.map((option, index) => {
        const Component = option.component;
        return (
          <div key={option.id}>
            {/* Option Header */}
            <div className="py-8 px-4 sm:px-6 lg:px-8 bg-zinc-900 border-b border-zinc-800">
              <div className="max-w-4xl mx-auto">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                  <div>
                    <h3 className="text-xl font-bold text-white mb-2">{option.title}</h3>
                    <Body className="text-zinc-400">{option.description}</Body>
                  </div>
                  <Button variant="outline" className="shrink-0">
                    Choose This Design
                  </Button>
                </div>
              </div>
            </div>
            
            {/* Component */}
            <section id={option.id}>
              <Component />
            </section>
            
            {/* Separator (except for last item) */}
            {index < options.length - 1 && (
              <div className="h-px bg-zinc-800"></div>
            )}
          </div>
        );
      })}
      
      <Footer />
      <BackToTop />
    </div>
  );
};

export default TestSections;