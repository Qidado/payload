
import { useEffect } from "react";
import Navigation from "@/components/Navigation";
import SiteSEO from "@/components/SEO/SiteSEO";
import Hero from "@/components/Hero";
import ProblemOption5 from "@/components/problem-variations/ProblemOption5";
import DemoVideo from "@/components/DemoVideo";
import SolutionCards from "@/components/SolutionCards";
import TruthBlock from "@/components/TruthBlock";


import PricingPreview from "@/components/PricingPreview";
import FacesOfJungl from "@/components/FacesOfJungl";
import Footer from "@/components/Footer";
import MobileStickyBottom from "@/components/MobileStickyBottom";
import ScrollProgress from "@/components/ScrollProgress";
import SectionNavigation from "@/components/SectionNavigation";
import BackToTop from "@/components/BackToTop";
import { useScrollTracking } from "@/hooks/useScrollTracking";

const Index = () => {
  useScrollTracking();
  
  useEffect(() => {
    // Scroll animation observer
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
          }
        });
      },
      { threshold: 0.1, rootMargin: '0px 0px -50px 0px' }
    );

    // Observe all scroll-fade elements
    const scrollElements = document.querySelectorAll('.scroll-fade');
    scrollElements.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  return (
    <>
      <ScrollProgress />
      <SiteSEO 
        title="Jungl – Run Your Creator Business in One Place"
        description="Invoicing, brand deals, tax reports & collabs—handled. Join the wait‑list for Jungl, the business OS built for creators."
        url="https://jungl.co/"
        image="/lovable-uploads/2990ec87-dea2-4e14-a30f-1d8f657d08f2.png"
      />
      <Navigation />
      <main role="main">
        <section id="hero">
          <Hero />
        </section>
        <div className="bg-black overflow-x-hidden">
          <section id="problem">
            <ProblemOption5 />
          </section>
          <section id="truth">
            <TruthBlock />
          </section>
          <section id="demo">
            <DemoVideo />
          </section>
          <section id="pricing">
            <PricingPreview />
          </section>
          <FacesOfJungl />
          <Footer />
        </div>
      </main>
      <MobileStickyBottom />
      <SectionNavigation />
      <BackToTop />
    </>
  );
};

export default Index;
