import { useEffect, useState } from "react";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import SiteSEO from "@/components/SEO/SiteSEO";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import ScrollProgress from "@/components/ScrollProgress";
import { BlogPostCard } from "@/components/cms/BlogPostCard";
import { getPosts, getCategories } from "@/lib/payload";
import { Post, Category } from "../payload/payload-types";
import { Search } from "lucide-react";

const Blog = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");
  const [posts, setPosts] = useState<Post[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Scroll animation observer
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
          }
        });
      },
      { threshold: 0.1, rootMargin: '0px 0px -50px 0px' }
    );

    const scrollElements = document.querySelectorAll('.scroll-fade');
    scrollElements.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [postsResult, categoriesResult] = await Promise.all([
          getPosts({ limit: 50 }),
          getCategories()
        ]);
        setPosts(postsResult.docs);
        setCategories(categoriesResult.docs);
      } catch (error) {
        console.error('Failed to fetch blog data:', error);
        // Fallback to empty arrays
        setPosts([]);
        setCategories([]);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const filteredPosts = posts.filter((post) => {
    const matchesCategory = activeCategory === "all" || 
      (typeof post.category === 'object' && post.category?.slug === activeCategory);
    
    const matchesSearch = searchQuery === "" ||
      post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.excerpt.toLowerCase().includes(searchQuery.toLowerCase());
    
    return matchesCategory && matchesSearch;
  });

  const categoryTabs = [
    { value: "all", label: "All Posts" },
    ...categories.map(cat => ({
      value: cat.slug,
      label: cat.name
    }))
  ];

  if (loading) {
    return (
      <>
        <ScrollProgress />
        <SiteSEO 
          title="Blog - Creator Business Insights | Jungl"
          description="Get the latest insights, tips, and strategies for growing your creator business. Expert advice on monetization, brand partnerships, and business growth."
          url="https://jungl.co/blog"
        />
        <Navigation />
        <main className="min-h-screen bg-background">
          <div className="container mx-auto px-4 py-16">
            <div className="text-center">Loading...</div>
          </div>
        </main>
        <Footer />
      </>
    );
  }

  return (
    <>
      <ScrollProgress />
      <SiteSEO 
        title="Blog - Creator Business Insights | Jungl"
        description="Get the latest insights, tips, and strategies for growing your creator business. Expert advice on monetization, brand partnerships, and business growth."
        url="https://jungl.co/blog"
      />
      <Navigation />
      <main className="min-h-screen bg-background">
        {/* Hero Section */}
        <section className="bg-gradient-to-br from-primary/5 via-background to-primary/5 py-24">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 scroll-fade">
              Creator Business
              <span className="block text-primary">Insights</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto scroll-fade">
              Get the latest strategies, tips, and insights to grow your creator business and maximize your revenue.
            </p>
            
            {/* Search */}
            <div className="relative max-w-md mx-auto scroll-fade">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                type="text"
                placeholder="Search posts..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
        </section>

        {/* Blog Posts */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <Tabs value={activeCategory} onValueChange={setActiveCategory} className="w-full">
              <TabsList className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 w-full mb-8">
                {categoryTabs.map((tab) => (
                  <TabsTrigger key={tab.value} value={tab.value} className="text-sm">
                    {tab.label}
                  </TabsTrigger>
                ))}
              </TabsList>

              {categoryTabs.map((tab) => (
                <TabsContent key={tab.value} value={tab.value}>
                  {filteredPosts.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {filteredPosts.map((post) => (
                        <BlogPostCard key={post.id} post={post} className="scroll-fade" />
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <p className="text-muted-foreground">
                        {searchQuery ? 
                          `No posts found matching "${searchQuery}"` : 
                          "No posts available in this category yet."
                        }
                      </p>
                    </div>
                  )}
                </TabsContent>
              ))}
            </Tabs>
          </div>
        </section>

        {/* Newsletter Section */}
        <section className="bg-primary/5 py-16">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-4">Stay Updated</h2>
            <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
              Get the latest creator business insights, tips, and strategies delivered to your inbox.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
              <Input placeholder="Enter your email" type="email" className="flex-1" />
              <button className="bg-primary text-primary-foreground px-6 py-2 rounded-md hover:bg-primary/90 transition-colors">
                Subscribe
              </button>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
};

export default Blog;