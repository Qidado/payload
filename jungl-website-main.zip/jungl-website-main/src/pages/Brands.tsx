import { useEffect } from "react";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import BrandsSEO from "@/components/SEO/BrandsSEO";
import BrandsHero from "@/components/brands/BrandsHero";
import RebellionSection from "@/components/brands/RebellionSection";
import BrandProblemSolution from "@/components/brands/BrandProblemSolution";
import HowItWorks from "@/components/brands/HowItWorks";
import KeyDifferentiator from "@/components/brands/KeyDifferentiator";
import ProofSection from "@/components/brands/ProofSection";


import PricingSection from "@/components/brands/PricingSection";

import FooterCTA from "@/components/brands/FooterCTA";
import StickyDemo from "@/components/brands/StickyDemo";
import ScrollProgress from "@/components/ScrollProgress";
import SectionNavigation from "@/components/SectionNavigation";
import BackToTop from "@/components/BackToTop";

const Brands = () => {
  useEffect(() => {
    // Scroll animation observer
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
          }
        });
      },
      { threshold: 0.1, rootMargin: '0px 0px -50px 0px' }
    );

    // Observe all scroll-fade elements
    const scrollElements = document.querySelectorAll('.scroll-fade');
    scrollElements.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  return (
    <>
      <ScrollProgress />
      <BrandsSEO />
      <Navigation variant="dark" />
      <main role="main">
        {/* Hero Section */}
        <section id="hero">
          <BrandsHero />
        </section>
        
        <div className="bg-white overflow-x-hidden">
          {/* Pain/Benefit (DISCOVER → COLLABORATE → CONVERT) */}
          <section id="problem-solution">
            <BrandProblemSolution />
          </section>

          {/* How It Works (3 Steps) */}
          <section id="how-it-works">
            <HowItWorks />
          </section>

          {/* Differentiator (Affiliate & Sales Tracking) */}
          <section id="key-differentiator">
            <KeyDifferentiator />
          </section>

          {/* Proof & Trust (Campaign stats + testimonials + logos) */}
          <section id="proof">
            <ProofSection />
          </section>

          {/* Pricing (Others vs Jungl) */}
          <section id="pricing">
            <PricingSection />
          </section>

          {/* Final CTA (Start Free) */}
          <FooterCTA />

          <Footer />
        </div>
      </main>
      
      {/* Sticky Demo Button */}
      <StickyDemo />
      <SectionNavigation />
      <BackToTop />
    </>
  );
};

export default Brands;