import { useEffect } from "react";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { AlternateDisplay, H2, Body, BodyLarge } from "@/components/Typography";
import ScrollProgress from "@/components/ScrollProgress";
import BackToTop from "@/components/BackToTop";

const About = () => {
  useEffect(() => {
    // Scroll animation observer
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
          }
        });
      },
      { threshold: 0.1, rootMargin: '0px 0px -50px 0px' }
    );

    // Observe all scroll-fade elements
    const scrollElements = document.querySelectorAll('.scroll-fade');
    scrollElements.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  return (
    <>
      <ScrollProgress />
      <Navigation />
      <main role="main">
        {/* Hero Section */}
        <section className="py-20 sm:py-24 lg:py-32 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-black to-zinc-900">
          <div className="max-w-4xl mx-auto text-center">
            <AlternateDisplay className="text-white mb-6">
              About Jungl
            </AlternateDisplay>
            <BodyLarge className="text-zinc-300 text-lg max-w-2xl mx-auto">
              We're building the future of creator-brand partnerships.
            </BodyLarge>
          </div>
        </section>

        {/* Mission Section */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
          <div className="max-w-4xl mx-auto">
            <div className="scroll-fade">
              <H2 className="mb-8 text-center text-black">Our Mission</H2>
              <Body className="text-lg leading-relaxed mb-8 text-black">
                Jungl was founded with a simple belief: authentic creator-brand partnerships shouldn't be complicated, expensive, or unfair. We're building a platform that empowers creators to monetize their influence while helping brands connect with audiences in meaningful ways.
              </Body>
              <Body className="text-lg leading-relaxed text-black">
                Our mission is to democratize influencer marketing by making it accessible to creators of all sizes and brands of all budgets. We believe that when creators succeed, brands succeed, and communities thrive.
              </Body>
            </div>
          </div>
        </section>

        {/* Values Section */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-50">
          <div className="max-w-4xl mx-auto">
            <div className="scroll-fade">
              <H2 className="mb-12 text-center text-black">Our Values</H2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="text-center">
                  <H2 className="mb-4 text-black">Transparency</H2>
                  <Body className="text-black">Clear pricing, honest communication, and fair partnerships for everyone.</Body>
                </div>
                <div className="text-center">
                  <H2 className="mb-4 text-black">Creator-First</H2>
                  <Body className="text-black">You keep 100% of your earnings. We succeed when creators succeed.</Body>
                </div>
                <div className="text-center">
                  <H2 className="mb-4 text-black">Innovation</H2>
                  <Body className="text-black">Constantly improving our platform to serve creators and brands better.</Body>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Team Section */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
          <div className="max-w-4xl mx-auto text-center">
            <div className="scroll-fade">
              <H2 className="mb-8 text-black">Built by Creators, for Creators</H2>
              <Body className="text-lg leading-relaxed text-black">
                Our team combines deep experience in creator economy, technology, and brand marketing. We understand the challenges because we've lived them, and we're committed to building solutions that actually work.
              </Body>
            </div>
          </div>
        </section>

        <Footer />
      </main>
      <BackToTop />
    </>
  );
};

export default About;