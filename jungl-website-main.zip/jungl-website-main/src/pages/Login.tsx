import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import SiteSEO from "@/components/SEO/SiteSEO";
import { Button } from "@/components/ui/button";
import { Building2, Smartphone } from "lucide-react";

const Login = () => {
  const handleAppStoreClick = () => {
    // This will open the App Store
    window.open("https://apps.apple.com/dk/app/jungl-creator-business-hub/id6741893457", "_blank");
  };

  return (
    <>
      <SiteSEO title="Login – Jungl" description="Login to continue to Jungl." url="https://jungl.co/login" noindex />
      <Navigation />
      <div className="bg-black min-h-screen">
        {/* Hero Section */}
        <section className="relative pt-32 pb-20 px-4 sm:px-6 md:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight">
              Welcome back to
              <span className="block text-transparent bg-clip-text bg-gradient-to-r from-white to-gray-400">
                Jungl
              </span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-300 mb-12 max-w-3xl mx-auto leading-relaxed">
              Choose your path to continue
            </p>
          </div>
        </section>

        {/* Login Options */}
        <section className="py-20 px-4 sm:px-6 md:px-8">
          <div className="max-w-4xl mx-auto">
            <div className="grid md:grid-cols-2 gap-8">
              {/* Brands Login */}
              <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 text-center hover:bg-white/15 transition-all duration-300">
                <div className="bg-white/20 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-6">
                  <Building2 className="w-10 h-10 text-white" />
                </div>
                <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">
                  For Brands
                </h2>
                <p className="text-gray-300 mb-8 text-lg">
                  Access your brand dashboard to manage campaigns, find creators, and track performance.
                </p>
                <Button 
                  className="bg-white text-black hover:opacity-90 font-semibold px-8 py-4 text-lg w-full"
                  onClick={() => window.open("https://business.jungl.co/dashboard", "_blank")}
                >
                  Brand Dashboard
                </Button>
              </div>

              {/* Creators Login */}
              <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 text-center hover:bg-white/15 transition-all duration-300">
                <div className="bg-white/20 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-6">
                  <Smartphone className="w-10 h-10 text-white" />
                </div>
                <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">
                  For Creators
                </h2>
                <p className="text-gray-300 mb-8 text-lg">
                  Download the Jungl app to manage your content, connect with brands, and grow your audience.
                </p>
                <Button 
                  className="bg-white text-black hover:opacity-90 font-semibold px-8 py-4 text-lg w-full"
                  onClick={handleAppStoreClick}
                >
                  Download App
                </Button>
              </div>
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
};

export default Login;