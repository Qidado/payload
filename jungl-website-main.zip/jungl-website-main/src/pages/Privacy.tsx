import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";

const Privacy = () => {
  return (
    <>
      <Navigation />
      <div className="bg-black min-h-screen pt-32 pb-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 md:px-8">
          <div className="prose prose-invert max-w-none">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-8">
              Privacy Policy
            </h1>
            <p className="text-gray-300 text-lg mb-8">
              (for Jungl ApS websites and apps)
            </p>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-white mb-4">1. Purpose of This Policy</h2>
              <p className="text-gray-300 leading-relaxed">
                The purpose of this privacy policy is to inform you of how Jungl ApS ("Jungl", "we", "us") processes your personal data. We wish to make you aware of the information we collect, the reasons for processing it, and, where applicable, the duration of storage. This policy governs the processing of personal data in connection with your interactions, registration, and use of our websites, apps, and digital services.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-white mb-4">2. Description of Processing</h2>
              <p className="text-gray-300 leading-relaxed mb-6">
                Jungl processes your personal data for one or more specific purposes and in accordance with the applicable data protection regulations, including the GDPR. We process your information if you are a customer, have created a brand or influencer account on our platform, applied for a position with us, or signed up for our newsletter. Generally, the information is provided directly by you, and we retain and process it only for as long as necessary to fulfill the purposes for which it was collected.
              </p>
              <p className="text-gray-300 leading-relaxed mb-6">
                Below are the primary categories and purposes for which we process your data:
              </p>

              <div className="space-y-6">
                <div>
                  <h3 className="text-xl font-semibold text-white mb-3">2.1 Managing Purchases and Subscriptions</h3>
                  <p className="text-gray-300 leading-relaxed mb-3">
                    When you purchase our services or subscribe to our platform, we may process the personal data of your company's contact person. This includes:
                  </p>
                  <ul className="text-gray-300 ml-4 mb-3 space-y-1">
                    <li>• Contact details: Name, company name, position, telephone number, and email address</li>
                    <li>• Transaction details: Purchase history and payment information</li>
                  </ul>
                  <p className="text-gray-300 leading-relaxed mb-2">
                    <strong>Legal basis:</strong> Processing is necessary for the performance of a contract with you (GDPR Article 6(1)(b)).
                  </p>
                  <p className="text-gray-300 leading-relaxed">
                    <strong>Retention:</strong> We retain data related to purchases and subscriptions for the current financial year plus 5 years (in accordance with the Danish Bookkeeping Act).
                  </p>
                </div>

                <div>
                  <h3 className="text-xl font-semibold text-white mb-3">2.2 Paying Customers (Brands)</h3>
                  <p className="text-gray-300 leading-relaxed mb-3">
                    For our business customers who subscribe to our digital platform or collaborate with us, we process general personal information of employees or representatives. This information is used to:
                  </p>
                  <ul className="text-gray-300 ml-4 mb-3 space-y-1">
                    <li>• Enhance and improve our platform and services</li>
                    <li>• Contact you regarding guidance on using our digital platform or subscription options</li>
                  </ul>
                  <p className="text-gray-300 leading-relaxed mb-3">Data collected may include:</p>
                  <ul className="text-gray-300 ml-4 mb-3 space-y-1">
                    <li>• Email address</li>
                    <li>• Phone number</li>
                    <li>• Job title</li>
                    <li>• Company name</li>
                    <li>• Full name of the contact person</li>
                    <li>• Business registration details (if applicable)</li>
                  </ul>
                  <p className="text-gray-300 leading-relaxed">
                    <strong>Legal basis:</strong> We process your data to enter into and fulfill a service agreement with you (GDPR Article 6(1)(b)).
                  </p>
                </div>

                <div>
                  <h3 className="text-xl font-semibold text-white mb-3">2.3 Influencer Profile</h3>
                  <p className="text-gray-300 leading-relaxed mb-3">
                    When you create an influencer account on our platform, we process your personal information to help match you with brand campaigns and collaborations. Typically, we collect standard personal data such as:
                  </p>
                  <ul className="text-gray-300 ml-4 mb-3 space-y-1">
                    <li>• Basic information: Name, profile picture, biography, email address, phone number, and address</li>
                    <li>• Additional details: Country, gender, birthday, and categories of interest</li>
                    <li>• Identification and verification: In some cases, additional data (e.g., personal identification number, passport or driver's license details, bank information, tax identification number) may be required</li>
                  </ul>
                  <p className="text-gray-300 leading-relaxed mb-3">
                    If you choose to connect your social media accounts (e.g., Facebook, Instagram, TikTok) with your Jungl profile, we will also collect information available through those platforms according to your privacy settings and the respective platform's privacy policies. This may include:
                  </p>
                  <ul className="text-gray-300 ml-4 mb-3 space-y-1">
                    <li>• Social media username and profile name</li>
                    <li>• Profile picture and biography</li>
                    <li>• Public engagement data (e.g., likes, comments, insights)</li>
                  </ul>
                  <p className="text-gray-300 leading-relaxed mb-3">
                    <strong>Sensitive Data:</strong> We process any sensitive personal data (e.g., regarding race, ethnic origin, etc.) only if it is made publicly available or provided by you.
                  </p>
                  <p className="text-gray-300 leading-relaxed mb-2">
                    <strong>Consent and Retention:</strong>
                  </p>
                  <ul className="text-gray-300 ml-4 mb-3 space-y-1">
                    <li>• Registration as an influencer is based on your explicit consent (GDPR Article 6(1)(a)). You may withdraw this consent at any time by contacting us at support@jungl.co.</li>
                    <li>• Your influencer profile will remain active until you request deletion or up to 3 years after your last login, after which it will be removed.</li>
                    <li>• Payment-related data connected with influencer collaborations will be retained for the current financial year plus 5 years in accordance with the Danish Bookkeeping Act.</li>
                  </ul>
                </div>

                <div>
                  <h3 className="text-xl font-semibold text-white mb-3">2.4 Optimization of Services</h3>
                  <p className="text-gray-300 leading-relaxed mb-3">
                    To continuously improve our platform and services, we collect and analyze various data points to understand user interactions. These data points are gathered when you register for an account and during your use of our services. The information may include:
                  </p>
                  <ul className="text-gray-300 ml-4 mb-3 space-y-1">
                    <li>• Name, gender, and birthdate</li>
                    <li>• Company and address details</li>
                    <li>• Email address and phone number</li>
                    <li>• Payment information and data provided via forms</li>
                  </ul>
                  <p className="text-gray-300 leading-relaxed mb-2">
                    <strong>Anonymization & Consent:</strong>
                  </p>
                  <ul className="text-gray-300 ml-4 mb-3 space-y-1">
                    <li>• Most of these data points are anonymized before analysis.</li>
                    <li>• If non-anonymized data is required for a particular purpose, we will seek your explicit consent (GDPR Article 6(1)(a)). You may withdraw your consent at any time.</li>
                    <li>• In cases where no explicit consent is obtained, processing may be carried out based on our legitimate interest (GDPR Article 6(1)(f)) provided this does not conflict with your rights.</li>
                  </ul>
                  <p className="text-gray-300 leading-relaxed">
                    <strong>Retention:</strong> Non-anonymized data is generally kept for up to 3 years before being deleted or anonymized.
                  </p>
                </div>

                <div>
                  <h3 className="text-xl font-semibold text-white mb-3">2.5 Website Data Collection</h3>
                  <p className="text-gray-300 leading-relaxed mb-3">
                    When you visit our website, we use cookies and similar technologies (such as pixels) to collect personal data. This helps us:
                  </p>
                  <ul className="text-gray-300 ml-4 mb-3 space-y-1">
                    <li>• Enhance the website's appearance and user experience</li>
                    <li>• Gather statistics on your visit (e.g., activity, preferences, behavior, IP address, browser type)</li>
                  </ul>
                  <p className="text-gray-300 leading-relaxed mb-2">
                    <strong>Consent:</strong>
                  </p>
                  <ul className="text-gray-300 ml-4 mb-3 space-y-1">
                    <li>• Personal data is only collected with your prior consent, which you may withdraw at any time.</li>
                    <li>• For further details, please refer to our cookie policy available on our website.</li>
                  </ul>
                </div>

                <div>
                  <h3 className="text-xl font-semibold text-white mb-3">2.6 Customer Relationship Management and Support</h3>
                  <p className="text-gray-300 leading-relaxed mb-3">
                    To provide you with support and manage our relationship, we process your personal data, including:
                  </p>
                  <ul className="text-gray-300 ml-4 mb-3 space-y-1">
                    <li>• Name, company, position, telephone number, email address</li>
                    <li>• Details of your support inquiries</li>
                  </ul>
                  <p className="text-gray-300 leading-relaxed mb-2">
                    <strong>Legal basis:</strong> This processing is necessary to fulfill our contractual obligations (GDPR Article 6(1)(b)).
                  </p>
                  <p className="text-gray-300 leading-relaxed">
                    <strong>Retention:</strong> We delete such data on an ongoing basis, but no later than 3 years after the end of our customer relationship.
                  </p>
                </div>

                <div>
                  <h3 className="text-xl font-semibold text-white mb-3">2.7 Job Applicants</h3>
                  <p className="text-gray-300 leading-relaxed mb-3">
                    If you apply for a job at Jungl, we process your personal data to evaluate your suitability for the role. This may include:
                  </p>
                  <ul className="text-gray-300 ml-4 mb-3 space-y-1">
                    <li>• Name, address, telephone number, email address, and birthdate</li>
                    <li>• Application documents such as your CV, cover letter, photographs, academic records</li>
                    <li>• Test results, references, and interview notes</li>
                  </ul>
                  <p className="text-gray-300 leading-relaxed mb-2">
                    <strong>Legal basis:</strong> Processing is necessary to assess your application and, where applicable, to enter into an employment agreement (GDPR Article 6(1)(b)). We may also process certain information based on our legitimate interest (GDPR Article 6(1)(f)).
                  </p>
                  <p className="text-gray-300 leading-relaxed">
                    <strong>Retention:</strong> Your data is stored until the position is filled. If we wish to keep your data for future opportunities beyond the recruitment process, we will obtain your explicit consent.
                  </p>
                </div>

                <div>
                  <h3 className="text-xl font-semibold text-white mb-3">2.8 Newsletters and Marketing Communications</h3>
                  <p className="text-gray-300 leading-relaxed mb-3">
                    If you subscribe to our newsletter or marketing communications, we process your name and email address to send you updates, news, and promotional materials.
                  </p>
                  <p className="text-gray-300 leading-relaxed mb-2">
                    <strong>Legal basis:</strong> Processing is based on your consent (GDPR Article 6(1)(a)).
                  </p>
                  <p className="text-gray-300 leading-relaxed mb-2">
                    <strong>Withdrawal:</strong> You may withdraw your consent at any time by contacting us at support@jungl.co or by clicking the unsubscribe link provided in every email.
                  </p>
                  <p className="text-gray-300 leading-relaxed">
                    <strong>Retention:</strong> We retain a record of your consent for 2 years after you unsubscribe (this period corresponds with the expiry of any potential criminal liability).
                  </p>
                </div>

                <div>
                  <h3 className="text-xl font-semibold text-white mb-3">2.9 Suppliers and Collaborators</h3>
                  <p className="text-gray-300 leading-relaxed mb-3">
                    When entering into agreements with suppliers or collaborators, we process the personal data of their contact persons, which may include:
                  </p>
                  <ul className="text-gray-300 ml-4 mb-3 space-y-1">
                    <li>• Name, position, telephone number, email address, and, if necessary, payment information</li>
                  </ul>
                  <p className="text-gray-300 leading-relaxed mb-2">
                    <strong>Legal basis:</strong> Processing is necessary to establish an agreement (GDPR Article 6(1)(b)) or is based on our legitimate interests (GDPR Article 6(1)(f)).
                  </p>
                  <p className="text-gray-300 leading-relaxed">
                    <strong>Retention:</strong> Written correspondence is deleted continuously, while data required for compliance with bookkeeping regulations is stored for the current financial year plus 5 years.
                  </p>
                </div>

                <div>
                  <h3 className="text-xl font-semibold text-white mb-3">2.10 Notification by Statutory Processing</h3>
                  <p className="text-gray-300 leading-relaxed mb-3">
                    In certain cases, we process your personal data based on legal requirements or to establish a customer relationship. You are required to provide the necessary information so that we can:
                  </p>
                  <ul className="text-gray-300 ml-4 mb-3 space-y-1">
                    <li>• Establish and maintain the relationship</li>
                    <li>• Provide you with an account, services, or to issue invoices</li>
                  </ul>
                  <p className="text-gray-300 leading-relaxed">
                    If you choose not to provide the required data, we may be unable to establish or continue our relationship with you.
                  </p>
                </div>

                <div>
                  <h3 className="text-xl font-semibold text-white mb-3">2.11 Recipients of Personal Data</h3>
                  <p className="text-gray-300 leading-relaxed mb-3">
                    We treat your personal data confidentially and do not share it with third parties except under the following circumstances:
                  </p>
                  <ul className="text-gray-300 ml-4 mb-3 space-y-1">
                    <li>• When necessary to perform our services (e.g., system and hosting providers, payment service providers, support providers, social media marketing partners)</li>
                    <li>• When you have given your explicit consent</li>
                    <li>• When disclosure is required by law or based on our legitimate interests</li>
                  </ul>
                  <p className="text-gray-300 leading-relaxed">
                    Some third-party service providers with whom we share your data may be located outside the EU/EEA (for example, in the USA). In such cases, we ensure that appropriate legal safeguards are in place (including the use of EU Commission Standard Contractual Clauses). If you wish to review the legal basis for any cross-border data transfers, please contact us at support@jungl.co.
                  </p>
                </div>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-white mb-4">3. Your Rights</h2>
              <p className="text-gray-300 leading-relaxed mb-3">
                Under applicable data protection laws, you have the following rights regarding your personal data:
              </p>
              <ul className="text-gray-300 ml-4 mb-4 space-y-1">
                <li>• <strong>Access:</strong> The right to request access to your personal data.</li>
                <li>• <strong>Rectification:</strong> The right to request correction of any inaccurate or incomplete data.</li>
                <li>• <strong>Erasure:</strong> The right to request deletion of your personal data (subject to applicable legal restrictions).</li>
                <li>• <strong>Restriction:</strong> The right to request limitations on how your data is processed.</li>
                <li>• <strong>Objection:</strong> The right to object to processing based on our legitimate interests.</li>
                <li>• <strong>Data Portability:</strong> The right to receive your data in a structured, commonly used, and machine-readable format.</li>
              </ul>
              <p className="text-gray-300 leading-relaxed mb-4">
                If you have given your consent to our processing, you also have the right to withdraw that consent at any time. To exercise any of these rights—or if you wish to have your associated profile deleted—please contact us at support@jungl.co.
              </p>
              <p className="text-gray-300 leading-relaxed">
                If you are dissatisfied with our handling of your personal data, you have the right to lodge a complaint with the Danish Data Protection Agency (Datatilsynet) via their website at www.datatilsynet.dk/english or by phone at +45 33 19 32 00.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-white mb-4">4. Our Contact Information</h2>
              <p className="text-gray-300 leading-relaxed mb-3">
                The company responsible for processing your personal data is:
              </p>
              <div className="text-gray-300 leading-relaxed">
                <p>Jungl ApS</p>
                <p>CVR: 45319717</p>
                <p>Address: Kronprinsessegade 54, 5. tv, 1306 København K, Danmark</p>
                <p>Email: support@jungl.co</p>
              </div>
              <p className="text-gray-300 leading-relaxed mt-4">
                If you have any questions regarding this privacy policy or our data processing practices, please do not hesitate to contact us.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-white mb-4">5. Keeping Your Data Safe</h2>
              <p className="text-gray-300 leading-relaxed">
                We employ reasonable physical, technical, and organizational measures to protect your personal data within our organization. However, please be aware that the Internet is not a completely secure environment, and we cannot guarantee the absolute security of data transmitted to us. For this reason, we advise you not to include any confidential or highly sensitive information when communicating with us via email.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-white mb-4">6. Revision of This Privacy Policy</h2>
              <p className="text-gray-300 leading-relaxed">
                We reserve the right to amend or update this privacy policy from time to time. In the event of significant changes, we will notify you via email or by posting a prominent notice on our website.
              </p>
              <p className="text-gray-300 leading-relaxed mt-4">
                <strong>Last Revised:</strong> February 10, 2025
              </p>
            </section>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default Privacy;