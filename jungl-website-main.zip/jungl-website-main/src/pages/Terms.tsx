import { useEffect } from "react";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { AlternateDisplay, H2, H3, Body, BodyLarge } from "@/components/Typography";
import ScrollProgress from "@/components/ScrollProgress";
import BackToTop from "@/components/BackToTop";

const Terms = () => {
  useEffect(() => {
    // Scroll animation observer
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
          }
        });
      },
      { threshold: 0.1, rootMargin: '0px 0px -50px 0px' }
    );

    // Observe all scroll-fade elements
    const scrollElements = document.querySelectorAll('.scroll-fade');
    scrollElements.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  return (
    <>
      <ScrollProgress />
      <Navigation />
      <main role="main">
        {/* Hero Section */}
        <section className="py-20 sm:py-24 lg:py-32 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-black to-zinc-900">
          <div className="max-w-4xl mx-auto text-center">
            <AlternateDisplay className="text-white mb-6">
              Terms of Service
            </AlternateDisplay>
            <BodyLarge className="text-zinc-300 text-lg max-w-2xl mx-auto">
              Last updated: Coming Soon
            </BodyLarge>
          </div>
        </section>

        {/* Terms Content */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
          <div className="max-w-4xl mx-auto prose prose-lg">
            <div className="scroll-fade">
              <H2>1. Acceptance of Terms</H2>
              <Body className="mb-6">
                By accessing and using Jungl's platform and services, you accept and agree to be bound by the terms and provision of this agreement.
              </Body>

              <H2>2. Description of Service</H2>
              <Body className="mb-6">
                Jungl provides a platform that connects content creators with brands for marketing collaborations. Our service includes tools for campaign management, content creation, and payment processing.
              </Body>

              <H2>3. User Accounts</H2>
              <Body className="mb-6">
                To use our service, you must create an account and provide accurate, complete, and current information. You are responsible for maintaining the confidentiality of your account credentials.
              </Body>

              <H2>4. Creator Terms</H2>
              <Body className="mb-6">
                Creators keep 100% of their earnings from brand partnerships. Jungl does not charge transaction fees to creators. Creators are responsible for delivering content according to agreed terms with brands.
              </Body>

              <H2>5. Brand Terms</H2>
              <Body className="mb-6">
                Brands pay a platform fee for using our services to connect with creators. Payment terms and campaign requirements will be specified in individual campaign agreements.
              </Body>

              <H2>6. Content and Intellectual Property</H2>
              <Body className="mb-6">
                Users retain ownership of their content. By using our platform, you grant Jungl a limited license to display and distribute your content as necessary to provide our services.
              </Body>

              <H2>7. Prohibited Uses</H2>
              <Body className="mb-6">
                Users may not use our platform for any unlawful purpose or to engage in conduct that is harmful to other users, our platform, or third parties.
              </Body>

              <H2>8. Privacy</H2>
              <Body className="mb-6">
                Your privacy is important to us. Please review our Privacy Policy, which also governs your use of our services.
              </Body>

              <H2>9. Termination</H2>
              <Body className="mb-6">
                We may terminate or suspend your account immediately, without prior notice or liability, for any reason whatsoever, including without limitation if you breach the Terms.
              </Body>

              <H2>10. Changes to Terms</H2>
              <Body className="mb-6">
                We reserve the right to modify or replace these Terms at any time. We will provide notice of any material changes before they become effective.
              </Body>

              <H2>11. Contact Information</H2>
              <Body className="mb-6">
                If you have any questions about these Terms of Service, please contact us at legal@jungl.com.
              </Body>
            </div>
          </div>
        </section>

        <Footer />
      </main>
      <BackToTop />
    </>
  );
};

export default Terms;