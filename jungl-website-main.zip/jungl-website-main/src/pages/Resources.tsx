import { useEffect, useState } from "react";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import SiteSEO from "@/components/SEO/SiteSEO";
import { AlternateDisplay, Body, H2, H3 } from "@/components/Typography";
import ScrollProgress from "@/components/ScrollProgress";
import BackToTop from "@/components/BackToTop";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Search, BookOpen, FileText, Video, Users, Download, ExternalLink, Clock, Star } from "lucide-react";
import { ResourceCard } from "@/components/cms/ResourceCard";
import { getResources, getCategories } from "@/lib/payload";
import { Resource, Category } from "../payload/payload-types";

const Resources = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");
  const [resources, setResources] = useState<Resource[]>([]);
  const [featuredResources, setFeaturedResources] = useState<Resource[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Scroll animation observer
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
          }
        });
      },
      { threshold: 0.1, rootMargin: '0px 0px -50px 0px' }
    );

    const scrollElements = document.querySelectorAll('.scroll-fade');
    scrollElements.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [allResourcesResult, featuredResult, categoriesResult] = await Promise.all([
          getResources({ limit: 50 }),
          getResources({ featured: true, limit: 10 }),
          getCategories()
        ]);
        
        setResources(allResourcesResult.docs);
        setFeaturedResources(featuredResult.docs);
        setCategories(categoriesResult.docs);
      } catch (error) {
        console.error('Failed to fetch resources:', error);
        // Fallback to static data for demo
        setResources(fallbackResources);
        setFeaturedResources(fallbackResources.filter(r => r.featured));
        setCategories(fallbackCategories);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  // Fallback data for development
  const fallbackCategories: Category[] = [
    { id: "1", name: "Guides", slug: "guides", createdAt: "", updatedAt: "" },
    { id: "2", name: "Templates", slug: "templates", createdAt: "", updatedAt: "" },
    { id: "3", name: "Tools", slug: "tools", createdAt: "", updatedAt: "" },
    { id: "4", name: "Community", slug: "community", createdAt: "", updatedAt: "" },
  ];

  const fallbackResources: Resource[] = [
    {
      id: "1",
      title: "Complete Creator Business Setup Guide",
      slug: "creator-business-setup",
      description: "Learn how to structure your creator business for maximum growth and tax benefits.",
      category: fallbackCategories[0],
      type: "guide",
      featured: true,
      image: "/lovable-uploads/3d8690ac-1ce9-4e14-b2be-53745c43eea8.png",
      tags: [{ tag: "Business" }, { tag: "Tax" }, { tag: "Legal" }],
      estimatedTime: "15 min read",
      difficulty: "beginner",
      createdAt: "",
      updatedAt: ""
    },
    {
      id: "2", 
      title: "Brand Deal Negotiation Template",
      slug: "brand-deal-template",
      description: "Professional email templates and rate cards for negotiating brand partnerships.",
      category: fallbackCategories[1],
      type: "template",
      featured: true,
      image: "/lovable-uploads/56495540-5978-42a9-b48e-d0df60b46803.png",
      tags: [{ tag: "Partnerships" }, { tag: "Templates" }, { tag: "Email" }],
      downloadUrl: "#",
      difficulty: "intermediate",
      createdAt: "",
      updatedAt: ""
    },
    {
      id: "3",
      title: "Tax Deduction Checklist",
      slug: "tax-deduction-checklist", 
      description: "Comprehensive list of business expenses you can deduct as a creator.",
      category: fallbackCategories[0],
      type: "checklist",
      featured: false,
      tags: [{ tag: "Tax" }, { tag: "Finance" }],
      estimatedTime: "10 min read",
      difficulty: "beginner",
      createdAt: "",
      updatedAt: ""
    }
  ];

  const resourceCategories = [
    { id: "all", label: "All Resources", icon: BookOpen },
    ...categories.map(cat => ({
      id: cat.slug,
      label: cat.name,
      icon: FileText
    }))
  ];

  const filteredResources = resources.filter(resource => {
    const matchesCategory = activeCategory === "all" || 
      (typeof resource.category === 'object' && resource.category?.slug === activeCategory);
    
    const matchesSearch = searchQuery === "" ||
      resource.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      resource.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (resource.tags && resource.tags.some(tagObj => 
        typeof tagObj === 'object' && tagObj.tag?.toLowerCase().includes(searchQuery.toLowerCase())
      ));
    
    return matchesCategory && matchesSearch;
  });

  if (loading) {
    return (
      <>
        <SiteSEO
          title="Creator Business Resources & Guides | Jungl"
          description="Free guides, templates, and resources to help creators build and grow their business. Learn about invoicing, taxes, brand deals, and more."
          url="https://jungl.co/resources"
          image="/lovable-uploads/2990ec87-dea2-4e14-a30f-1d8f657d08f2.png"
        />
        <ScrollProgress />
        <Navigation />
        <main className="min-h-screen bg-background">
          <div className="container mx-auto px-4 py-16">
            <div className="text-center">Loading resources...</div>
          </div>
        </main>
        <Footer />
      </>
    );
  }

  return (
    <>
      <SiteSEO
        title="Creator Business Resources & Guides | Jungl"
        description="Free guides, templates, and resources to help creators build and grow their business. Learn about invoicing, taxes, brand deals, and more."
        url="https://jungl.co/resources"
        image="/lovable-uploads/2990ec87-dea2-4e14-a30f-1d8f657d08f2.png"
      />
      <ScrollProgress />
      <Navigation />
      <main role="main">
        {/* Hero Section */}
        <section className="py-20 sm:py-24 lg:py-32 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-black to-zinc-900">
          <div className="max-w-4xl mx-auto text-center">
            <AlternateDisplay className="text-white mb-6 scroll-fade">
              Creator Business Resources
            </AlternateDisplay>
            <Body className="text-zinc-300 text-lg max-w-2xl mx-auto mb-8 scroll-fade">
              Free guides, templates, and tools to help you build and scale your creator business like a pro.
            </Body>
            
            {/* Search Bar */}
            <div className="max-w-md mx-auto relative scroll-fade">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-zinc-400 h-4 w-4" />
              <Input
                placeholder="Search resources..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-zinc-800 border-zinc-700 text-white placeholder-zinc-400"
              />
            </div>
          </div>
        </section>

        {/* Featured Resources */}
        {featuredResources.length > 0 && (
          <section className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
            <div className="max-w-7xl mx-auto">
              <div className="text-center mb-12">
                <H2 className="mb-4 scroll-fade">Featured Resources</H2>
                <Body className="text-zinc-600 max-w-2xl mx-auto scroll-fade">
                  Hand-picked resources to kickstart your creator business journey.
                </Body>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {featuredResources.map((resource) => (
                  <ResourceCard key={resource.id} resource={resource} className="scroll-fade" />
                ))}
              </div>
            </div>
          </section>
        )}

        {/* All Resources */}
        <section className="py-20 px-4 sm:px-6 lg:px-8 bg-zinc-50">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-12">
              <H2 className="mb-4 scroll-fade">All Resources</H2>
              <Body className="text-zinc-600 max-w-2xl mx-auto scroll-fade">
                Browse our complete library of creator business resources.
              </Body>
            </div>

            {/* Category Tabs */}
            <Tabs value={activeCategory} onValueChange={setActiveCategory} className="mb-8">
              <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 lg:w-fit lg:mx-auto">
                {resourceCategories.map((category) => {
                  const Icon = category.icon;
                  return (
                    <TabsTrigger key={category.id} value={category.id} className="flex items-center gap-2">
                      <Icon className="h-4 w-4" />
                      <span className="hidden sm:inline">{category.label}</span>
                    </TabsTrigger>
                  );
                })}
              </TabsList>

              {resourceCategories.map((category) => (
                <TabsContent key={category.id} value={category.id}>
                  {filteredResources.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {filteredResources.map((resource) => (
                        <ResourceCard key={resource.id} resource={resource} className="scroll-fade" />
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <Body className="text-zinc-500">
                        {searchQuery ? 
                          `No resources found matching "${searchQuery}"` : 
                          "No resources available in this category yet."
                        }
                      </Body>
                    </div>
                  )}
                </TabsContent>
              ))}
            </Tabs>
          </div>
        </section>

        {/* Newsletter CTA */}
        <section className="py-20 px-4 sm:px-6 lg:px-8 bg-black">
          <div className="max-w-4xl mx-auto text-center">
            <H2 className="text-white mb-4 scroll-fade">Stay Updated</H2>
            <Body className="text-zinc-300 mb-8 max-w-2xl mx-auto scroll-fade">
              Get notified when we publish new guides, templates, and resources to help grow your creator business.
            </Body>
            <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto scroll-fade">
              <Input 
                placeholder="Enter your email" 
                className="bg-zinc-800 border-zinc-700 text-white placeholder-zinc-400"
              />
              <Button>Subscribe</Button>
            </div>
          </div>
        </section>

        <Footer />
      </main>
      <BackToTop />
    </>
  );
};

export default Resources;