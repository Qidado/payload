import { useEffect } from "react";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { AlternateDisplay, H2, H3, Body, BodyLarge } from "@/components/Typography";
import ScrollProgress from "@/components/ScrollProgress";
import BackToTop from "@/components/BackToTop";

const Press = () => {
  useEffect(() => {
    // Scroll animation observer
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
          }
        });
      },
      { threshold: 0.1, rootMargin: '0px 0px -50px 0px' }
    );

    // Observe all scroll-fade elements
    const scrollElements = document.querySelectorAll('.scroll-fade');
    scrollElements.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  return (
    <>
      <ScrollProgress />
      <Navigation />
      <main role="main">
        {/* Hero Section */}
        <section className="py-20 sm:py-24 lg:py-32 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-black to-zinc-900">
          <div className="max-w-4xl mx-auto text-center">
            <AlternateDisplay className="text-white mb-6">
              Press Resources
            </AlternateDisplay>
            <BodyLarge className="text-zinc-300 text-lg max-w-2xl mx-auto">
              Media resources, press releases, and company information for journalists and media professionals.
            </BodyLarge>
          </div>
        </section>

        {/* Media Kit */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
          <div className="max-w-4xl mx-auto">
            <div className="scroll-fade">
              <H2 className="mb-8 text-center text-black">Media Kit</H2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="p-6 border border-gray-200 rounded-lg">
                  <H3 className="mb-4 text-black">Brand Assets</H3>
                  <Body className="mb-4 text-black">
                    Download our official logos, brand guidelines, and visual assets.
                  </Body>
                  <button className="text-primary hover:underline">
                    Download Brand Kit →
                  </button>
                </div>

                <div className="p-6 border border-gray-200 rounded-lg">
                  <H3 className="mb-4 text-black">Company Photos</H3>
                  <Body className="mb-4 text-black">
                    High-resolution photos of our team, office, and product screenshots.
                  </Body>
                  <button className="text-primary hover:underline">
                    Download Photos →
                  </button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Company Facts */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-50">
          <div className="max-w-4xl mx-auto">
            <div className="scroll-fade">
              <H2 className="mb-8 text-center text-black">Company Facts</H2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
                <div>
                  <H3 className="mb-2 text-black">Founded</H3>
                  <Body className="text-black">2024</Body>
                </div>
                <div>
                  <H3 className="mb-2 text-black">Mission</H3>
                  <Body className="text-black">Democratizing creator marketing</Body>
                </div>
                <div>
                  <H3 className="mb-2 text-black">Platform</H3>
                  <Body className="text-black">Mobile-first creator marketplace</Body>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Press Releases */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
          <div className="max-w-4xl mx-auto">
            <div className="scroll-fade">
              <H2 className="mb-8 text-center text-black">Press Releases</H2>
              <div className="space-y-6">
                <div className="p-6 border border-gray-200 rounded-lg">
                  <div className="flex justify-between items-start mb-4">
                    <H3 className="text-black">Jungl Launches to Democratize Creator Marketing</H3>
                    <span className="text-sm text-gray-500">Coming Soon</span>
                  </div>
                  <Body className="text-gray-600">
                    New platform eliminates traditional influencer marketing barriers with zero transaction fees for creators and transparent pricing for brands.
                  </Body>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Media Contact */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-50">
          <div className="max-w-4xl mx-auto text-center">
            <div className="scroll-fade">
              <H2 className="mb-8 text-black">Media Contact</H2>
              <Body className="text-lg mb-8 text-black">
                For press inquiries, interviews, or media requests, please contact our media team.
              </Body>
              <div className="space-y-2">
                <Body className="text-black"><strong>Email:</strong> press@jungl.com</Body>
                <Body className="text-black"><strong>Response Time:</strong> Within 24 hours</Body>
              </div>
            </div>
          </div>
        </section>

        <Footer />
      </main>
      <BackToTop />
    </>
  );
};

export default Press;